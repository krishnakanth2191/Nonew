package testSuites;

import java.util.HashMap;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import au.gov.ipaustralia.selenium.browser.BrowserManagement;
import au.gov.ipaustralia.selenium.fileReader.ExcelReader;
import testCases.designs.EServicesDesignsNewApp;
import testCases.designs.EServicesDesignsRenewal;
import testCases.designs.EServicesDesignsResponsePreRegistrationFormalitiesCheck;

public class EServDesignsDataCreateSuite {

	// DATA PROVIDERS
	@DataProvider(name = "NewAppData")
	public Object[][] getNewAppData() {
		return (new ExcelReader()).getRowDataMap("ESERVICES", "RIO_Designs_Data.xlsx", "NewAppSR");
	}

	@Test(dataProvider = "NewAppData", enabled = true, groups = "DesignsNewApp")
	public void designsNewApplication(HashMap<String, String> dataMap) throws Exception {
		BrowserManagement.browser(driver -> EServicesDesignsNewApp.newAppSR(driver, dataMap));

	}

	@Test(groups = "DesignsAppRenew")
	public void designsRenew() throws Exception {
		BrowserManagement.browser(driver -> EServicesDesignsRenewal.renewal(driver));

	}

	@Test(groups = "DesignsPreAppFormalityNotice")
	public void designsPreAppFormalityNotice() throws Exception {
		BrowserManagement.browser(driver -> EServicesDesignsResponsePreRegistrationFormalitiesCheck.desResponsePreRegistration(driver));

	}

}
