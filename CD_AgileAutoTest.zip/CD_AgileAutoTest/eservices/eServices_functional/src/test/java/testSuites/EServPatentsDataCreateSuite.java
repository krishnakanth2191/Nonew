package testSuites;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import au.gov.ipaustralia.automation.selenium.helpers.db.PAMSDBManager;
import au.gov.ipaustralia.selenium.browser.BrowserManagement;
import au.gov.ipaustralia.testng.helpers.TestMethodCapture;
import testCases.patents.EServicesPatentExaminationReportResponse;
import testCases.patents.EServicesPatentExaminationStandard;
import testCases.patents.EServicesPatentITPPayment;
import testCases.patents.EServicesPatentNewApp;
import testCases.patents.EServicesPatentRenew;
import testCases.patents.EServicesPatentsAmendmentsAnticipationExam;
import testCases.patents.EServicesPatentNationalPhaseEntry;

@Listeners(TestMethodCapture.class)
public class EServPatentsDataCreateSuite {

    @Test(groups = "PatentsNewApplication")
    public void PatentNewApp() throws Exception {
        BrowserManagement.browser(driver -> EServicesPatentNewApp.newApplication(driver));
    }

    @Test(groups = "PatentsRenew")
    public void PatentRenew() throws Exception {
        String ipRight = (new PAMSDBManager()).getPatentForRenewal().getFirstDataItem().toString();
        BrowserManagement.browser(driver -> EServicesPatentRenew.renewalRequest(driver, ipRight));
    }

    @Test(groups = "ExamRequest")
    public void PatentExamRequest() throws Exception {
        BrowserManagement.browser(driver -> EServicesPatentExaminationStandard.examinationRequest(driver));
    }

    @Test(groups = "PatentNationalPhase")
    public void PatentNationalPhaseEntry() throws Exception {
        BrowserManagement.browser(driver -> EServicesPatentNationalPhaseEntry.nationalPhaseEntry(driver));
    }
    
    @Test(groups = "PatentAmendmentsExam")
    public void PatentsAmendmentsAnticipationExamination () throws Exception {
        BrowserManagement.browser(driver -> EServicesPatentsAmendmentsAnticipationExam.patentsAmendmentsAnticipationExam(driver));
    }
    
    @Test(groups = "ITPPayment")
    public void PatentITPPayment () throws Exception {
        BrowserManagement.browser(driver -> EServicesPatentITPPayment.itpPayment(driver));
    }
    
    @Test(groups = "PatentExamReportResponse")
    public void PatentExamReportResponse () throws Exception {
    	BrowserManagement.browser(driver -> EServicesPatentExaminationReportResponse.patentExamReportResponse(driver));
    }
        
}
