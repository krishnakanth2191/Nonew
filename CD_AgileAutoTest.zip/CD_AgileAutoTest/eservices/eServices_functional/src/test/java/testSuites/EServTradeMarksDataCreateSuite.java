package testSuites;

import java.util.HashMap;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import au.gov.ipaustralia.selenium.browser.BrowserManagement;
import au.gov.ipaustralia.selenium.fileReader.ExcelReader;
import au.gov.ipaustralia.testng.helpers.TestMethodCapture;
import testCases.tradeMark.EServicesTradeMarkAmendAddress;
import testCases.tradeMark.EServicesTradeMarksNewApp;
import testCases.tradeMark.EServicesTradeMarksRegistration;
import testCases.tradeMark.EServicesTradeMarksRenewal;

@Listeners(TestMethodCapture.class)
public class EServTradeMarksDataCreateSuite {

    @DataProvider(name = "NewAppData")
    public Object[][] tmNewAppData() {
        return (new ExcelReader()).getRowDataMap("ESERVICES", "ESERVICES_TradeMarks.xlsx", "NewApplication");
    }

    @Test(dataProvider = "NewAppData", enabled = true, groups = "TradeMarkNewApplication")
    public void tradeMarkNewApplication(HashMap<String, String> dataMap) throws Exception {
        BrowserManagement.browser(driver -> EServicesTradeMarksNewApp.newApplication(driver, dataMap));

    }

    @Test(groups = "TradeMarkAppRenew")
    public void tradeMarkRenew() throws Exception {
        BrowserManagement.browser(driver -> EServicesTradeMarksRenewal.renewal(driver));

    }

    @Test(groups = "RegistrationPayment")
    public void tradeMarkRegistration() throws Exception {
        BrowserManagement.browser(driver -> EServicesTradeMarksRegistration.tMRegistration(driver));
    }

    @Test(groups = "TradeMarkAmendAddress")
    public void tradeMarkAmendAddress() throws Exception {
        BrowserManagement.browser(driver -> EServicesTradeMarkAmendAddress.amendAddress(driver));
    }
    
}
