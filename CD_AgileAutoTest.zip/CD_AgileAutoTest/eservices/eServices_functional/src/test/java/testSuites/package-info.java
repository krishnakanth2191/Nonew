/**
 * Provides classes which group test cases into runnable suites
 * 
 */
package testSuites;