package testCases.tradeMark;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.File;
import java.util.Map;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Home;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Login;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.MyCart;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Payment;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Summary;
import au.gov.ipaustralia.selenium.eservices.pageobjects.designs.MainContact;
import au.gov.ipaustralia.selenium.eservices.pageobjects.trademarks.TradeMarkApplicants;
import au.gov.ipaustralia.selenium.eservices.pageobjects.trademarks.TradeMarks;
import au.gov.ipaustralia.selenium.eservices.pageobjects.trademarks.TradeMarksNewAppAdditionalDetails;
import au.gov.ipaustralia.selenium.eservices.pageobjects.trademarks.TradeMarksNewAppAppliacntOrAgent;
import au.gov.ipaustralia.selenium.eservices.pageobjects.trademarks.TradeMarksNewAppDetails;
import au.gov.ipaustralia.selenium.eservices.pageobjects.trademarks.TradeMarksNewAppGoodsAndServices;

public class EServicesTradeMarksNewApp {
	public static WebDriver newApplication(WebDriver driver, Map<String, String> testData) {
		System.out.println("Starting test case EServices_TradeMarks_newApp");

		PageFactory.initElements(driver, Login.class).doLogin(testData);

		Home homePage = PageFactory.initElements(driver, Home.class);
		assertThat(homePage.verifyPageUrl()).isTrue();
		assertThat(homePage.verifyPageLoaded()).isTrue();
		homePage.clickTradeMarksIncludingTmHeadstartLink();

		TakesScreenshot screen = (TakesScreenshot) driver;
		File src = screen.getScreenshotAs(OutputType.FILE);
		System.out.println("#### Screenshot AbsolutePath->" + src.getAbsolutePath());
		testData.put("ScreenshotPath", src.getAbsolutePath());

		TradeMarks trademarks = PageFactory.initElements(driver, TradeMarks.class);
		assertThat(trademarks.verifyPageUrl()).isTrue();
		assertThat(trademarks.verifyPageLoaded()).isTrue();
		trademarks.clickApplyForAnAustralianTradeMarkLink();

		TradeMarksNewAppAppliacntOrAgent appOrAgent = PageFactory.initElements(driver,
				TradeMarksNewAppAppliacntOrAgent.class);
		appOrAgent.setData(testData);
		assertThat(appOrAgent.verifyPageUrl()).isTrue();
		assertThat(appOrAgent.verifyPageLoaded()).isTrue();
		appOrAgent.setYourReferenceTextField();
		appOrAgent.selectApplicantOrAgent();
		appOrAgent.clickNextButton();

		TradeMarkApplicants applicants = PageFactory.initElements(driver, TradeMarkApplicants.class);
		applicants.setData(testData);
		assertThat(applicants.verifyPageUrl()).isTrue();
		assertThat(applicants.verifyPageLoaded()).isTrue();
		applicants.addNewApplicants();
		applicants.clickNextButton();

		MainContact mainContact = PageFactory.initElements(driver, MainContact.class);
		assertThat(mainContact.verifyPageLoaded()).isTrue();
		assertThat(mainContact.verifyPageUrl()).isTrue();
		mainContact.clickNextButton();

		TradeMarksNewAppDetails details = PageFactory.initElements(driver, TradeMarksNewAppDetails.class);
		details.setData(testData);
		assertThat(details.verifyPageUrl()).isTrue();
		assertThat(details.verifyPageLoaded()).isTrue();
		details.populateTMTypeFields();
		details.clickNextButton();

		TradeMarksNewAppAdditionalDetails additional = PageFactory.initElements(driver,
				TradeMarksNewAppAdditionalDetails.class);
		additional.setData(testData);
		assertThat(additional.verifyPageUrl()).isTrue();
		assertThat(additional.verifyPageLoaded()).isTrue();

		additional.populateNonEnglishWordsFields();
		additional.populateNonEnglishCharactersFields();
		additional.populateConvClaimFields();
		additional.populateDivisionalAppFields();
		additional.populateDefensiveMarkFields();

		additional.selectCertificationRadioButton();
		additional.addFileCertification();

		additional.selectCollectiveRadioButton();

		additional.populateLimitationsFields();

		additional.clickNextButton();

		TradeMarksNewAppGoodsAndServices goods = PageFactory.initElements(driver,
				TradeMarksNewAppGoodsAndServices.class);
		goods.setData(testData);
		assertThat(goods.verifyPageUrl()).isTrue();
		assertThat(goods.verifyPageLoaded()).isTrue();
		if (testData.get("DIVISIONAL_PARENT_NO").trim().equals("")) {
			goods.fillNominateSection();
		}
		goods.clickNextButton();

		Summary summary = PageFactory.initElements(driver, Summary.class);
		assertThat(summary.verifyPageUrl()).isTrue();
		assertThat(summary.verifyPageLoaded()).isTrue();
		summary.clickAddToCartButton();

		MyCart cart = PageFactory.initElements(driver, MyCart.class);
		cart.setData(testData);
		assertThat(cart.verifyPageUrl()).isTrue();
		assertThat(cart.verifyPageLoaded()).isTrue();
		cart.setYourCartReferenceTextField();
		cart.clickProceedToPayButton();

		Payment payment = PageFactory.initElements(driver, Payment.class);
		payment.setData(testData);
		assertThat(payment.verifyPageUrl()).isTrue();
		assertThat(payment.verifyPageLoaded()).isTrue();
		payment.makePayment();

		payment.signOut();
		return null;
	}
}
