package testCases.patents;

import static org.assertj.core.api.Assertions.assertThat;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Home;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Login;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.MyCart;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Payment;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Receipt;
import au.gov.ipaustralia.selenium.eservices.pageobjects.patents.Patents;
import au.gov.ipaustralia.selenium.eservices.pageobjects.patents.PatentsExaminationAdditionalRequests;
import au.gov.ipaustralia.selenium.eservices.pageobjects.patents.PatentsExaminationAttachments;
import au.gov.ipaustralia.selenium.eservices.pageobjects.patents.PatentsExaminationDetails;
import au.gov.ipaustralia.selenium.eservices.pageobjects.patents.PatentsExaminationSubmitterDetails;
import au.gov.ipaustralia.selenium.eservices.pageobjects.patents.PatentsExaminationSummary;

public class EServicesPatentsAmendmentsAnticipationExam {
    
    public static WebDriver patentsAmendmentsAnticipationExam(WebDriver driver) {

        PageFactory.initElements(driver, Login.class).defaultLogon();
        
        Home homePage = PageFactory.initElements(driver, Home.class);
        assertThat(homePage.verifyPageUrl()).isTrue();
        assertThat(homePage.verifyPageLoaded()).isTrue();
        homePage.clickPatentsLink();
        
        Patents patents = PageFactory.initElements(driver, Patents.class);
        assertThat(patents.verifyPageUrl()).isTrue();
        assertThat(patents.verifyPageLoaded()).isTrue();
        patents.clickExaminationRequest();
        
        PatentsExaminationSubmitterDetails submitter = PageFactory.initElements(driver, PatentsExaminationSubmitterDetails.class);
        assertThat(submitter.verifyPageUrl()).isTrue();
        assertThat(submitter.verifyPageLoaded()).isTrue();
        submitter.clickApplicantRadioButton();
        submitter.setYourReferenceTextField("Auto Examination Request Test");
        submitter.clickNextButton();
        
        PatentsExaminationDetails examDetails = PageFactory.initElements(driver, PatentsExaminationDetails.class);
        assertThat(examDetails.verifyPageUrl()).isTrue();
        assertThat(examDetails.verifyPageLoaded()).isTrue();
        examDetails.loadIPRightDetails();
        examDetails.clickFullExamination();
        examDetails.clickStatementOfEntitlement();
        examDetails.clickNextButton();
        
        PatentsExaminationAttachments attachments = PageFactory.initElements(driver, PatentsExaminationAttachments.class);
        assertThat(attachments.verifyPageUrl()).isTrue();
        assertThat(attachments.verifyPageLoaded()).isTrue();
        attachments.attachedSupportingDoc("cnpmapcooleman.pdf");
        attachments.clickNextButton();
        
        PatentsExaminationAdditionalRequests requests = PageFactory.initElements(driver, PatentsExaminationAdditionalRequests.class);
        assertThat(requests.verifyPageUrl()).isTrue();
        assertThat(requests.verifyPageLoaded()).isTrue();
        requests.clickRequestAmendmentButton();
        requests.attachAmendment("cnpmapcooleman.pdf");
        requests.clickNextButton();
        
        PatentsExaminationSummary summary = PageFactory.initElements(driver, PatentsExaminationSummary.class);
        assertThat(summary.verifyPageUrl()).isTrue();
        assertThat(summary.verifyPageLoaded()).isTrue();
        summary.clickAddToCartButton();
        
        MyCart cart = PageFactory.initElements(driver, MyCart.class);
        assertThat(cart.verifyPageUrl()).isTrue();
        assertThat(cart.verifyPageLoaded()).isTrue();
        cart.setYourCartReferenceTextField("Auto Patent Examination Test");
        cart.clickProceedToPayButton();
        
        Payment payment = PageFactory.initElements(driver, Payment.class);
        assertThat(payment.verifyPageUrl()).isTrue();
        assertThat(payment.verifyPageLoaded()).isTrue();
        payment.makeDefaultPayment();

        Receipt rec = PageFactory.initElements(driver, Receipt.class);
        assertThat(rec.verifyPageUrl()).isTrue();
        assertThat(rec.verifyPageLoaded()).isTrue();
        rec.signOut();
        
        return null;
        
    }

}
