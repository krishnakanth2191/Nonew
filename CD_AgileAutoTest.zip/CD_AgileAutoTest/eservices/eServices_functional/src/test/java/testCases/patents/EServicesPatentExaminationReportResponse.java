package testCases.patents;

import static org.assertj.core.api.Assertions.assertThat;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Home;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Login;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.MyCart;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Payment;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Receipt;
import au.gov.ipaustralia.selenium.eservices.pageobjects.generalrequest.GeneralRequestPatents;
import au.gov.ipaustralia.selenium.eservices.pageobjects.generalrequest.GeneralRequestSummary;
import au.gov.ipaustralia.selenium.eservices.pageobjects.generalrequest.GeneralRequestDetails;
import au.gov.ipaustralia.selenium.eservices.pageobjects.patents.Patents;

public class EServicesPatentExaminationReportResponse {

	/**
	 * Models Patent Response to an Examiners Report in eServices
	 *  
	 * Acceptance Criteria: 
	 *   1 Route to Patents "General eServices Request"
	 *   2 Select from drop-down list: "Examination", then "Response to an Examiner's Report"
	 *   3 Get relevant Patents IP number (same query as Patent Renewals)
	 *   4 Set 'Months to Pay' to any number other than null or 0
	 *   5 Attach PDF file
	 *   6 Add to Cart -> Payment -> signOut
	 *  
	 * @author Danielle Orth (bimord) 
	 * 
	 * @since 23/11/17
	 */

	private static final Logger LOGGER = Logger.getLogger(EServicesPatentExaminationReportResponse.class);

	public static WebDriver patentExamReportResponse(WebDriver driver) {

		LOGGER.info(
				"\n\n     - - - - - Starting test case EServices_Patent_Response_to_Examiners_Report - - - - -     \n");

		PageFactory.initElements(driver, Login.class).defaultLogon();

		Home homePage = PageFactory.initElements(driver, Home.class);
		assertThat(homePage.verifyPageUrl()).isTrue();
		assertThat(homePage.verifyPageLoaded()).isTrue();
		homePage.clickPatentsLink();

		/* Acceptance Criteria: 1 */
		Patents patents = PageFactory.initElements(driver, Patents.class);
		assertThat(patents.verifyPageUrl()).isTrue();
		assertThat(patents.verifyPageLoaded()).isTrue();
		patents.clickGeneralEServicesLink();

		GeneralRequestPatents patentsRequest = PageFactory.initElements(driver, GeneralRequestPatents.class);
		assertThat(patentsRequest.verifyPageUrl()).isTrue();
		assertThat(patentsRequest.verifyPageLoaded()).isTrue();
		/* Acceptance Criteria: 2 */
		patentsRequest.setIpRightDropDownListField("Patents");
		patentsRequest.setRequestCategoryDropDownListField("Examination");
		patentsRequest.setRequestTypeDropDownListField("Response to an Examiner's Report");
		patentsRequest.clickNextButton();

		GeneralRequestDetails patentsRequestDetails = PageFactory.initElements(driver, GeneralRequestDetails.class);
		assertThat(patentsRequestDetails.verifyPageUrl()).isTrue();
		assertThat(patentsRequestDetails.verifyPageLoaded()).isTrue();
		/* Acceptance Criteria: 3 */
		patentsRequestDetails.setPatentsIpRightNumber();
		patentsRequestDetails.clickAddDetailsButton();
		/* Acceptance Criteria: 4 */
		patentsRequestDetails.setMonthsToPay("2");
		/* Acceptance Criteria: 5 */
		patentsRequestDetails.addFilesCommon("PDF_Document.pdf");
		patentsRequestDetails.clickNextButton();

		/* Acceptance Criteria: 6 */
		GeneralRequestSummary summary = PageFactory.initElements(driver, GeneralRequestSummary.class);
		assertThat(summary.verifyPageUrl()).isTrue();
		assertThat(summary.verifyPageLoaded()).isTrue();
		summary.clickAddToCartButton();

		MyCart cart = PageFactory.initElements(driver, MyCart.class);
		assertThat(cart.verifyPageUrl()).isTrue();
		assertThat(cart.verifyPageLoaded()).isTrue();
		cart.setYourCartReferenceTextField("Patent Response to Examiner's Report");
		cart.clickProceedToPayButton();

		Payment payment = PageFactory.initElements(driver, Payment.class);
		assertThat(payment.verifyPageUrl()).isTrue();
		assertThat(payment.verifyPageLoaded()).isTrue();
		payment.makeDefaultPayment();

		Receipt rec = PageFactory.initElements(driver, Receipt.class);
		assertThat(rec.verifyPageUrl()).isTrue();
		assertThat(rec.verifyPageLoaded()).isTrue();
		rec.signOut();

		return null;
	}
}
