package testCases.patents;

import static org.assertj.core.api.Assertions.assertThat;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Home;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Login;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.MyCart;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Payment;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Summary;
import au.gov.ipaustralia.selenium.eservices.pageobjects.patents.Patents;
import au.gov.ipaustralia.selenium.eservices.pageobjects.patents.PatentsNewAppAdditionalRequests;
import au.gov.ipaustralia.selenium.eservices.pageobjects.patents.PatentsNewAppApplicantorAgent;
import au.gov.ipaustralia.selenium.eservices.pageobjects.patents.PatentsNewAppApplicants;
import au.gov.ipaustralia.selenium.eservices.pageobjects.patents.PatentsNewAppInventionDetails;
import au.gov.ipaustralia.selenium.eservices.pageobjects.patents.PatentsNewAppMainContact;
import au.gov.ipaustralia.selenium.eservices.pageobjects.patents.PatentsNewAppRelatedApplications;
import au.gov.ipaustralia.selenium.eservices.pageobjects.patents.PatentsNewAppSpecification;

public class EServicesPatentNewApp {

	public static WebDriver newApplication(WebDriver driver) {
		Login login = PageFactory.initElements(driver, Login.class);
		login.openHomePage();
		login.defaultLogon();

		Home home = PageFactory.initElements(driver, Home.class);
		assertThat(home.verifyPageUrl()).isTrue();
		assertThat(home.verifyPageLoaded()).isTrue();
		home.clickPatentsLink();

		Patents patents = PageFactory.initElements(driver, Patents.class);
		assertThat(patents.verifyPageUrl()).isTrue();
		assertThat(patents.verifyPageLoaded()).isTrue();
		patents.clickNewStandardPatent();

		PatentsNewAppApplicantorAgent appOrAgent = PageFactory.initElements(driver,
				PatentsNewAppApplicantorAgent.class);
		assertThat(appOrAgent.verifyPageUrl()).isTrue();
		assertThat(appOrAgent.verifyPageLoaded()).isTrue();
		appOrAgent.setYourReferenceTextField("Auto New App Test");
		appOrAgent.clickNextButton();

		PatentsNewAppApplicants applicants = PageFactory.initElements(driver, PatentsNewAppApplicants.class);
		assertThat(applicants.verifyPageUrl()).isTrue();
		assertThat(applicants.verifyPageLoaded()).isTrue();
		applicants.clickNextButton();

		PatentsNewAppMainContact contact = PageFactory.initElements(driver, PatentsNewAppMainContact.class);
		assertThat(contact.verifyPageUrl()).isTrue();
		assertThat(contact.verifyPageTitle()).isTrue();
		contact.clickNextButton();

		PatentsNewAppInventionDetails details = PageFactory.initElements(driver, PatentsNewAppInventionDetails.class);
		assertThat(details.verifyPageUrl()).isTrue();
		assertThat(details.verifyPageLoaded()).isTrue();
		details.setInventionDescription("A new standard patent");
		details.clickAddInventor();
		details.selectInventorTitle("Mr");
		details.setInventorName("Jimmy");
		details.setInventorLastName("Lime");
		details.clickSaveInventor();
		details.clickNextButton();

		PatentsNewAppRelatedApplications related = PageFactory.initElements(driver,
				PatentsNewAppRelatedApplications.class);
		assertThat(related.verifyPageUrl()).isTrue();
		assertThat(related.verifyPageLoaded()).isTrue();
		related.clickNextButton();

		PatentsNewAppSpecification specs = PageFactory.initElements(driver, PatentsNewAppSpecification.class);
		specs.clickAddDescription("cnpmapcooleman.pdf");
		specs.clickAddClaims("DESCRIPTION ver 12694054.pdf");
		specs.clickNextButton();

		PatentsNewAppAdditionalRequests additional = PageFactory.initElements(driver,
				PatentsNewAppAdditionalRequests.class);
		additional.clickNextButton();

		Summary summary = PageFactory.initElements(driver, Summary.class);
		assertThat(summary.verifyPageLoaded()).isTrue();
		summary.clickAddToCartButton();

		MyCart myCart = PageFactory.initElements(driver, MyCart.class);
		assertThat(myCart.verifyPageLoaded()).isTrue();
		myCart.setYourCartReferenceTextField("Auto Patent New App Test");
		myCart.clickProceedToPayButton();

		Payment payment = PageFactory.initElements(driver, Payment.class);
		assertThat(payment.verifyPageUrl()).isTrue();
		assertThat(payment.verifyPageLoaded()).isTrue();
		payment.makeDefaultPayment();

		payment.signOut();
		return null;

	}
}
