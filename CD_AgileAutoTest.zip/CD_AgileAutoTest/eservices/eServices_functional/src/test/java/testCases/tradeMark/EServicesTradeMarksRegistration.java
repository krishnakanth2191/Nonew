package testCases.tradeMark;

import static org.assertj.core.api.Assertions.assertThat;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Home;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Login;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.MyCart;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Payment;
import au.gov.ipaustralia.selenium.eservices.pageobjects.trademarks.TradeMarksRegistration;

/**
 * Models the process of Registering a Trade Mark in eServices
 * 
 * @author Danielle Orth - 04/10/2017
 *
 */
public class EServicesTradeMarksRegistration {
    private static final Logger LOGGER = Logger.getLogger(EServicesTradeMarksRegistration.class);
    private EServicesTradeMarksRegistration() {
    }

    public static WebDriver tMRegistration(WebDriver driver) {
        LOGGER.info("Starting test case EServices_TradeMarks_Registration");

        PageFactory.initElements(driver, Login.class).defaultLogon();

        /**
         * Assert that the Home.class page has loaded correctly Click the 'Trade Mark registration payment' link from
         * the home page
         */
        Home homePage = PageFactory.initElements(driver, Home.class);
        assertThat(homePage.verifyPageUrl()).isTrue();
        assertThat(homePage.verifyPageLoaded()).isTrue();
        homePage.clickTradeMarkRegistrationPayment();

        /**
         * Assert TradeMarksRegistration.class has loaded correctly, populate unregistered TM number, and click 'Add'
         * button - (Wait for eServices)
         */
        TradeMarksRegistration tmRegistration = PageFactory.initElements(driver, TradeMarksRegistration.class);
        assertThat(tmRegistration.verifyPageUrl()).as("TM REGISTRATION page URL").isTrue();
        // assertThat(tmRegistration.verifyPageLoaded()).as("TM REGISTRATION page loaded").isTrue();
        tmRegistration.setTradeMarkTextField();
        tmRegistration.clickAddButton();

        /**
         * Assert no Error Messages present
         */
        assertThat(tmRegistration.verifyPageUrl()).as("TM REGISTRATION page URL").isTrue();
        // assertThat(tmRegistration.verifyPageLoaded()).as("TM REGISTRATION page loaded").isTrue();
        for (int i = 0; i < 10; i++) {
            if (tmRegistration.noErrorMessages() == false) {
                tmRegistration.setTradeMarkTextField();
                tmRegistration.clickAddButton();
            }
            else if (tmRegistration.noErrorMessages() == true) {
                LOGGER.info("Click Add To Cart");
                tmRegistration.clickAddToCartButton();
                i = 10;
            }
        }

        /**
         * Payment & Sign out
         */
        MyCart cart = PageFactory.initElements(driver, MyCart.class);
        assertThat(cart.verifyPageUrl()).as("MY CART page URL").isTrue();
        assertThat(cart.verifyPageLoaded()).as("MY CART page loaded").isTrue();
        cart.setYourCartReferenceTextField();
        cart.clickProceedToPayButton();

        Payment payment = PageFactory.initElements(driver, Payment.class);
        assertThat(payment.verifyPageUrl()).as("PAYMENT page URL").isTrue();
        assertThat(payment.verifyPageLoaded()).as("PAYMENT page loaded").isTrue();
        payment.makeDefaultPayment();

        payment.signOut();
        LOGGER.info("   - Test case EServices_TradeMarks_Registration_Payment complete");
        return null;
    }
}
