package testCases.patents;

import static org.assertj.core.api.Assertions.assertThat;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Home;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Login;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.MakeAPayment;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.MyCart;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Payment;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Summary;

/**
 * Test steps for Patents ITP Payment
 * 
 * @author Jonathan Eastman
 * 
 * @Jira AUTO-231
 *
 */

public class EServicesPatentITPPayment {

        public static void itpPayment(WebDriver driver) {

            PageFactory.initElements(driver, Login.class).defaultLogon();
            
            Home homePage = PageFactory.initElements(driver, Home.class);
            assertThat(homePage.verifyPageUrl()).isTrue();
            assertThat(homePage.verifyPageLoaded()).isTrue();
            homePage.clickMakeAPayment();
            
            MakeAPayment makeAPayment = PageFactory.initElements(driver, MakeAPayment.class);
            assertThat(makeAPayment.verifyPageUrl()).isTrue();
            assertThat(makeAPayment.verifyPageLoaded()).isTrue();
            makeAPayment.clickInvitationToPay();
            makeAPayment.setIPRightType("Patents");
            makeAPayment.loadITPPaymentNumber();
            makeAPayment.clickPayNow();
            makeAPayment.clickNextButton();
            
            Summary summary = PageFactory.initElements(driver, Summary.class);
            summary.clickAddToCartButton();

            MyCart myCart = PageFactory.initElements(driver, MyCart.class);
            assertThat(myCart.verifyPageUrl()).isTrue();
            assertThat(myCart.verifyPageLoaded()).isTrue();
            myCart.setYourCartReferenceTextField("Auto Patent New App Test");
            myCart.clickProceedToPayButton();

            Payment payment = PageFactory.initElements(driver, Payment.class);
            assertThat(payment.verifyPageUrl()).isTrue();
            assertThat(payment.verifyPageLoaded()).isTrue();
            payment.makeDefaultPayment();

            payment.signOut();
    }
        
}
