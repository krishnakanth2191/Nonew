/**
 * Provides classes which define the test cases
 * 
 */
package testCases.designs;