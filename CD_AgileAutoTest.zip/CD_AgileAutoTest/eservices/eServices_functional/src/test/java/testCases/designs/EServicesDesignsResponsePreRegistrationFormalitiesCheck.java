package testCases.designs;

import static org.assertj.core.api.Assertions.assertThat;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Home;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Login;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.MyCart;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Receipt;
import au.gov.ipaustralia.selenium.eservices.pageobjects.designs.DesignsResponsePreRegistration;

public class EServicesDesignsResponsePreRegistrationFormalitiesCheck {

	/**
	 * Models Designs Pre-Registration for formality check notices in eServices
	 *  
	 * Acceptance Criteria: 
	 *   1 Routes to 'Responds to Formalities Status'
	 *   2 Pulls valid Designs Mark Number from the DB
	 *   3 Uploads selected PDF for Lodge Response
	 *   4 Uploads selected image for Representations
	 *   5 Continues to completion (MyCart-Receipt-SignOut)
	 *  
	 * @author Danielle Orth (bimord) 
	 * @since 21/11/17
	 */

	private static final Logger LOGGER = Logger
			.getLogger(EServicesDesignsResponsePreRegistrationFormalitiesCheck.class);

	public static WebDriver desResponsePreRegistration(WebDriver driver) {
		LOGGER.info(
				"\n\n     - - - - - Starting test case EServices_Designs_Response_PreRegistration_Formalities_Check_Notice - - - - -     \n");

		PageFactory.initElements(driver, Login.class).defaultLogon();

		Home homePage = PageFactory.initElements(driver, Home.class);
		assertThat(homePage.verifyPageUrl()).isTrue();
		assertThat(homePage.verifyPageLoaded()).isTrue();
		homePage.clickDesignsLink();
		/* Acceptance Criteria 1 */
		homePage.clickDesignsServiceRequests();

		DesignsResponsePreRegistration formalityCheck = PageFactory.initElements(driver,
				DesignsResponsePreRegistration.class);
		assertThat(formalityCheck.verifyPageUrl()).isTrue();
		assertThat(formalityCheck.verifyPageLoaded()).isTrue();
		formalityCheck.clickRespondToFormalitiesNotice();
		/* Acceptance Criteria 2 */
		formalityCheck.setDesignsFormalitiesNoticeNumber();
		formalityCheck.clickRetrieveDetailsButton();
		formalityCheck.clickLodgeDocumentResponse();
		/* Acceptance Criteria 3 */
		formalityCheck.addFilesCommon("PDF_Document.pdf");
		formalityCheck.clickNextButton();
		/* Acceptance Criteria 4 */
		formalityCheck.addFilesCommon("PNG_Image.png");
		formalityCheck.clickNextButton();
		formalityCheck.clickNextButton();
		formalityCheck.clickAddToCartButton();

		/* Acceptance Criteria 5 */
		MyCart cart = PageFactory.initElements(driver, MyCart.class);
		assertThat(cart.verifyPageUrl()).isTrue();
		assertThat(cart.verifyPageLoaded()).isTrue();
		cart.setYourCartReferenceTextField("Designs Formality Notice");
		cart.clickProceedToPayButton();

		Receipt receipt = PageFactory.initElements(driver, Receipt.class);
		String batchReference = new String();
		assertThat(receipt.verifyPageUrl()).isTrue();
		assertThat(receipt.verifyPageLoaded()).isTrue();
		batchReference = receipt.getBatchReference().toString();
		LOGGER.info("\n" + batchReference);
		receipt.signOut();

		return null;
	}
}
