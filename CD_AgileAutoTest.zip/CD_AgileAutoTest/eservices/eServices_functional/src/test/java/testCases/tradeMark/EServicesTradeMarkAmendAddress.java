package testCases.tradeMark;

import static org.assertj.core.api.Assertions.assertThat;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Home;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Login;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.MyCart;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Receipt;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Summary;
import au.gov.ipaustralia.selenium.eservices.pageobjects.designs.GeneralRequest;
import au.gov.ipaustralia.selenium.eservices.pageobjects.designs.GeneralRequestDetails;
import au.gov.ipaustralia.selenium.eservices.pageobjects.generalrequest.GeneralRequestTradeMarks;
import au.gov.ipaustralia.selenium.eservices.pageobjects.trademarks.TradeMarks;

public class EServicesTradeMarkAmendAddress {

    private static final Logger LOGGER = Logger.getLogger(EServicesTradeMarkAmendAddress.class);

    public static WebDriver amendAddress(WebDriver driver) {

        PageFactory.initElements(driver, Login.class).defaultLogon();

        Home homePage = PageFactory.initElements(driver, Home.class);
        assertThat(homePage.verifyPageUrl()).isTrue();
        assertThat(homePage.verifyPageLoaded()).isTrue();
        homePage.clickTradeMarksIncludingTmHeadstartLink();

        TradeMarks tradeMarks = PageFactory.initElements(driver, TradeMarks.class);
        assertThat(tradeMarks.verifyPageUrl()).isTrue();
        assertThat(tradeMarks.verifyPageLoaded()).isTrue();
        tradeMarks.clickGeneralRequest();

        GeneralRequest general = PageFactory.initElements(driver, GeneralRequest.class);
        assertThat(general.verifyPageUrl()).isTrue();
        assertThat(general.verifyPageLoaded()).isTrue();
        general.setYourReferenceTextField("Auto Amend Address Test");
        general.setIpRightTypeDropDownListField("Trade Marks");
        general.setRequestCategoryDropDownListField("Amendment - Excluding TM Headstart (pre-application service)");
        general.setRequestTypeDropDownListField("Amend the Address for Service");
        general.clickNextButton();

        GeneralRequestTradeMarks requestDetails = PageFactory.initElements(driver, GeneralRequestTradeMarks.class);
        assertThat(requestDetails.verifyPageUrl()).isTrue();
        assertThat(requestDetails.verifyPageLoaded()).isTrue();
        requestDetails.loadTMDetails("REGISTERED");
        LOGGER.info("Trade Mark Number successfully found");
        requestDetails.addFilesCommon("cnpmapcooleman.pdf");
        LOGGER.info("File successfully attached");
        requestDetails.clickNextButton();

        Summary summary = PageFactory.initElements(driver, Summary.class);
        assertThat(summary.verifyPageUrl()).isTrue();
        assertThat(summary.verifyPageLoaded()).isTrue();
        summary.clickAddToCartButton();

        MyCart cart = PageFactory.initElements(driver, MyCart.class);
        assertThat(cart.verifyPageUrl()).isTrue();
        assertThat(cart.verifyPageLoaded()).isTrue();
        cart.setYourCartReferenceTextField("Auto TM Amend Address");
        cart.clickProceedToPayButton();

        Receipt receipt = PageFactory.initElements(driver, Receipt.class);
        String batchReference = new String();
        assertThat(receipt.verifyPageUrl()).isTrue();
        assertThat(receipt.verifyPageLoaded()).isTrue();
        batchReference = receipt.getBatchReference().toString();
        LOGGER.info(batchReference);
        receipt.signOut();
        return null;

    }

}
