package testCases.designs;

import static org.assertj.core.api.Assertions.assertThat;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Home;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Login;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.MyCart;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Payment;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Receipt;
import au.gov.ipaustralia.selenium.eservices.pageobjects.designs.RenewalOfIPRights;

public class EServicesDesignsRenewal {
    
    /**
     * Author - Jonathan Eastman
     * Scripting begun 15/09/17
     */

	private static final Logger LOGGER = Logger.getLogger(EServicesDesignsRenewal.class);
	public static WebDriver renewal(WebDriver driver) {
		System.out.println("Starting test case EServices_Designs_Renewal");

		PageFactory.initElements(driver, Login.class).defaultLogon();
		
		Home homePage = PageFactory.initElements(driver, Home.class);
		assertThat(homePage.verifyPageUrl()).isTrue();
		assertThat(homePage.verifyPageLoaded()).isTrue();
		homePage.clickRenewalPayment();
		
		RenewalOfIPRights renewal = PageFactory.initElements(driver, RenewalOfIPRights.class);
		assertThat(renewal.verifyPageUrl()).isTrue();
		assertThat(renewal.verifyPageLoaded()).isTrue();
		renewal.setYourRefText("Auto Designs Renewal Test");
		renewal.selectIPRightType("Designs");
		renewal.setDesignsRenewalNumber();
		renewal.clickAddButton();
		renewal.clickAddToCartButton();
		
		MyCart cart = PageFactory.initElements(driver, MyCart.class);
		assertThat(cart.verifyPageUrl()).isTrue();
		assertThat(cart.verifyPageLoaded()).isTrue();
		cart.setYourCartReferenceTextField("Auto Designs Renewal");
		cart.clickProceedToPayButton();
		
		Payment payment = PageFactory.initElements(driver, Payment.class);
		assertThat(payment.verifyPageUrl()).isTrue();
		assertThat(payment.verifyPageLoaded()).isTrue();
		payment.makeDefaultPayment();
		
		Receipt receipt = PageFactory.initElements(driver, Receipt.class);
        String batchReference = new String();
        assertThat(receipt.verifyPageUrl()).isTrue();
        assertThat(receipt.verifyPageLoaded()).isTrue();
        batchReference = receipt.getBatchReference().toString();
        LOGGER.info(batchReference);
        receipt.signOut();
        return null;
	}

}
