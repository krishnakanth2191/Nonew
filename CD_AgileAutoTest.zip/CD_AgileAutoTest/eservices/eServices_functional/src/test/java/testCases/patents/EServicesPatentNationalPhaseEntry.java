package testCases.patents;

import static org.assertj.core.api.Assertions.assertThat;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Home;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Login;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.MyCart;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Payment;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Summary;
import au.gov.ipaustralia.selenium.eservices.pageobjects.patents.Patents;
import au.gov.ipaustralia.selenium.eservices.pageobjects.patents.PatentsNewAppAdditionalRequests;
import au.gov.ipaustralia.selenium.eservices.pageobjects.patents.PatentsNewAppMainContact;
import au.gov.ipaustralia.selenium.eservices.pageobjects.patents.PatentsNewAppNationalPhaseEntryReference;
import au.gov.ipaustralia.selenium.eservices.pageobjects.patents.PatentsNewAppNationalPhaseEntryWipoPctNumber;
import au.gov.ipaustralia.selenium.eservices.pageobjects.patents.PatentsNewAppSpecification;

/**
 * Test steps for Patents National Phase Entry
 * 
 * @author Suresh Thumma - 06/11/2017
 * 
 * @Jira AUTO-226
 *
 */

public class EServicesPatentNationalPhaseEntry {
    
    private static final Logger LOGGER = Logger.getLogger(EServicesPatentNationalPhaseEntry.class);
	public static WebDriver nationalPhaseEntry(WebDriver driver) {
	    LOGGER.info("Starting National Phase Entry");
	    Login login = PageFactory.initElements(driver, Login.class);
        login.openHomePage();
        login.defaultLogon();

        Home home = PageFactory.initElements(driver, Home.class);
        assertThat(home.verifyPageUrl()).isTrue();
        assertThat(home.verifyPageLoaded()).isTrue();
        home.clickPatentsLink();

        Patents patents = PageFactory.initElements(driver, Patents.class);
        assertThat(patents.verifyPageUrl()).isTrue();
        assertThat(patents.verifyPageLoaded()).isTrue();
        patents.clickNationalPhase();
               

        PatentsNewAppNationalPhaseEntryWipoPctNumber wipoPCTNumber = PageFactory.initElements(driver, PatentsNewAppNationalPhaseEntryWipoPctNumber.class);
        assertThat(wipoPCTNumber.verifyPageUrl()).isTrue();
        assertThat(wipoPCTNumber.verifyPageTitle()).isTrue();
        wipoPCTNumber.setWipoYear();
        wipoPCTNumber.setWipoNumber();
        wipoPCTNumber.clickNextButton();
        
        PatentsNewAppNationalPhaseEntryReference pctReference = PageFactory.initElements(driver, PatentsNewAppNationalPhaseEntryReference.class);
        assertThat(pctReference.verifyPageUrl()).isTrue();
        assertThat(pctReference.verifyPageTitle()).isTrue();
        pctReference.setPCTRef("AUT_NPE");
        pctReference.attachedPCTReqForm("cnpmapcooleman.pdf");
        pctReference.clickAcknowledgeNPAYes();
        pctReference.clickFiledEnglishYes();
        pctReference.clickPriorityClaimYes();
        pctReference.clickNextButton();
        
        
        PatentsNewAppMainContact contact = PageFactory.initElements(driver, PatentsNewAppMainContact.class);
        assertThat(contact.verifyPageUrl()).isTrue();
        assertThat(contact.verifyPageTitle()).isTrue();
        contact.clickNextButton();

        PatentsNewAppSpecification specs = PageFactory.initElements(driver, PatentsNewAppSpecification.class);
        specs.clickAddDescription("cnpmapcooleman.pdf");
        specs.clickAddClaims("DESCRIPTION ver 12694054.pdf");
        specs.clickNextButton();

        PatentsNewAppAdditionalRequests additional = PageFactory.initElements(driver,
                PatentsNewAppAdditionalRequests.class);
        assertThat(additional.verifyPageUrl()).isTrue();
        assertThat(additional.verifyPageTitle()).isTrue();
        additional.clickNextButton();

        Summary summary = PageFactory.initElements(driver, Summary.class);
        assertThat(summary.verifyPageLoaded()).isTrue();
        summary.clickAddToCartButton();

        MyCart myCart = PageFactory.initElements(driver, MyCart.class);
        assertThat(myCart.verifyPageLoaded()).isTrue();
        myCart.setYourCartReferenceTextField("Auto Patent National Phase Entry");
        myCart.clickProceedToPayButton();

        Payment payment = PageFactory.initElements(driver, Payment.class);
        assertThat(payment.verifyPageUrl()).isTrue();
        assertThat(payment.verifyPageLoaded()).isTrue();
        payment.makeDefaultPayment();

        payment.signOut();
        LOGGER.info("End of National Phase Entry");
        return null;
       

    }
}
