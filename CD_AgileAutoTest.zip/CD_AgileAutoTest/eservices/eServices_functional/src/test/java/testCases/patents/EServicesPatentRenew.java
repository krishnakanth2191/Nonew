package testCases.patents;

import static org.assertj.core.api.Assertions.assertThat;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Home;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Login;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.MyCart;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Payment;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Receipt;
import au.gov.ipaustralia.selenium.eservices.pageobjects.patents.Patents;
import au.gov.ipaustralia.selenium.eservices.pageobjects.patents.RenewalOfIPRights;



public class EServicesPatentRenew {

	public static void renewalRequest(WebDriver driver, String ipRightID) {
		System.out.println("Starting method eservicesRenewalRequest");
		Login logonPage = PageFactory.initElements(driver, Login.class);
		logonPage.openHomePage();
		logonPage.defaultLogon();

		Home homePage = PageFactory.initElements(driver, Home.class);
		assertThat(homePage.verifyPageUrl()).isTrue();
		assertThat(homePage.verifyPageLoaded()).isTrue();
		homePage.clickPatentsLink();

		Patents patents = PageFactory.initElements(driver, Patents.class);
		assertThat(patents.verifyPageUrl()).isTrue();
		assertThat(patents.verifyPageLoaded()).isTrue();
		patents.clickRenewPatent();

		RenewalOfIPRights renew = PageFactory.initElements(driver, RenewalOfIPRights.class);
		renew.setYourRefText("Auto Test PR");
		renew.selectIPRightType("Patents");
		renew.setIPRightNumber(ipRightID);
		renew.clickAddButton();
		renew.clickAddToCartButton();

		MyCart cart = PageFactory.initElements(driver, MyCart.class);
		assertThat(cart.verifyPageUrl()).isTrue();
		assertThat(cart.verifyPageLoaded()).isTrue();
		cart.setYourCartReferenceTextField("Auto Cart Ref");
		cart.clickProceedToPayButton();

		Payment payment = PageFactory.initElements(driver, Payment.class);
		assertThat(payment.verifyPageUrl()).isTrue();
		assertThat(payment.verifyPageLoaded()).isTrue();
		payment.makeDefaultPayment();

		Receipt rec = PageFactory.initElements(driver, Receipt.class);
		assertThat(rec.verifyPageUrl()).isTrue();
		assertThat(rec.verifyPageLoaded()).isTrue();
		rec.signOut();

	}
}
