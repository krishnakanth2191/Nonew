package testCases.designs;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import au.gov.ipaustralia.selenium.eservices.pageobjects.common.CustomerDetails;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Home;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Login;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.MyCart;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Payment;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Receipt;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.Summary;
import au.gov.ipaustralia.selenium.eservices.pageobjects.designs.Designs;
import au.gov.ipaustralia.selenium.eservices.pageobjects.designs.DesignsApplicants;
import au.gov.ipaustralia.selenium.eservices.pageobjects.designs.DesignsNewAppApplicantOrAgent;
import au.gov.ipaustralia.selenium.eservices.pageobjects.designs.DesignsNewAppCategory;
import au.gov.ipaustralia.selenium.eservices.pageobjects.designs.DesignsNewAppDesigners;
import au.gov.ipaustralia.selenium.eservices.pageobjects.designs.DesignsNewAppPriority;
import au.gov.ipaustralia.selenium.eservices.pageobjects.designs.DesignsNewAppProducts;
import au.gov.ipaustralia.selenium.eservices.pageobjects.designs.DesignsNewAppRepresentations;
import au.gov.ipaustralia.selenium.eservices.pageobjects.designs.MainContact;

public class EServicesDesignsNewApp {

	public static WebDriver newAppSR(WebDriver driver, Map<String, String> testData) {
		String signedInCustomer = "";

		PageFactory.initElements(driver, Login.class).doLogin(testData);

		Home homePage = PageFactory.initElements(driver, Home.class);
		assertThat(homePage.verifyPageUrl()).isTrue();
		assertThat(homePage.verifyPageLoaded()).isTrue();
		if (testData.get("CATEGORY").equals("EXISTING_EXCLUDED_APPLICATION")) {
			homePage.clickCustomerDetailsLink();
			CustomerDetails custDetails = PageFactory.initElements(driver, CustomerDetails.class);
			assertThat(custDetails.verifyPageUrl()).isTrue();
			assertThat(custDetails.verifyPageLoaded()).isTrue();
			signedInCustomer = custDetails.getCustomerID();
			custDetails.clickCancelButton();
			assertThat(homePage.verifyPageUrl()).isTrue();
			assertThat(homePage.verifyPageLoaded()).isTrue();
		}
		homePage.clickDesignsLink();

		Designs designs = PageFactory.initElements(driver, Designs.class);
		assertThat(designs.verifyPageUrl()).isTrue();
		assertThat(designs.verifyPageLoaded()).isTrue();
		designs.clickApplyForADesignLink();
		
		DesignsNewAppCategory cat = PageFactory.initElements(driver, DesignsNewAppCategory.class);
		cat.setData(testData);
		assertThat(cat.verifyPageUrl()).isTrue();
		assertThat(cat.verifyPageLoaded()).isTrue();
		cat.selectDesignCategory();
		cat.clickStartButton();

		DesignsNewAppApplicantOrAgent appOrAgent = PageFactory.initElements(driver,
				DesignsNewAppApplicantOrAgent.class);
		appOrAgent.setData(testData);
		assertThat(appOrAgent.verifyPageLoaded()).isTrue();
		assertThat(appOrAgent.verifyPageUrl()).isTrue();
		appOrAgent.setAssociatedApplicationNumber(signedInCustomer);
		appOrAgent.setYourReferenceTextField();
		appOrAgent.selectApplicantOrAgent();
		appOrAgent.clickNextButton();

		DesignsApplicants applicants = PageFactory.initElements(driver, DesignsApplicants.class);
		applicants.setData(testData);
		assertThat(applicants.verifyPageUrl()).isTrue();
		assertThat(applicants.verifyPageLoaded()).isTrue();
		applicants.addNewApplicants();
		applicants.clickNextButton();

		MainContact mainContact = PageFactory.initElements(driver, MainContact.class);
		assertThat(mainContact.verifyPageLoaded()).isTrue();
		assertThat(mainContact.verifyPageUrl()).isTrue();

		mainContact.clickNextButton();

		DesignsNewAppDesigners designers = PageFactory.initElements(driver, DesignsNewAppDesigners.class);
		designers.setData(testData);
		assertThat(designers.verifyPageLoaded()).isTrue();
		assertThat(designers.verifyPageUrl()).isTrue();
		designers.selectApplicant();
		designers.addNewDesigners();
		designers.clickNextButton();
		if (testData.get("DESIGNER_GIVEN_NAME").equals("")) {
			applicants.clickYesNoDesigher();

		}

		DesignsNewAppProducts products = PageFactory.initElements(driver, DesignsNewAppProducts.class);
		products.setData(testData);
		assertThat(products.verifyPageUrl()).isTrue();
		assertThat(products.verifyPageLoaded()).isTrue();
		products.setProductTextareaField();
		products.setStatementOfNewnessAndDistinctivenessTextareaField();
		products.clickNextButton();

		DesignsNewAppRepresentations reps = PageFactory.initElements(driver, DesignsNewAppRepresentations.class);
		reps.setData(testData);
		assertThat(reps.verifyPageUrl()).isTrue();
		assertThat(reps.verifyPageLoaded()).isTrue();
		reps.addFiles();
		reps.clickNextButton();

		DesignsNewAppPriority priority = PageFactory.initElements(driver, DesignsNewAppPriority.class);
		priority.setData(testData);
		assertThat(priority.verifyPageUrl()).isTrue();
		assertThat(priority.verifyPageLoaded()).isTrue();
		priority.addConventionClaims();
		priority.setRequestTypeRadioButtonField();
		priority.clickNextButton();

		Summary summary = PageFactory.initElements(driver, Summary.class);		
		assertThat(summary.verifyPageUrl()).isTrue();
		assertThat(summary.verifyPageLoaded()).isTrue();
		summary.clickAddToCartButton();

		MyCart cart = PageFactory.initElements(driver, MyCart.class);
		cart.setData(testData);
		assertThat(cart.verifyPageUrl()).isTrue();
		assertThat(cart.verifyPageLoaded()).isTrue();
		cart.setYourCartReferenceTextField();
		cart.clickProceedToPayButton();

		Payment payment = PageFactory.initElements(driver, Payment.class);
		payment.setData(testData);
		assertThat(payment.verifyPageUrl()).isTrue();
		assertThat(payment.verifyPageLoaded()).isTrue();
		payment.makePayment();

		Receipt rec = PageFactory.initElements(driver, Receipt.class);
		assertThat(rec.verifyPageUrl()).isTrue();
		assertThat(rec.verifyPageLoaded()).isTrue();
		rec.signOut();
		return null;
	}
}
