package au.gov.ipaustralia.selenium.eservices.pageobjects.patents;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import au.gov.ipaustralia.selenium.eservices.pageobjects.common.BasePageEServices;
import au.gov.ipaustralia.selenium.helpers.wait.WaitTool;

public class PatentsNewAppSpecification extends PatentBasePage {

    private static final String PAGE_TITLE = "SPECIFICATION";
    private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/eservices\\/patent\\/.*\\/.*-wizard.xhtml";

    @FindBy(id = "idWizardForm:idSpecificationDescriptionFileUploadFileUploadButton")
    private WebElement attachDescription;

    @FindBy(id = "idWizardForm:idSpecificationClaimsFileUploadFileUploadButton")
    private WebElement attachClaims;

    @FindBy(className = "errorMessage")
    private WebElement uploadStatus;

    static final String BROWSE_FILE_DESRIPTION = "idWizardForm:idSpecificationDescriptionFileUpload";
    @FindBy(id = BROWSE_FILE_DESRIPTION)
    private WebElement browseFilesDescription;

    static final String BROWSE_FILE_CLAIMS = "idWizardForm:idSpecificationClaimsFileUpload";
    @FindBy(id = BROWSE_FILE_CLAIMS)
    private WebElement browseFilesClaims;

    public PatentsNewAppSpecification(WebDriver driver) {
        super(driver);
    }

    /**
     * Element to click on Add Description link and attach given file
     *
     * @return
     */
    public PatentsNewAppSpecification clickAddDescription(String fileName) {
        addFilesDescription(fileName);
        return this;
    }

    /**
     * Element to click on Add claims link and attach given file
     *
     * @return
     */
    public PatentsNewAppSpecification clickAddClaims(String fileName) {
        addFilesClaims(fileName);
        return this;
    }

    /**
     * @param fileName
     * 
     * @ passing browser elements as common ...
     * @return
     * @return TradeMarksNewApp_Details instance
     */
    public BasePageEServices addFilesDescription(String fileName) {
        WaitTool.waitForElement(driver, By.id(BROWSE_FILE_DESRIPTION), timeout);
        addFile(fileName, browseFilesDescription);
        return this;

    }

    /**
     * @param fileName
     * 
     * @ passing browser elements as common ...
     * @return
     * @return TradeMarksNewApp_Details instance
     */
    public BasePageEServices addFilesClaims(String fileName) {
        WaitTool.waitForElement(driver, By.id(BROWSE_FILE_CLAIMS), timeout);
        addFile(fileName, browseFilesClaims);
        return this;

    }

    /**
     * VerifyTables that current page URL matches the expected URL.
     *
     * @return boolean.
     */
    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    /**
     * VerifyPageTitle Matches with given title.
     *
     * @return boolean.
     */
    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

}
