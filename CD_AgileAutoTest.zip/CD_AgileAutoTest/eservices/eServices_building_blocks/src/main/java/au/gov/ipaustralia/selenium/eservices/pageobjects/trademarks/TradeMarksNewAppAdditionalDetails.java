package au.gov.ipaustralia.selenium.eservices.pageobjects.trademarks;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TradeMarksNewAppAdditionalDetails extends TradeMarksBasePage {

    private static final Logger LOGGER = Logger.getLogger(TradeMarksNewAppAdditionalDetails.class);
    private static final String PAGE_TITLE = "ADDITIONAL TRADE MARK DETAILS";
    private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/eservices\\/trademark\\.*\\/.*wizard.xhtml";
    private static final String VALUE = "value";
    private static final String FALSE = "false";

    // Non English content
    @FindBy(name = "idWizardForm:nonEnglishIndicator")
    private List<WebElement> containsNonEnglishRadioGroup;

    @FindBy(id = "idWizardForm:languageOtherThanEnglish")
    private WebElement containsForeignWordsCheckBox;

    @FindBy(id = "idWizardForm:translationPart1")
    private WebElement foreignLanguageTextField;

    @FindBy(id = "idWizardForm:translationPart2")
    private WebElement foreignWordsTestField;

    @FindBy(id = "idWizardForm:translationPart3")
    private WebElement translatedWords;

    @FindBy(id = "idWizardForm:foreignScript")
    private WebElement containsForeignCharatersCheckBox;

    @FindBy(id = "idWizardForm:transliterationPart1A")
    private WebElement foreignCharTextField;

    @FindBy(id = "idWizardForm:transliterationPart2")
    private WebElement foreignCharTransliteredAsTextField;

    @FindBy(id = "idWizardForm:transliterationPart3")
    private WebElement foreignCharTranslatedAsTextField;

    // Convention claim
    @FindBy(name = "idWizardForm:idConventionIndicator")
    private List<WebElement> convClaimGroup;

    @FindBy(id = "idWizardForm:tradeMarkNumberField")
    private WebElement convClaimTMNumberTextField;

    @FindBy(id = "idWizardForm:SelectCountry")
    private WebElement convClaimCountrySelectList;

    @FindBy(id = "idWizardForm:lodgementDateFieldInputDate")
    private WebElement convClaimLodgeDateTextField;

    @FindBy(id = "idWizardForm:ConventionGandsAddBtn")
    private WebElement concClaimGoodsAndServicesLink;

    @FindBy(id = "idWizardForm:ConventionGandsClassIdField")
    private WebElement convClaimClassNumberTextField;

    @FindBy(id = "idWizardForm:ConventionGandsDescriptionField")
    private WebElement convClaimGandSDescTextField;

    @FindBy(id = "idWizardForm:SaveConventionGandsBtn")
    private WebElement convClaimSaveGandSButton;

    @FindBy(id = "idWizardForm:SaveClaimBtn")
    private WebElement saveConvClainButton;

    // Divisional
    @FindBy(name = "idWizardForm:idDivisionalIndicator")
    private List<WebElement> divisionalGroup;

    @FindBy(id = "idWizardForm:divisionalParentIdentifier")
    private WebElement divisionalParentNumberTextField;

    @FindBy(id = "idWizardForm:retrieveDivisionalParentButton")
    private WebElement retrieveDetailsButton;

    @FindBy(id = "idWizardForm:divisionalParentGoodsAndServices:0:Description")
    private WebElement divisionalParentRow1DescriptionField;

    @FindBy(id = "idWizardForm:idGoodsAndServicesStepGoodsAndServicesUserEnteredTable:0:idGoodsAndServicesStepGoodsAndServicesUserEnteredEditBtn")
    private WebElement divisionalChildRow1EditLink;

    @FindBy(id = "idWizardForm:idGoodsAndServicesStepGoodsAndServicesUserEnteredDescriptionField")
    private WebElement divisionalChildEnterDescTextField;

    @FindBy(id = "idWizardForm:idGoodsAndServicesStepSaveGoodsAndServicesBtn")
    private WebElement divisionalChildSaveDescButton;

    // Defensive
    @FindBy(name = "idWizardForm:idDefensiveMarkIndicator")
    private List<WebElement> defensiveGroup;

    @FindBy(id = "idWizardForm:defensiveParentIdentifier")
    private WebElement defensiveParentTMTextField;

    @FindBy(id = "idWizardForm:idDefensiveParentSaveBtn")
    private WebElement defensiveTMSaveButton;

    @FindBy(id = "idWizardForm:idDefensiveTradeMarkEvidenceFileUpload")
    private WebElement browseFilesDefensive;

    @FindBy(id = "idWizardForm:idDefensiveTradeMarkEvidenceFileUploadFileUploadButton")
    private WebElement attachFileDefensive;

    // Certification
    @FindBy(name = "idWizardForm:idCertificationMarkIndicator")
    private List<WebElement> certificationGroup;

    @FindBy(id = "idWizardForm:FileUpload")
    private WebElement browseFilesCertification;

    @FindBy(id = "idWizardForm:FileUploadFileUploadButton")
    private WebElement attachFileCertification;

    // Collective
    @FindBy(name = "idWizardForm:idCollectiveMarkIndicator")
    private List<WebElement> collectiveGroup;

    // Limitations
    @FindBy(name = "idWizardForm:conditionsOrLimitationsIndicator")
    private List<WebElement> limitationsGroup;

    @FindBy(id = "idWizardForm:conditionsOrLimitations")
    private WebElement limitationsTextField;

    public TradeMarksNewAppAdditionalDetails(WebDriver driver) {
        super(driver);
    }

    // Non English content
    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails selectNonEnglishContentRadioButton() {
        String word = getDataValue(TradeMarkParameters.FOREIGN_WORD_LANG.getValue()).trim();
        String chararcter = getDataValue(TradeMarkParameters.FOREIGN_CHARACTER.getValue()).trim();
        String value = "";

        if ("".equals(word) && "".equals(chararcter)) {
            value = FALSE;
        }
        else {
            value = "true";
        }
        return selectNonEnglishContentRadioButton(value);
    }

    /**
     * @param value
     *            ...
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails selectNonEnglishContentRadioButton(String value) {
        for (WebElement el : containsNonEnglishRadioGroup) {
            if (value.equals(el.getAttribute(VALUE))) {
                if (!el.isSelected()) {
                    el.click();
                }
                break;
            }
        }
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails selectContainsForeignWordsCheckBox() {
        String word = getDataValue(TradeMarkParameters.FOREIGN_WORD_LANG.getValue()).trim();
        if (!word.equals("")) {
            (new WebDriverWait(driver,
                    timeout)).until(ExpectedConditions.elementToBeClickable(containsForeignWordsCheckBox));
            if (!containsForeignWordsCheckBox.isSelected()) {
                containsForeignWordsCheckBox.click();
                waitWhileEServicesBusy();
            }

        }
        return this;

    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails setForeignLanguageTextField() {
        String word = getDataValue(TradeMarkParameters.FOREIGN_WORD_LANG.getValue()).trim();
        if (!word.equals("")) {
            return setForeignLanguageTextField(word);

        }
        else {
            return this;
        }
    }

    /**
     * @param word
     *            ...
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails setForeignLanguageTextField(String word) {
        foreignLanguageTextField.click();
        foreignLanguageTextField.sendKeys(word);
        return null;
    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails setForeignWordsTestField() {
        String word = getDataValue(TradeMarkParameters.FOREIGN_WORDS.getValue()).trim();
        if (!word.equals("")) {
            return setForeignWordsTestField(word);

        }
        else {
            return this;
        }
    }

    /**
     * @param word
     *            ...
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails setForeignWordsTestField(String word) {
        foreignWordsTestField.click();
        foreignWordsTestField.sendKeys(word);
        return this;
    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails setTranslatedWordsTextField() {
        String word = getDataValue(TradeMarkParameters.TRANSLATION.getValue()).trim();
        if (!word.equals("")) {
            return setTranslatedWordsTextField(word);

        }
        else {
            return this;
        }
    }

    /**
     * @param word
     *            ...
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails setTranslatedWordsTextField(String word) {
        translatedWords.click();
        translatedWords.sendKeys(word);
        return this;
    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails populateNonEnglishWordsFields() {
        if (!getDataValue(TradeMarkParameters.FOREIGN_WORD_LANG.getValue()).trim().equals("")) {
            selectNonEnglishContentRadioButton("true");
            selectContainsForeignWordsCheckBox();
            setForeignLanguageTextField();
            setForeignWordsTestField();
            setTranslatedWordsTextField();
        }
        return this;
    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails selectContainsForeignCharatersCheckBox() {
        String word = getDataValue(TradeMarkParameters.FOREIGN_CHARACTER.getValue()).trim();
        if (!word.equals("")) {
            (new WebDriverWait(driver,
                    timeout)).until(ExpectedConditions.elementToBeClickable(containsForeignCharatersCheckBox));
            if (!containsForeignCharatersCheckBox.isSelected()) {
                containsForeignCharatersCheckBox.click();
                waitWhileEServicesBusy();
            }

        }
        return this;

    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails setForeignCharTextField() {
        String character = getDataValue(TradeMarkParameters.FOREIGN_CHARACTER.getValue()).trim();
        if (!character.equals("")) {
            return setForeignCharTextField(character);

        }
        else {
            return this;
        }
    }

    /**
     * @param character
     *            ...
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails setForeignCharTextField(String character) {
        foreignCharTextField.click();
        foreignCharTextField.sendKeys(character);
        return null;
    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails setForeignCharTransliteredAsTextField() {
        String word = getDataValue(TradeMarkParameters.TRAMSLITERED_CHAR.getValue()).trim();
        if (!word.equals("")) {
            return setForeignCharTransliteredAsTextField(word);

        }
        else {
            return this;
        }
    }

    /**
     * @param word
     *            ...
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails setForeignCharTransliteredAsTextField(String word) {
        foreignCharTransliteredAsTextField.click();
        foreignCharTransliteredAsTextField.sendKeys(word);
        return this;
    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails setForeignCharTranslatedAsTextField() {
        String word = getDataValue(TradeMarkParameters.TRANSLATED_CHAR.getValue()).trim();
        if (!word.equals("")) {
            return setForeignCharTranslatedAsTextField(word);

        }
        else {
            return this;
        }
    }

    /**
     * @param word
     *            ...
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails setForeignCharTranslatedAsTextField(String word) {
        foreignCharTranslatedAsTextField.click();
        foreignCharTranslatedAsTextField.sendKeys(word);
        return this;
    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails populateNonEnglishCharactersFields() {
        if (!getDataValue(TradeMarkParameters.FOREIGN_CHARACTER.getValue()).trim().equals("")) {
            selectNonEnglishContentRadioButton("true");
            selectContainsForeignCharatersCheckBox();
            setForeignCharTextField();
            setForeignCharTransliteredAsTextField();
            setForeignCharTranslatedAsTextField();
        }
        return this;
    }

    // Convention Claim
    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails selectConvClaimRadioButton() {
        String convCountry = getDataValue(TradeMarkParameters.CONV_COUNTRY.getValue()).trim();
        String value = "";

        if (convCountry.equals("")) {
            value = FALSE;
        }
        else {
            value = "true";
        }
        return selectConvClaimRadioButton(value);
    }

    /**
     * @param value
     *            ...
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails selectConvClaimRadioButton(String value) {
        for (WebElement el : convClaimGroup) {
            if (el.getAttribute(VALUE).equals(value)) {
                if (!el.isSelected()) {
                    el.click();
                }
                break;
            }
        }
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails setConvClaimTMNumberTextField() {
        String tmNum = getDataValue(TradeMarkParameters.CONV_TM_NUMBER.getValue()).trim();
        if (!tmNum.equals("")) {
            return setConvClaimTMNumberTextField(tmNum);
        }
        else {
            return this;
        }
    }

    /**
     * @param trademarkNumber
     *            ..
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails setConvClaimTMNumberTextField(String trademarkNumber) {
        (new WebDriverWait(driver,
                timeout)).until(ExpectedConditions.elementToBeClickable(containsForeignCharatersCheckBox));
        convClaimTMNumberTextField.click();
        convClaimTMNumberTextField.sendKeys(trademarkNumber);
        return null;
    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails setConvCountryDropDownList() {
        String country = getDataValue(TradeMarkParameters.CONV_COUNTRY.getValue()).trim();
        if (!country.equals("")) {
            return setConvCountryDropDownList(country);
        }
        else {
            return this;
        }
    }

    /**
     * @param countryValue
     *            ...
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails setConvCountryDropDownList(String countryValue) {
        new Select(convClaimCountrySelectList).selectByVisibleText(countryValue);
        return this;
    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails setConvClaimLodgeDateTextField() {
        String formatDate = dateFromLocal(10);

        if (!formatDate.equals("")) {
            return setConvClaimLodgeDateTextField(formatDate);
        }
        else {
            return this;
        }
    }

    /**
     * @param date
     *            ...
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails setConvClaimLodgeDateTextField(String date) {
        convClaimLodgeDateTextField.click();
        convClaimLodgeDateTextField.sendKeys(date);
        return this;
    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails clickConcClaimGoodsAndServicesLink() {
        if (!getDataValue(TradeMarkParameters.CONV_GS_DESC.getValue()).equals("")) {
            concClaimGoodsAndServicesLink.click();
            waitWhileEServicesBusy();
        }
        return this;
    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails setConvClaimClassNumberTextField() {
        String convClass = getDataValue(TradeMarkParameters.CONV_GS_CLASS.getValue()).trim();
        if (!convClass.equals("")) {
            return setConvClaimClassNumberTextField(convClass);
        }
        else {
            return this;
        }
    }

    /**
     * @param classNo
     *            ...
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails setConvClaimClassNumberTextField(String classNo) {
        (new WebDriverWait(driver,
                timeout)).until(ExpectedConditions.elementToBeClickable(convClaimClassNumberTextField));
        convClaimClassNumberTextField.click();
        convClaimClassNumberTextField.sendKeys(classNo);
        return this;
    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails setConvClaimGandSDescTextField() {
        String desc = getDataValue(TradeMarkParameters.CONV_GS_DESC.getValue()).trim();
        if (!desc.equals("")) {
            return setConvClaimGandSDescTextField(desc);
        }
        else {
            return this;
        }
    }

    /**
     * @param desc
     *            description
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    private TradeMarksNewAppAdditionalDetails setConvClaimGandSDescTextField(String desc) {
        (new WebDriverWait(driver,
                timeout)).until(ExpectedConditions.elementToBeClickable(convClaimGandSDescTextField));
        convClaimGandSDescTextField.click();
        convClaimGandSDescTextField.sendKeys(desc);
        return this;
    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails clickConvClaimSaveGandSButton() {
        String desc = getDataValue(TradeMarkParameters.CONV_GS_DESC.getValue()).trim();
        if (!desc.equals("")) {
            convClaimSaveGandSButton.click();
            waitWhileEServicesBusy();
        }
        return this;
    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails clickSaveConvClaimButton() {
        String convCountry = getDataValue(TradeMarkParameters.CONV_COUNTRY.getValue()).trim();
        if (!convCountry.equals("")) {
            saveConvClainButton.click();
            waitWhileEServicesBusy();
        }
        return this;
    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails populateConvClaimFields() {
        if (!getDataValue(TradeMarkParameters.CONV_COUNTRY.getValue()).trim().equals("")) {
            selectConvClaimRadioButton("true");
            setConvClaimTMNumberTextField();
            setConvCountryDropDownList();
            setConvClaimLodgeDateTextField();
            clickConcClaimGoodsAndServicesLink();
            setConvClaimClassNumberTextField();
            setConvClaimGandSDescTextField();
            clickConvClaimSaveGandSButton();
            clickSaveConvClaimButton();
        }

        return this;
    }

    // Divisional
    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails selectDivisionalRadioButton() {
        String number = getDataValue(TradeMarkParameters.DIVISIONAL_PARENT_NO.getValue()).trim();
        String value = "";

        if ("".equals(number)) {
            value = FALSE;
        }
        else {
            value = "true";
        }
        return selectDivisionalRadioButton(value);
    }

    /**
     * @param value
     *            ...
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails selectDivisionalRadioButton(String value) {
        for (WebElement el : divisionalGroup) {
            if (el.getAttribute(VALUE).equals(value)) {
                if (!el.isSelected()) {
                    el.click();
                }
                break;
            }
        }
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails setDivisionalParentNumberTextField() {
        if (!getDataValue(TradeMarkParameters.DIVISIONAL_PARENT_NO.getValue()).trim().equals("")) {
            String tmNumber = "";
            divisionalParentNumberTextField.sendKeys(tmNumber);
            retrieveDetailsButton.click();
            waitWhileEServicesBusy();
        }
        return this;
    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    private String getDivisionalParentRow1DDescription() {
        return divisionalParentRow1DescriptionField.getText();
    }

    /**
     * @param description
     *            ...
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    private TradeMarksNewAppAdditionalDetails setDivisionalChildRow1DescriptionField(String description) {
        divisionalChildRow1EditLink.click();
        waitWhileEServicesBusy();
        divisionalChildEnterDescTextField.sendKeys(description);
        divisionalChildSaveDescButton.click();
        waitWhileEServicesBusy();

        return this;

    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    private TradeMarksNewAppAdditionalDetails removeAdditionalChildClasses() {
        for (int i = 1; i < 6; i++) {
            WebElement removeLink;
            try {
                removeLink =
                        driver.findElement(By.id("idWizardForm:idGoodsAndServicesStepGoodsAndServicesUserEnteredTable:1:idGoodsAndServicesStepGoodsAndServicesUserEnteredRemoveBtn"));
                (new WebDriverWait(driver, 1)).until(ExpectedConditions.elementToBeClickable(removeLink));
                removeLink.click();
                waitWhileEServicesBusy();
            }
            catch (NoSuchElementException e) {
                LOGGER.info("No Element found", e);
                break;
            }
        }
        return this;
    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails populateDivisionalAppFields() {
        if (!getDataValue(TradeMarkParameters.DIVISIONAL_PARENT_NO.getValue()).trim().equals("")) {
            selectDivisionalRadioButton("true");
            setDivisionalParentNumberTextField();
            (new WebDriverWait(driver,
                    timeout)).until(ExpectedConditions.elementToBeClickable(divisionalChildRow1EditLink));
            String desc = getDivisionalParentRow1DDescription();
            String[] badCharacters = { "\\[", "\\]" };
            for (String bad : badCharacters) {
                desc = desc.replaceAll(bad, "");
            }
            setDivisionalChildRow1DescriptionField(desc);

            removeAdditionalChildClasses();
        }
        return this;
    }

    // Defensive
    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails selectDefensiveRadioButton() {
        String value = "";
        if ("".equals(getDataValue(TradeMarkParameters.DEFENSIVE_TM_NUMBER.getValue()).trim())) {
            value = FALSE;
        }
        else {
            value = "true";
        }
        return selectDefensiveRadioButton(value);
    }

    /**
     * @param value
     *            ...
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails selectDefensiveRadioButton(String value) {
        for (WebElement el : defensiveGroup) {
            if (el.getAttribute(VALUE).equals(value)) {
                if (!el.isSelected()) {
                    el.click();
                }
                break;
            }
        }
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails setDefensiveParentTMTextField() {
        if (!getDataValue(TradeMarkParameters.DEFENSIVE_TM_NUMBER.getValue()).trim().equals("")) {
            String tmNumber = getTMNumber(TradeMarkParameters.DEFENSIVE_TM_NUMBER.getValue());
            defensiveParentTMTextField.sendKeys(tmNumber);
            defensiveTMSaveButton.click();
            waitWhileEServicesBusy();
        }
        return this;
    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails clickDefensiveTMSaveButton() {
        defensiveTMSaveButton.click();
        return this;
    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails addFileDefensive() {
        String file = getDataValue(TradeMarkParameters.DEFENSIVE_FILE.getValue()).trim();
        if (!file.equals("")) {
            addFileDefensive(file);
        }
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * @param fileName
     *            ...
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails addFileDefensive(String fileName) {

        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(browseFilesDefensive));

        addFilesCommon(fileName);

        waitWhileEServicesBusy();

        return this;

    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails populateDefensiveMarkFields() {
        if (!getDataValue(TradeMarkParameters.DEFENSIVE_TM_NUMBER.getValue()).trim().equals("")) {
            selectDefensiveRadioButton();
            setDefensiveParentTMTextField();
            addFileDefensive();
        }
        return this;
    }

    // Certification
    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails selectCertificationRadioButton() {
        String mark = getDataValue(TradeMarkParameters.CERTIFICATION_MARK.getValue()).trim();
        String value = "";

        if ("".equals(mark) || "NO".equalsIgnoreCase(mark)) {
            value = FALSE;
        }
        else {
            value = "true";
        }
        return selectCertificationRadioButton(value);
    }

    /**
     * @param value
     *            ...
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails selectCertificationRadioButton(String value) {
        for (WebElement el : certificationGroup) {
            if (el.getAttribute(VALUE).equals(value)) {
                if (!el.isSelected()) {
                    el.click();
                }
                break;
            }
        }
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails addFileCertification() {
        String file = getDataValue(TradeMarkParameters.CERTIFICATION_MARK_FILE.getValue()).trim();
        if (!file.equals("")) {
            addFileCertification(file);
        }
        return this;
    }

    /**
     * @param fileName
     *            ...
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails addFileCertification(String fileName) {

        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(browseFilesCertification));

        addFilesCommon(fileName);

        waitWhileEServicesBusy();

        return this;

    }

    // Collective
    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails selectCollectiveRadioButton() {
        String mark = getDataValue(TradeMarkParameters.COLLECTIVE_MARK.getValue()).trim();
        String value = "";

        if ("".equals(mark) || "NO".equalsIgnoreCase(mark)) {
            value = FALSE;
        }
        else {
            value = "true";
        }
        return selectCollectiveRadioButton(value);
    }

    /**
     * @param value
     *            ...
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails selectCollectiveRadioButton(String value) {
        for (WebElement el : collectiveGroup) {
            if (el.getAttribute(VALUE).equals(value)) {
                if (!el.isSelected()) {
                    el.click();
                }
                break;
            }
        }
        waitWhileEServicesBusy();
        return this;
    }

    // Limitations
    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails selectLimitationsRadioButton() {
        String limit = getDataValue(TradeMarkParameters.LIMITATIONS.getValue()).trim();
        String value = "";

        if ("".equals(limit)) {
            value = FALSE;
        }
        else {
            value = "true";
        }
        return selectLimitationsRadioButton(value);
    }

    /**
     * @param value
     *            ...
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails selectLimitationsRadioButton(String value) {
        for (WebElement el : limitationsGroup) {
            if (el.getAttribute(VALUE).equals(value)) {
                if (!el.isSelected()) {
                    el.click();
                }
                break;
            }
        }
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails setLimitationsTextField() {
        String limit = getDataValue(TradeMarkParameters.LIMITATIONS.getValue()).trim();
        if (!limit.equals("")) {
            return setLimitationsTextField(limit);
        }
        else {
            return this;
        }
    }

    /**
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails populateLimitationsFields() {
        if (!getDataValue(TradeMarkParameters.LIMITATIONS.getValue()).trim().equals("")) {
            selectLimitationsRadioButton("true");
            setLimitationsTextField();
        }
        return this;
    }

    /**
     * @param limit
     *            ...
     * @return TradeMarksNewApp_AdditionalDetails instance
     */
    public TradeMarksNewAppAdditionalDetails setLimitationsTextField(String limit) {
        limitationsTextField.click();
        limitationsTextField.sendKeys(limit);
        return this;
    }

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

}
