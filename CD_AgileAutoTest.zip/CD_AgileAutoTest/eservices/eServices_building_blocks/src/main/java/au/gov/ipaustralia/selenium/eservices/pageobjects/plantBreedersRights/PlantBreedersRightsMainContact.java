package au.gov.ipaustralia.selenium.eservices.pageobjects.plantBreedersRights;

import org.openqa.selenium.WebDriver;

import au.gov.ipaustralia.selenium.eservices.pageobjects.common.BasePageEServices;

public class PlantBreedersRightsMainContact extends BasePageEServices {

    private static final String PAGE_TITLE = "MAIN CONTACT";
    private static final String PAGE_URL =
            "\\/ICMWebUI\\/views\\/private\\/eservices\\/pbr\\/new-application\\/new-app-wizard.xhtml";

    public PlantBreedersRightsMainContact(WebDriver driver) {
        super(driver);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }
}
