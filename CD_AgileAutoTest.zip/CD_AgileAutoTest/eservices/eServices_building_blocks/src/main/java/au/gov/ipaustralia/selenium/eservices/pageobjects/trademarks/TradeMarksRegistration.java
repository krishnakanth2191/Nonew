package au.gov.ipaustralia.selenium.eservices.pageobjects.trademarks;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import au.gov.ipaustralia.automation.selenium.helpers.db.ATMOSSDBManager;

/**
 * Models the click and populate tasks of Registering a Trade Mark in eServices
 * 
 * @author Danielle Orth - 04/10/2017
 *
 */
public class TradeMarksRegistration extends TradeMarksBasePage {

    private static final Logger LOGGER = Logger.getLogger(TradeMarksRegistration.class);
    private static final String PAGE_TITLE = "Trade mark registration";
    private static final String PAGE_URL =
        "\\/ICMWebUI\\/views\\/private\\/eservices\\/trademark\\/registration\\/tm-registration-wizard\\.xhtml";

    @FindBy(id = "idWizardForm:idFldIpRightNumber")
    private WebElement tradeMarkTextField;

    @FindBy(id = "idWizardForm:idAddIpRightAction")
    private WebElement registrationAddButton;

    @FindBy(id = "idWizardForm:idBtnACTION_ID_ADD_TO_CART")
    private WebElement registrationAddToCartButton;

    @FindBy(id = "singleMessageText")
    private WebElement errorMessage;
    
    @FindBy(id = "idWizardForm:idWizWarnDialogBtnCancel")
    private WebElement cancelAlertMessageBtn;

    public TradeMarksRegistration(WebDriver driver) {
        super(driver);
    }

    /**
     * Search the database for a TM number that needs registering (e.g. status 20. Approved)
     * 
     * @return TM Number in IP Right Number Text Field
     */
    public TradeMarksRegistration setTradeMarkTextField() {
        String tmNumber = (new ATMOSSDBManager().getUnRegisteredTradeMarkID().getFirstDataItem().toString());
        LOGGER.info(tmNumber);
        tradeMarkTextField.clear();
        tradeMarkTextField.sendKeys(tmNumber);
        return this;
    }

    /**
     * Click 'Add' button (wait for eServices loads the information)
     * 
     * @return TM Registration object updated to display registration information
     */
    public TradeMarksRegistration clickAddButton() {
        registrationAddButton.click();
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * Click 'Add To Cart' button. (wait for eServices 'Add to Cart' button to be clickable)
     * 
     * @return TM Registration object updated with registration information prior to being paid
     */
    public TradeMarksRegistration clickAddToCartButton() {
        (new WebDriverWait(driver, timeout))
            .until(ExpectedConditions.elementToBeClickable(registrationAddToCartButton));
        registrationAddToCartButton.click();
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * Check for Error Messages
     * 
     * @return No Error Messages - T/F
     */
    public boolean noErrorMessages() {
        if (registrationAddToCartButton.isEnabled()) {
            LOGGER.info("Valid TM number found");
            return true;
        }
        else {
            LOGGER.info(errorMessage.getText());
            
            if(driver.findElement(By.xpath(".//*[@class='alertMessage cancel']")).isDisplayed()){
                cancelAlertMessageBtn.click();
            }
            return false;
        }
    }

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }
}
