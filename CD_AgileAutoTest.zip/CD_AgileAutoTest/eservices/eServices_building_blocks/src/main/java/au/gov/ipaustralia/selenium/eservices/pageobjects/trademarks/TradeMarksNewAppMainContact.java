package au.gov.ipaustralia.selenium.eservices.pageobjects.trademarks;

import org.openqa.selenium.WebDriver;

public class TradeMarksNewAppMainContact extends TradeMarksBasePage {

    private static final String PAGE_TITLE = "MAIN CONTACT";
    private static final String PAGE_URL =
            "\\/ICMWebUI\\/views\\/private\\/eservices\\/trademark\\/new-trademark\\/new-tm-wizard.xhtml";

    public TradeMarksNewAppMainContact(WebDriver driver) {
        super(driver);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

}
