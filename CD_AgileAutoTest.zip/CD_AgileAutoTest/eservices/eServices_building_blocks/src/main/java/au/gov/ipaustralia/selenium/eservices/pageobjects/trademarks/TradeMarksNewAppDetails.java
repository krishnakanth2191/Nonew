/**
 * 
 */
package au.gov.ipaustralia.selenium.eservices.pageobjects.trademarks;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * @author Anthony Hallett
 *
 */
public class TradeMarksNewAppDetails extends TradeMarksBasePage {
    private static final String PAGE_TITLE = "TRADE MARK DETAILS";
    private static final String PAGE_URL =
            "\\/ICMWebUI\\/views\\/private\\/eservices\\/trademark\\/.*\\/.*wizard.xhtml";

    private static final String VALUE = "value";
    private static final String OTHER = "OTHER";

    @FindBy(name = "idWizardForm:trademarkCategoryDescription")
    private List<WebElement> tradeMarkTypeGroup;

    @FindBy(id = "idWizardForm:wordOrPhraseDescribingTrademark")
    private WebElement plainWord;

    @FindBy(name = "idWizardForm:trademarkOtherCategoryDescription")
    private List<WebElement> otherCategoryGroup;

    @FindBy(id = "idWizardForm:shapeDescriptionOne")
    private WebElement shapeDscriptionTextField;

    @FindBy(id = "idWizardForm:colourDescriptionOne")
    private WebElement coloursTextField;

    @FindBy(id = "idWizardForm:colourDescriptionTwo")
    private WebElement colourDescriptionTextField;

    @FindBy(id = "idWizardForm:soundDescriptionOne")
    private WebElement soundDescriptionTextField;

    @FindBy(id = "idWizardForm:movementDescriptionOne")
    private WebElement movementDescriptionTextField;

    @FindBy(id = "idWizardForm:otherDescriptionOneLabel")
    private WebElement otherDescriptionTextField;

    @FindBy(name = "idWizardForm:trademarkCategorySeriesIndicator")
    private List<WebElement> tradeMarkSeriesTypeGroup;

    @FindBy(id = "idWizardForm:idTrademarkConfirmSeries")
    private WebElement confirmSeries;

    @FindBy(id = "idWizardForm:idNumberOfTrademarksSelect")
    private WebElement selectSeriesNum;

    @FindBy(name = "idWizardForm:tradeMarkSeriesTypeSelect")
    private List<WebElement> tradeMarkSeriesApplicationGroup;

    @FindBy(name = "idWizardForm:tmDetailsSeriesTextList")
    private WebElement seriesAddText;

    @FindBy(id = "idWizardForm:tmDetailsSeriesTextAddBtn")
    private WebElement seriesAddTxtButton;

    @FindBy(id = "idWizardForm:tmDetailsSeriesFileBrowseAndAttach")
    private WebElement seriesAddBrowseFiles;

    @FindBy(id = "idWizardForm:tmDetailsSeriesFileBrowseAndAttachFileUploadButton")
    private WebElement seriesAttachButton;

    @FindBy(id = "idWizardForm:tmDetailsSeriesFileAddBtn")
    private WebElement seriesAddButton;

    @FindBy(name = "idWizardForm:tmSeriesDifferentColoursIndicator")
    private List<WebElement> seriesDiffColorGroup;

    @FindBy(id = "idWizardForm:idColourSeriesDescriptionField")
    private WebElement seriesDiffColorDescription;

    public TradeMarksNewAppDetails(WebDriver driver) {
        super(driver);
    }

    /**
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails setTMTypeRadioButtonField() {
        return setTMTypeRadioButtonField(getDataValue(TradeMarkParameters.TRADEMARK_TYPE.getValue()));
    }

    /**
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails addFile() {
        String fileName = getDataValue(TradeMarkParameters.ATTACHMENT_FILE.getValue()).trim();
        if (!fileName.equals("")) {
            addFilesCommon(fileName);
        }
        return this;
    }

    /**
     * Set default value to One Word Or One Phrase In Stylised Text E.g. Example Radio Button field.
     *
     * @param type
     *            ...
     * @return the TradeMarksNewApp_Details class instance.
     */
    public TradeMarksNewAppDetails setTMTypeRadioButtonField(String type) {
        for (WebElement el : tradeMarkTypeGroup) {
            if (el.getAttribute(VALUE).equals(type)) {
                if (!el.isSelected()) {
                    el.click();
                    waitWhileEServicesBusy();
                }
                break;
            }
        }
        return this;
    }

    /**
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails setPlainWordTextField() {
        String word = getDataValue(TradeMarkParameters.PLAIN_WORD.getValue());
        if (!word.trim().equals("")) {
            return setPlainWordTextField(getDataValue(TradeMarkParameters.PLAIN_WORD.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * @param dataValue
     *            the plain word text
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails setPlainWordTextField(String dataValue) {
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(plainWord));
        plainWord.click();
        plainWord.sendKeys(dataValue);
        return this;
    }

    /**
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails setOtherCategoryRadioButton() {
        return setOtherCategoryRadioButton(getDataValue(TradeMarkParameters.TRADEMARK_TYPE.getValue()));
    }

    /**
     * @param category
     *            ...
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails setOtherCategoryRadioButton(String category) {
        for (WebElement el : otherCategoryGroup) {
            if (el.getAttribute(VALUE).equals(category)) {
                if (!el.isSelected()) {
                    el.click();
                }
                break;
            }
        }
        return this;
    }

    /**
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails setShapeDescTextField() {
        String desc = getDataValue(TradeMarkParameters.DESCRIPTION_FIELD1.getValue()).trim();
        if (!desc.equals("")) {
            return setShapeDescTextField(desc);

        }
        else {
            return this;
        }
    }

    /**
     * @param descriptiuon
     *            ...
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails setShapeDescTextField(String descriptiuon) {
        shapeDscriptionTextField.click();
        shapeDscriptionTextField.sendKeys(descriptiuon);
        return this;
    }

    /**
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails setColoursTextField() {
        String colours = getDataValue(TradeMarkParameters.DESCRIPTION_FIELD1.getValue()).trim();
        if (!colours.equals("")) {
            return setColoursTextField(colours);

        }
        else {
            return this;
        }
    }

    /**
     * @param colours
     *            ...
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails setColoursTextField(String colours) {
        coloursTextField.click();
        coloursTextField.sendKeys(colours);
        return this;
    }

    /**
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails setColourDescTextField() {
        String desc = getDataValue(TradeMarkParameters.DESCRIPTION_FIELD2.getValue()).trim();
        if (!desc.equals("")) {
            return setColourDescTextField(desc);

        }
        else {
            return this;
        }
    }

    /**
     * @param description
     *            ...
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails setColourDescTextField(String description) {
        colourDescriptionTextField.click();
        colourDescriptionTextField.sendKeys(description);
        return this;
    }

    /**
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails setSoundDescTextField() {
        String desc = getDataValue(TradeMarkParameters.DESCRIPTION_FIELD1.getValue()).trim();
        if (!desc.equals("")) {
            return setSoundDescTextField(desc);

        }
        else {
            return this;
        }
    }

    /**
     * @param descriptiuon
     *            ...
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails setSoundDescTextField(String descriptiuon) {
        soundDescriptionTextField.click();
        soundDescriptionTextField.sendKeys(descriptiuon);
        return this;
    }

    public TradeMarksNewAppDetails setMovementDescTextField() {
        String desc = getDataValue(TradeMarkParameters.DESCRIPTION_FIELD1.getValue()).trim();
        if (!desc.equals("")) {
            return setMovementDescTextField(desc);

        }
        else {
            return this;
        }
    }

    /**
     * @param descriptiuon
     *            ...
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails setMovementDescTextField(String descriptiuon) {
        movementDescriptionTextField.click();
        movementDescriptionTextField.sendKeys(descriptiuon);
        return this;
    }

    /**
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails setOtherDescTextField() {
        String desc = getDataValue(TradeMarkParameters.DESCRIPTION_FIELD1.getValue()).trim();
        if (!desc.equals("")) {
            return setOtherDescTextField(desc);

        }
        else {
            return this;
        }
    }

    /**
     * @param description
     *            ...
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails setOtherDescTextField(String description) {
        otherDescriptionTextField.click();
        otherDescriptionTextField.sendKeys(description);
        return this;
    }

    /**
     * @param type
     *            ...
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails setTMSeriesTypeRadioButtonField(String type) {
        for (WebElement el : tradeMarkSeriesTypeGroup) {
            if (el.getAttribute(VALUE).equals(type)) {
                if (!el.isSelected()) {
                    el.click();
                }
                break;
            }
        }
        return this;
    }

    /**
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails setTradeMarksconfirmSeries() {
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(confirmSeries));
        confirmSeries.click();
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails setTradeMarksselectSeriesNum() {
        String num = getDataValue(TradeMarkParameters.SERIES_NUM.getValue());
        if (!num.trim().equals("")) {
            return setSereisNum(getDataValue(TradeMarkParameters.SERIES_NUM.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * @param dataValue
     *            ...
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails setSereisNum(String dataValue) {
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(selectSeriesNum));
        selectSeriesNum.sendKeys(dataValue);
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails setSeriesApplicationRadioButton() {
        String num = getDataValue(TradeMarkParameters.SERIES_TYPE.getValue());
        if (!num.trim().equals("")) {
            return seriesApplicationRadioButton(getDataValue(TradeMarkParameters.SERIES_TYPE.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * @param type
     *            ...
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails seriesApplicationRadioButton(String type) {
        for (WebElement el : tradeMarkSeriesApplicationGroup) {
            if (el.getAttribute(VALUE).equals(type)) {
                (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(el));
                if (!el.isSelected()) el.click();
            }
        }

        return this;

    }

    /**
     * @param word
     *            ...
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails addTMseriesAddText(String word) {
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(seriesAddText));
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeSelected(seriesAddText));
        seriesAddText.click();
        seriesAddText.sendKeys(word);

        return this;
    }

    /**
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails clickTMseriesAddTxtButton() {
        seriesAddTxtButton.click();
        return this;
    }

    /**
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails addSereisPlainWord() {
        if (!getDataValue(TradeMarkParameters.SERIES_PLAIN_WORD.getValue()).trim().equals("")) {
            String[] word = getDataValue(TradeMarkParameters.SERIES_PLAIN_WORD.getValue()).split("\n");

            for (int i = 0; i < word.length; i++) {
                String tbID = "idWizardForm:tmDetailsSeriesTextList:" + i + ":tmDetailsSeriesTextInput";

                WebElement textBox = driver.findElement(By.id(tbID));
                (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(textBox));
                textBox.sendKeys(word[i]);

                if (i < word.length - 1) {
                    clickTMseriesAddTxtButton();
                    waitWhileEServicesBusy();
                }
            }
        }

        return this;
    }

    /**
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails setSeriesDiffColoursRadioButton() {
        String color = getDataValue(TradeMarkParameters.SERIES_DIFF_COLOR.getValue());
        if (!color.trim().equals("")) {
            return setSeriesDiffColoursRadioButton(getDataValue(TradeMarkParameters.SERIES_DIFF_COLOR.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * @param type
     *            ...
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails setSeriesDiffColoursRadioButton(String type) {
        for (WebElement el : seriesDiffColorGroup) {

            if (el.getAttribute(VALUE).equals(type)) {
                (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(el));
                if (!el.isSelected()) el.click();

            }
        }

        return this;

    }

    /**
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails setSeriesColoursTextField() {
        String colours = getDataValue(TradeMarkParameters.DESCRIPTION_FIELD1.getValue()).trim();
        if (!colours.equals("")) {
            return setSeriesColoursTextField(colours);

        }
        else {
            return this;
        }
    }

    /**
     * @param descriptiuon
     *            ...
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails setSeriesColoursTextField(String descriptiuon) {
        seriesDiffColorDescription.click();
        seriesDiffColorDescription.sendKeys(descriptiuon);
        return this;
    }

    /**
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails setSeriesColoursOption() {
        if (!getDataValue(TradeMarkParameters.SERIES_DIFF_COLOR.getValue()).trim().equals("")) {
            String type = getDataValue(TradeMarkParameters.SERIES_DIFF_COLOR.getValue());

            {

                if ("true".equals(type)) {
                    setSeriesColoursTextField();

                }
            }
        }

        return this;

    }

    /**
     * @return TradeMarksNewApp_Details instance
     */
    public TradeMarksNewAppDetails populateTMTypeFields() {
        String type = getDataValue(TradeMarkParameters.TRADEMARK_TYPE.getValue());
        if ("WORD".equals(type)) {
            setTMTypeRadioButtonField(type);
            setPlainWordTextField();
        }
        else if ("FANCY_WORD".equals(type) || "LOGO".equals(type)) {
            setTMTypeRadioButtonField(type);
            addFile();
        }
        else if ("SHAPE".equals(type)) {
            setTMTypeRadioButtonField(OTHER);
            setOtherCategoryRadioButton("SHAPE");
            addFile();
            setShapeDescTextField();
        }
        else if ("COLOUR".equals(type)) {
            setTMTypeRadioButtonField(OTHER);
            setOtherCategoryRadioButton("COLOUR");
            addFile();
            setColoursTextField();
            setColourDescTextField();
        }
        else if ("SOUND".equals(type)) {
            setTMTypeRadioButtonField(OTHER);
            setOtherCategoryRadioButton("SOUND");
            addFile();
            setSoundDescTextField();
        }
        else if ("MOVEMENT".equals(type)) {
            setTMTypeRadioButtonField(OTHER);
            setOtherCategoryRadioButton("MOVEMENT");
            addFile();
            setMovementDescTextField();
        }
        else if (OTHER.equals(type)) {
            setTMTypeRadioButtonField(OTHER);
            setOtherCategoryRadioButton(OTHER);
            addFile();
            setOtherDescTextField();
        }
        else if ("SERIES".equals(type)) {
            setTMTypeRadioButtonField(OTHER);
            setTMSeriesTypeRadioButtonField("False");
            setTradeMarksconfirmSeries();
            setTradeMarksselectSeriesNum();
            setSeriesApplicationRadioButton();

        }

        return this;
    }

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

}
