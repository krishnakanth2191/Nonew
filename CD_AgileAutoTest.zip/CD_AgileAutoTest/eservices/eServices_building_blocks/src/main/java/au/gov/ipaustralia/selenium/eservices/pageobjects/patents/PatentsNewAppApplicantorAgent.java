package au.gov.ipaustralia.selenium.eservices.pageobjects.patents;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PatentsNewAppApplicantorAgent extends PatentBasePage {

    private static final String PAGE_TITLE = "APPLICANT OR AGENT SELECTION";
    private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/eservices\\/patent\\/.*\\/.*";

    @FindBy(id = "idWizardForm:patentNewAppInputCustomerRefNumber")
    private WebElement yourReference;

    public PatentsNewAppApplicantorAgent(WebDriver driver) {
        super(driver);
    }

    public PatentsNewAppApplicantorAgent setYourReferenceTextField(String yourReferenceValue) {
        yourReference.sendKeys(yourReferenceValue);
        return this;
    }

    /**
     * VerifyPageTitle Matches with given title.
     *
     * @return boolean.
     */
    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    /**
     * Verify that the page loaded completely.
     *
     * @return boolean.
     */
    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

}
