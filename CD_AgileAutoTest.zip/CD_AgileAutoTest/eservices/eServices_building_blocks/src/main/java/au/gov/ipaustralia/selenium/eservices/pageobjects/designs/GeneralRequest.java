package au.gov.ipaustralia.selenium.eservices.pageobjects.designs;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Models the GENERAL eSERVICE REQUEST page in eServices
 * 
 * @author Anthony Hallett
 *
 */
public class GeneralRequest extends DesignsBasePage {
    private static final String PAGE_TITLE = "GENERAL eSERVICE REQUEST";
    private static final String PAGE_URL =
            "\\/ICMWebUI\\/views\\/private\\/eservices\\/.*\\/.*-wizard.xhtml";

    @FindBy(id = "idWizardForm:idFldUserRef")
    private WebElement yourReference;

    @FindBy(id = "idWizardForm:idSrHeirarchyDropdownList:0:level")
    private WebElement ipRightType;

    @FindBy(id = "idWizardForm:idSrHeirarchyDropdownList:1:level")
    private WebElement requestCategory;

    @FindBy(id = "idWizardForm:idSrHeirarchyDropdownList:2:level")
    private WebElement requestType;

    public GeneralRequest(WebDriver driver) {
        super(driver);
    }

    /**
     * Set default value to Your Reference Text field.
     *
     * @return the GeneralRequest class instance.
     */
    public GeneralRequest setYourReferenceTextField() {
        String ref = getDataValue("CUSTOMER_REFERENCE").trim();
        if (!ref.equals("")) {
            return setYourReferenceTextField(ref);
        }
        else {
            return this;
        }
    }

    /**
     * Set value to Your Reference Text field.
     * 
     * @param yourReferenceValue
     *            ...
     * @return the GeneralRequest class instance.
     */
    public GeneralRequest setYourReferenceTextField(String yourReferenceValue) {
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(yourReference));
        yourReference.sendKeys(yourReferenceValue);
        return this;
    }

    /**
     * Set value to Ip Right Type Drop Down List field.
     * 
     * @param ipRightTypeValue
     *            'Designs' or 'Trade Marks'
     * @return the GeneralRequest class instance.
     */
    public GeneralRequest setIpRightTypeDropDownListField(String ipRightTypeValue) {
        new Select(ipRightType).selectByVisibleText(ipRightTypeValue);
        return this;
    }

    /**
     * Set default value to Request Category Drop Down List field.
     *
     * @return the GeneralRequest class instance.
     */
    public GeneralRequest setRequestCategoryDropDownListField() {
        String category = getDataValue("REQUEST_CATEGORY");
        if (!category.equals("")) {
            return setRequestCategoryDropDownListField(category);
        }
        else {
            return this;
        }
    }

    /**
     * Set value to Request Category Drop Down List field.
     * 
     * @param requestCategoryValue
     *            ...
     * @return the GeneralRequest class instance.
     */
    public GeneralRequest setRequestCategoryDropDownListField(String requestCategoryValue) {
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(requestCategory));
        new Select(requestCategory).selectByVisibleText(requestCategoryValue);
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * Set default value to Request Type Drop Down List field.
     *
     * @return the GeneralRequest class instance.
     */
    public GeneralRequest setRequestTypeDropDownListField() {
        String type = getDataValue("REQUEST_TYPE");
        if (!type.equals("")) {
            return setRequestTypeDropDownListField(type);
        }
        else {
            return this;
        }
    }

    /**
     * Set value to Request Type Drop Down List field.
     * 
     * @param requestTypeValue
     *            ...
     * @return the GeneralRequest class instance.
     */
    public GeneralRequest setRequestTypeDropDownListField(String requestTypeValue) {
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(requestType));
        new Select(requestType).selectByVisibleText(requestTypeValue);
        waitWhileEServicesBusy();

        return this;
    }

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

}
