package au.gov.ipaustralia.selenium.eservices.pageobjects.common;

/**
 * Calling Enum Values
 * 
 * @author Suresh Thumma
 *
 */
public enum CommonParameters {

                              SKIP_ROW("SKIP_ROW"), USER_NAME("USER_NAME"), ESERVICES("ESERVICES");
    private String header;

    CommonParameters(String value) {
        this.header = value;
    }

    public String getValue() {
        return header;
    }

}
