package au.gov.ipaustralia.selenium.eservices.pageobjects.plantBreedersRights;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import au.gov.ipaustralia.selenium.eservices.pageobjects.common.BasePageEServices;

public class PlantBreedersRightsBreeders extends BasePageEServices {

    private static final String PAGE_TITLE = "BREEDERS";
    private static final String PAGE_URL =
            "\\/ICMWebUI\\/views\\/private\\/eservices\\/pbr\\/new-application\\/new-app-wizard.xhtml";

    public PlantBreedersRightsBreeders(WebDriver driver) {
        super(driver);
    }

    @FindBy(className = "checkbox-question")
    private WebElement checkBox;

    public PlantBreedersRightsBreeders clickCheckBox() {
        checkBox.click();
        return this;
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

}
