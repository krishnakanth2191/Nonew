package au.gov.ipaustralia.selenium.eservices.pageobjects.common;

import static org.assertj.core.api.Assertions.assertThat;

import javax.management.RuntimeErrorException;

import org.apache.log4j.Logger;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import au.gov.ipaustralia.selenium.browser.ThreadSafeWebDriverStorage;

/**
 * Models the PAYMENT page in eServices
 * 
 * @author Anthony Hallett
 *
 */
public class Payment extends BasePageEServices {

    private static final Logger LOGGER = Logger.getLogger(Payment.class);
    private static final String PAGE_TITLE = "PAYMENT";
    private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/home\\/";

    @FindBy(id = "cardHolder")
    @CacheLookup
    private WebElement nameOnCard;

    @FindBy(id = "cardType")
    @CacheLookup
    private WebElement creditCardType;

    @FindBy(id = "cardNumber")
    @CacheLookup
    private WebElement creditCardNumber;

    @FindBy(id = "expiryMonth")
    @CacheLookup
    private WebElement expiryMonth;

    @FindBy(id = "expiryYear")
    @CacheLookup
    private WebElement expiryYear;

    @FindBy(id = "ccv")
    @CacheLookup
    private WebElement ccv;

    @FindBy(id = "payAndSubmit")
    @CacheLookup
    private WebElement paySubmit;

    @FindBy(className = "errorMessage paymentErrorMessage")
    private WebElement paymentErrorMessage;

    public Payment(WebDriver driver) {
        super(driver);

        assertThat(verifyPageUrl()).as("PAYMENT page URL").isTrue();
        assertThat(verifyPageLoaded()).as("PAYMENT page loaded").isTrue();
    }

    /**
     * Set default value to Name On Card Text field.
     *
     * @return the EServices_DesignsNewApp_Payment class instance.
     */
    public Payment setNameOnCardTextField() {
        return setNameOnCardTextField(getDataValue("NAME_ON_CARD"));
    }

    /**
     * Set value to Name On Card Text field.
     * 
     * @param nameOnCardValue
     *            ...
     * @return the EServices_DesignsNewApp_Payment class instance.
     */
    public Payment setNameOnCardTextField(String nameOnCardValue) {
        nameOnCard.sendKeys(nameOnCardValue);
        return this;
    }

    /**
     * Set default value to Credit Card Type Drop Down List field.
     *
     * @return the EServices_DesignsNewApp_Payment class instance.
     */
    public Payment setCreditCardTypeDropDownListField() {
        return setCreditCardTypeDropDownListField(getDataValue("CREDIT_CARD_TYPE"));
    }

    /**
     * Set value to Credit Card Type Drop Down List field.
     * 
     * @param creditCardTypeValue
     *            ...
     * @return the EServices_DesignsNewApp_Payment class instance.
     */
    public Payment setCreditCardTypeDropDownListField(String creditCardTypeValue) {
        new Select(creditCardType).selectByVisibleText(creditCardTypeValue);
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * Set default value to Credit Card Number Text field.
     *
     * @return the EServices_DesignsNewApp_Payment class instance.
     */
    public Payment setCreditCardNumberTextField() {
        return setCreditCardNumberTextField(getDataValue("CREDIT_CARD_NUMBER"));
    }

    /**
     * Set value to Credit Card Number Text field.
     * 
     * @param creditCardNumberValue
     *            ...
     * @return the EServices_DesignsNewApp_Payment class instance.
     */
    public Payment setCreditCardNumberTextField(String creditCardNumberValue) {
        creditCardNumber.sendKeys(creditCardNumberValue);
        return this;
    }

    /**
     * Set default value to Expiry Month Drop Down List field.
     *
     * @return the EServices_DesignsNewApp_Payment class instance.
     */
    public Payment setExpiryMonthDropDownListField() {
        return setExpiryMonthDropDownListField(getDataValue("EXPIRY_MONTH"));
    }

    /**
     * Set value to Expiry Month Drop Down List field.
     * 
     * @param expiryValue
     *            ...
     * @return the EServices_DesignsNewApp_Payment class instance.
     */
    public Payment setExpiryMonthDropDownListField(String expiryValue) {
        new Select(expiryMonth).selectByVisibleText(expiryValue);
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * Set default value to Expiry Year Drop Down List field.
     *
     * @return the EServices_DesignsNewApp_Payment class instance.
     */
    public Payment setExpiryYearDropDownListField() {
        return setExpiryYearDropDownListField(getDataValue("EXPIRY_YEAR"));
    }

    /**
     * Set value to Expiry Month Drop Down List field.
     * 
     * @param expiryValue
     *            ...
     * @return the EServices_DesignsNewApp_Payment class instance.
     */
    public Payment setExpiryYearDropDownListField(String expiryValue) {
        new Select(expiryYear).selectByVisibleText(expiryValue);
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * Set default value to Ccv Text field.
     *
     * @return the EServices_DesignsNewApp_Payment class instance.
     */
    public Payment setCcvTextField() {
        return setCcvTextField(getDataValue("CCV"));
    }

    /**
     * Set value to Ccv Text field.
     * 
     * @param ccvValue
     *            ...
     * @return the EServices_DesignsNewApp_Payment class instance.
     */
    public Payment setCcvTextField(String ccvValue) {
        ccv.sendKeys(ccvValue);
        return this;
    }

    /**
     * Convenience method to complete all fields on the payment screen using data from the provider
     * 
     * @return Payment instance
     */
    public Payment makePayment() {
        setNameOnCardTextField();
        setCreditCardTypeDropDownListField();
        setCreditCardNumberTextField();
        setExpiryMonthDropDownListField();
        setExpiryYearDropDownListField();
        setCcvTextField();
        clickPaySubmitButton();

        return this;
    }

    /**
     * Convenience method to complete all fields on the payment screen using the standard auto test data
     * 
     * @return Payment instance
     */
    public Payment makeDefaultPayment() {
        setNameOnCardTextField("Auto Tester");
        setCreditCardTypeDropDownListField("Visa");
        setCreditCardNumberTextField("4111111111111111");
        setExpiryMonthDropDownListField("03");
        setExpiryYearDropDownListField("2019");
        setCcvTextField("045");

        clickPaySubmitButton();

        return this;
    }

    /**
     * Click on Pay Submit Button.
     *
     * @return the EServices_DesignsNewApp_Payment class instance.
     */
    public Payment clickPaySubmitButton() {
        this.clickA4J(paySubmit);
        waitWhileEServicesBusy();

        return this;
    }

    /**
     * Click on Pay Submit Button.
     *
     * @return the EServices_DesignsNewApp_Payment class instance.
     */
    public Payment clickPaySubmitButtonIE() {
        paySubmit.click();
        return this;
    }

    public boolean verifyPaymentError() {
        boolean match = false;
        if (paymentErrorMessage.isDisplayed()) {
            match = true;
            LOGGER.info("Payment Failed, Test Passed");
        }
        else {
            LOGGER.info("Payment Successful, Test Failed");
        }
        return match;
    }

    public void closeDriver() {
        WebDriver d = driver;
        try {
            if (!d.getTitle().contains("PAYMENT")) {
                throw new RuntimeErrorException(null, "Page not found.");
            }
        }
        catch (NoSuchWindowException e) {
           LOGGER.info("No Element Found", e);

        }
        finally {
            try {
                ThreadSafeWebDriverStorage.quitWebDriver(driver);
            }
            catch (Exception e) {
                LOGGER.info("Driver not Found", e);
            }
        }
        return;
    }

    /**
     * VerifyTables that current page URL matches the expected URL.
     *
     * @return boolean.
     */
    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }
    
    /**
     * VerifyPageTitle Matches with given title.
     *
     * @return boolean.
     */
    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

}
