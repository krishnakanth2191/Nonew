package au.gov.ipaustralia.selenium.eservices.pageobjects.common;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import au.gov.ipaustralia.selenium.environment.EnvironmentVariables;

/**
 * Models the login page in eServices
 * 
 * @author Anthony Hallett
 *
 */
public class Login extends BasePageEServices {

    private static final String PAGE_LOADED_TEXT = "Services";
    private static final String PAGE_URL = "\\/ssoda\\/UI\\/Login\\?realm=\\/IPA_EXTERNAL";

    @FindBy(id = "IDToken1")
    @CacheLookup
    private WebElement username;

    @FindBy(id = "IDToken2")
    @CacheLookup
    private WebElement password;

    @FindBy(id = "IDButton")
    @CacheLookup
    private WebElement loginsubmit;

    @FindBy(css = "a.icmformbutton")
    @CacheLookup
    private WebElement register;

    public Login(WebDriver driver) {
        super(driver);
        openHomePage();
        assertThat(verifyPageUrl()).as("Login page URL").isTrue();
        assertThat(verifyPageLoaded()).as("Login page is loaded").isTrue();
    }

    /**
     * @return Login instance
     */
    public Login setUserName() {
        if (getData().containsKey(CommonParameters.USER_NAME.getValue())) {
            return setUserName(getData().get(CommonParameters.USER_NAME.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * @param name
     *            ...
     * @return Login instance
     */
    public Login setUserName(String name) {
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.visibilityOf(username));
        username.sendKeys(name);

        return this;
    }

    /**
     * @return Login instance
     */
    public Login setPassword() {
        if (getData().containsKey("USER_PASSWORD")) {
            return setPassword(getData().get("USER_PASSWORD"));
        }
        else {
            return this;
        }
    }

    /**
     * @param passText
     *            ...
     * @return Login instance
     */
    public Login setPassword(String passText) {
        password.clear();
        password.sendKeys(passText);
        return this;
    }

    /**
     * @return Login instance
     */
    public Login clickLoginButton() {
        loginsubmit.click();
        return this;
    }

    /**
     * @return Login instance
     */
    public Login defaultLogon() {
        String defaultUser =
                EnvironmentVariables.getConfiguredItem(CommonParameters.ESERVICES.getValue(), "default-user-name");
        String defultPassText =
                EnvironmentVariables.getConfiguredItem(CommonParameters.ESERVICES.getValue(), "default-user-password");
        this.setUserName(defaultUser).setPassword(defultPassText).clickLoginButton();
        return this;
    }

    public Login logon() {
        String defaultUser =
                EnvironmentVariables.getConfiguredItem(CommonParameters.ESERVICES.getValue(), "default-user-name");
        String defultPassText =
                EnvironmentVariables.getConfiguredItem(CommonParameters.ESERVICES.getValue(), "default-user-password");
        if ("".equals(getDataValue(CommonParameters.USER_NAME.getValue()))) {
            this.setUserName(defaultUser).setPassword(defultPassText).clickLoginButton();
        }
        else {
            this.setUserName().setPassword().clickLoginButton();
        }
        return this;
    }

    /**
     * @return Login instance
     */
    public Login clickRegisterButton() {
        register.click();
        return this;
    }

    /**
     * @return Login instance
     */
    public Login ensureSignedOut() {
        if (this.isSignOutVisible()) {
            this.signOut();
        }
        return this;
    }

    /**
     * @param data
     *            provider
     * @return Login instance
     */
    public Login doLogin(Map<String, String> data) {
        setData(data);
        openHomePage();
        assertThat(verifyPageUrl()).isTrue();
        assertThat(verifyPageLoaded()).isTrue();
        logon();

        return this;
    }

    /**
     * VerifyTables that the page loaded completely.
     *
     * @return boolean.
     */

    public boolean verifyPageLoaded() {
        return verifyPageLoaded(PAGE_LOADED_TEXT);
    }

    /**
     * VerifyTables that current page URL matches the expected URL.
     *
     * @return boolean.
     */

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    public boolean verifyPageTitle() {
        // Not implemented ... not valid
        return false;
    }

}
