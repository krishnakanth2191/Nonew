package au.gov.ipaustralia.selenium.eservices.pageobjects.common;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;

/**
 * Simple {@link ExpectedCondition} that simulates {@link DefaultSelenium#waitForCondition(String, String)}
 */
public class JavascriptWaitForCondition implements ExpectedCondition<Boolean> {
    private String javascriptBooleanCondition;

    public JavascriptWaitForCondition(String javascriptBooleanCondition) {
        super();
        this.javascriptBooleanCondition = javascriptBooleanCondition;
    }

    @Override
    public Boolean apply(WebDriver input) {
        JavascriptExecutor js = (JavascriptExecutor) input;

        return (Boolean) js.executeScript(this.javascriptBooleanCondition, new Object[] {});
    }

}
