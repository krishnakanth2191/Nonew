package au.gov.ipaustralia.selenium.eservices.pageobjects.generalrequest;

import org.openqa.selenium.WebDriver;

/**
 * Models the General Request Summary page in eServices
 * 
 * @author Danielle Orth (bimord)
 *
 * @since 23/11/2017
 */

public class GeneralRequestSummary extends GeneralRequestBasePage {

	private static final String PAGE_TITLE = "SUMMARY";
	private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/eservices\\/general\\/general-wizard.xhtml";

	/**
	 * Page Constructor with WebDriver
	 */
	public GeneralRequestSummary(WebDriver driver) {
		super(driver);
	}

	/**
	 * Verify that current page URL matches the expected URL.
	 *
	 * @return true for URL loaded correctly
	 */
	public boolean verifyPageUrl() {
		return verifyPageUrl(PAGE_URL);
	}

	/**
	 * Verify that the page loaded completely.
	 *
	 * @return true for page loaded correctly
	 */
	public boolean verifyPageTitle() {
		return verifyPageTitle(PAGE_TITLE);
	}

	public boolean verifyPageLoaded() {
		return verifyPageTitle();
	}
}
