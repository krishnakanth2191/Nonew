/**
 * 
 */
package au.gov.ipaustralia.selenium.eservices.pageobjects.trademarks;

import org.openqa.selenium.WebDriver;

import au.gov.ipaustralia.selenium.eservices.pageobjects.common.BasePageEServices;

/**
 * @author Anthony Hallett
 *
 */
public abstract class TradeMarksBasePage extends BasePageEServices {

    public TradeMarksBasePage(WebDriver driver) {
        super(driver);
    }
    
}
