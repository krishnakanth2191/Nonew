package au.gov.ipaustralia.selenium.eservices.pageobjects.trademarks;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class TradeMarksNewAppAppliacntOrAgent extends TradeMarksBasePage {

    private static final String PAGE_TITLE = "APPLICANT OR AGENT";
    private static final String PAGE_URL =
            "\\/ICMWebUI\\/views\\/private\\/eservices\\/trademark\\/new-trademark\\/new-tm-wizard.xhtml";

    @FindBy(name = "idWizardForm:tmNewAppSubmissionCategorySelect")
    @CacheLookup
    private List<WebElement> applicantOrAgentOptionGroup;

    @FindBy(id = "idWizardForm:tmNewAppInputCustomerRefNumber")
    @CacheLookup
    private WebElement yourReference;

    public TradeMarksNewAppAppliacntOrAgent(WebDriver driver) {
        super(driver);
    }

    /**
     * Set default value to Your Reference Text field.
     *
     * @return the ES_DesignsNewApp_Applicant class instance.
     */
    public TradeMarksNewAppAppliacntOrAgent setYourReferenceTextField() {
        if (getData().containsKey(TradeMarkParameters.CUSTOMER_REFERENCE.getValue())) {
            return setYourReferenceTextField(getData().get(TradeMarkParameters.CUSTOMER_REFERENCE.getValue()));
        }
        else {
            return this;
        }

    }

    /**
     * @return TradeMarksNewApp_AppliacntOrAgent instance
     */
    public TradeMarksNewAppAppliacntOrAgent selectApplicantOrAgent() {
        if (getData().containsKey(TradeMarkParameters.CUSTOMER_TYPE.getValue())) {
            return selectApplicantOrAgent(getData().get(TradeMarkParameters.CUSTOMER_TYPE.getValue()));
        }
        else {
            return selectApplicantOrAgent(TradeMarkParameters.APPLICANT.getValue());
        }

    }

    /**
     * selects the option button for the nominated type
     * 
     * @param type
     *            the' value' attribute of the required option <br>
     *            APPLICANT; AGENT
     * @return TradeMarksNewApp_AppliacntOrAgent instance
     */
    public TradeMarksNewAppAppliacntOrAgent selectApplicantOrAgent(String type) {
        for (WebElement el : applicantOrAgentOptionGroup) {
            if (el.getAttribute("value").equals(type)) {
                if (!el.isSelected()) {
                    el.click();
                }
                break;
            }
        }
        return this;
    }

    /**
     * Set value to Your Reference Text field.
     * 
     * @param yourReferenceValue
     *            ...
     * @return the ES_DesignsNewApp_Applicant class instance.
     */
    public TradeMarksNewAppAppliacntOrAgent setYourReferenceTextField(String yourReferenceValue) {
        yourReference.sendKeys(yourReferenceValue);
        return this;
    }

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

}
