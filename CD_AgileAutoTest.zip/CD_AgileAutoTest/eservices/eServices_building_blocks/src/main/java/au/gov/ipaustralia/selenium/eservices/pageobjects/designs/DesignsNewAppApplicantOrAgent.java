package au.gov.ipaustralia.selenium.eservices.pageobjects.designs;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

import au.gov.ipaustralia.automation.selenium.helpers.db.DatabaseManagerException;
import au.gov.ipaustralia.selenium.helpers.wait.WaitTool;

/**
 * Models the APPLICANT OR AGENT page in eServices
 * 
 * @author Anthony Hallett
 *
 */
public class DesignsNewAppApplicantOrAgent extends DesignsBasePage {

    private static final Logger LOGGER = Logger.getLogger(DesignsNewAppApplicantOrAgent.class);
    private static final String PAGE_TITLE = "APPLICANT OR AGENT";
    private static final String PAGE_URL =
            "\\/ICMWebUI\\/views\\/private\\/eservices\\/design\\/new-application\\/new-app-wizard.xhtml";

    @FindBy(name = "idWizardForm:designNewAppSubmissionCategorySelect")
    @CacheLookup
    private List<WebElement> applicantOrAgentOptionGroup;

    @FindBy(id = "idWizardForm:designNewAppInputCustomerRefNumber")
    @CacheLookup
    private WebElement yourReference;

    @FindBy(id = "idWizardForm:idBtnACTION_ID_NEXT")
    @CacheLookup
    private WebElement next;

    @FindBy(id = "idWizardForm:idApplicationNumber")
    @CacheLookup
    private WebElement excludedIPRight;

    @FindBy(id = "idWizardForm:idRetrieveExistingDesignDetailsAction")
    private WebElement retrieveDetailsButton;

    public DesignsNewAppApplicantOrAgent(WebDriver driver) {
        super(driver);

        assertThat(verifyPageUrl()).as("APPLICANT OR AGENT page URL").isTrue();
        assertThat(verifyPageLoaded()).as("APPLICANT OR AGENT page loaded").isTrue();
    }

    /**
     * Set default value to Your Reference Text field.
     *
     * @return the ES_DesignsNewApp_Applicant class instance.
     */
    public DesignsNewAppApplicantOrAgent setYourReferenceTextField() {
        if (getData().containsKey(DesignsParameters.CUSTOMER_REFERENCE.getValue())) {
            return setYourReferenceTextField(getData().get(DesignsParameters.CUSTOMER_REFERENCE.getValue()));
        }
        else {
            return this;
        }

    }

    public DesignsNewAppApplicantOrAgent selectApplicantOrAgent() {
        if (getData().containsKey(DesignsParameters.CUSTOMER_TYPE.getValue())) {
            return selectApplicantOrAgent(getData().get(DesignsParameters.CUSTOMER_TYPE.getValue()));
        }
        else {
            return selectApplicantOrAgent(DesignsParameters.CUSTOMER_TYPE_APPLICANT.getValue());
        }

    }

    /**
     * selects the option button for the nominated type
     * 
     * @param type
     *            the' value' attribute of the required option <br>
     *            APPLICANT; AGENT
     * @return DesignsNewApp_ApplicantOrAgent instance
     */
    public DesignsNewAppApplicantOrAgent selectApplicantOrAgent(String type) {
        for (WebElement el : applicantOrAgentOptionGroup) {
            if (el.getAttribute("value").equals(type)) {
                if (!el.isSelected()) {
                    el.click();
                }
                break;
            }
        }
        return this;
    }

    /**
     * Set value to Your Reference Text field.
     * 
     * @param yourReferenceValue
     *            ...
     * @return the ES_DesignsNewApp_Applicant class instance.
     */
    public DesignsNewAppApplicantOrAgent setYourReferenceTextField(String yourReferenceValue) {
        yourReference.sendKeys(yourReferenceValue);
        return this;
    }

    /**
     * Set default value to Excluded Application Number Text field.
     * 
     * @param custID
     *            ...
     * @return the ES_DesignsNewApp_Applicant class instance.
     */
    public DesignsNewAppApplicantOrAgent setAssociatedApplicationNumber(String custID) throws DatabaseManagerException {
        if (!getDataValue(DesignsParameters.ASSOCIATED_IPRIGHT.getValue()).trim().equals("")) {
            String ipRight = "";
            excludedIPRight.sendKeys(ipRight);
            retrieveDetailsButton.click();
            waitWhileEServicesBusy();
        }
        return this;
    }

    public String getTaskType() {
        String workCaseId = "";

        Boolean status =
                driver.findElements(By.xpath("//*[@id='idWizardForm:idRemoveDesigndetailsAction']")).size() > 0;
        if (status) {
            workCaseId = "Case Found";
        }
        else {
            workCaseId = "Case NOT Found";
        }
        return workCaseId;
    }

    /**
     * @param ipRightNumeber
     *            ...
     * @return GeneralRequestDetails instance
     */
    public DesignsNewAppApplicantOrAgent setIPRight(String ipRight,
                                                    int waitSeconds) {
        String workCaseID = "";
        int waited = 0;
        excludedIPRight.sendKeys(ipRight);
        retrieveDetailsButton.click();
        waitWhileEServicesBusy();
        int noOfTries = waitSeconds / 5;
        for (int i = 0; i < noOfTries; i++) {
            workCaseID = getTaskType();
            if ("Case NOT Found".equals(workCaseID)) {
                WaitTool.sleep(5000);
                waited += 5;
                retrieveDetailsButton.click();
                waitWhileEServicesBusy();
            }
            else {
                waited = waited / 60;
                LOGGER.info("Waited at ESerives for " + waited + " Minutes");
                break;
            }
        }

        return this;
    }

    /**
     * @param ipRight
     *            ...
     * @return DesignsNewApp_ApplicantOrAgent instance
     */
    public DesignsNewAppApplicantOrAgent setAssociatedFurtherApplicationNumber(String ipRight) {
        excludedIPRight.sendKeys(ipRight);
        retrieveDetailsButton.click();
        waitWhileEServicesBusy();
        return this;
    }

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }
}
