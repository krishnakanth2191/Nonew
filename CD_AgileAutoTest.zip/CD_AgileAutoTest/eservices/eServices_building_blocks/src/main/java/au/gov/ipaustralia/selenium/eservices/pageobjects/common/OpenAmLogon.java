/**
 * 
 */
package au.gov.ipaustralia.selenium.eservices.pageobjects.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * models the undecorated OpenAM login page
 * 
 * @author cpahan
 *
 */
public class OpenAmLogon extends Login {

    @FindBy(name = "Login.Submit")
    private WebElement loginsubmit;

    /**
     * @param driver
     *            the Webdriver
     */
    public OpenAmLogon(WebDriver driver) {
        super(driver);
    }

    @Override
    public OpenAmLogon clickLoginButton() {
        loginsubmit.click();
        return this;
    }

}
