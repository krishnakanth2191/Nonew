package au.gov.ipaustralia.selenium.eservices.pageobjects.common;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import au.gov.ipaustralia.selenium.helpers.utilities.RegExpUtilities;

/**
 * Models the SUMMARY page in eServices
 * 
 * @author Anthony Hallett
 */
public class Summary extends BasePageEServices {
    private static final String PAGE_TITLE = "SUMMARY";
    private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/.*\\/.*-wizard.xhtml";

    @FindBy(id = "idWizardForm:idBtnACTION_ID_ADD_TO_CART")
    private WebElement addToCart;

    @FindBy(css = ".wizTotalPayable")
    private WebElement totalPayableSummary;

    @FindBy(xpath = "//td[text() = 'Designs New Application']/following-sibling::*")
    private WebElement designNewAppFee;

    @FindBy(xpath = "//td[text() = 'Request to Register a Design']/following-sibling::*")
    private WebElement designRegisterFee;

    @FindBy(xpath = "//td[text() = 'Request for Examination by Registered Owner']/following-sibling::*")
    private WebElement designExamFee;

    @FindBy(xpath = "//td[span[text()='Total payable (AU)']]/following-sibling::*/span")
    private WebElement totalPayable;

    @FindBy(xpath = "//h3[span[text()= 'Applicants']]/following-sibling::*/table")
    private WebElement applicantsTable;

    @FindBy(xpath = "//h3[span[text()= 'Main Contact']]/following-sibling::*//dt[contains(text(), 'Name')]/following-sibling::*[1]/span")
    private WebElement mainContactName;

    @FindBy(id = "idWizardForm:idMainContactCorrespondenceAddressAddressLine1")
    private WebElement mainContactAddressLine1;

    @FindBy(id = "idWizardForm:idMainContactCorrespondenceAddressAddressLine2")
    private WebElement mainContactAddressLine2;

    @FindBy(id = "idWizardForm:idMainContactCorrespondenceAddressAddressLine3")
    private WebElement mainContactAddressLine3;

    @FindBy(id = "idWizardForm:idMainContactCorrespondenceAddressSuburb")
    private WebElement mainContactSuburb;

    @FindBy(id = "idWizardForm:idMainContactCorrespondenceAddressAddressLine")
    private WebElement mainContactCountry;

    @FindBy(id = "idWizardForm:idMainContactLegalServiceAddressAddressLine1")
    private WebElement legalServiceAddressLine1;

    @FindBy(id = "idWizardForm:idMainContactLegalServiceAddressSuburb")
    private WebElement legalServiceSuburb;

    @FindBy(id = "idWizardForm:idMainContactLegalServiceAddressAddressLine")
    private WebElement legalServiceCountry;

    @FindBy(xpath = "//h3[span[text()= 'Main Contact']]/following-sibling::*//dt[contains(text(), 'Contact person')]/following-sibling::*[1]")
    private WebElement mainContactPerson;

    @FindBy(xpath = "//h3[span[text()= 'Main Contact']]/following-sibling::*//dt[contains(text(), Phone')]/following-sibling::*[1]")
    private WebElement mainContactPhone;

    @FindBy(xpath = "//h3[span[text()= 'Main Contact']]/following-sibling::*//dt[contains(text(), 'Fax')]/following-sibling::*[1]")
    private WebElement mainContactFax;

    @FindBy(xpath = "//h3[span[text()= 'Main Contact']]/following-sibling::*//dt[contains(text(), 'Mobile')]/following-sibling::*[1]")
    private WebElement mainContactMobile;

    @FindBy(xpath = "//h3[span[text()= 'Main Contact']]/following-sibling::*//dt[contains(text(), 'Email address')]/following-sibling::*[1]")
    private WebElement mainContactEmail;

    @FindBy(xpath = "//dt[span[contains(text(), 'Designers')]]/following-sibling::*/span")
    private List<WebElement> designers;

    @FindBy(xpath = "//dt[span[contains(text(), 'Product(s) the design relates to')]]//following-sibling::*[1]/span")
    private WebElement products;

    @FindBy(xpath = "//dt[span[contains(text(), 'Statement of newness and distinctiveness')]]//following-sibling::*[1]/span")
    private WebElement statementOfNewness;

    @FindBy(xpath = "//*[@id='idWizardForm:designRepresentationFilesTable:tb']//tr//img")
    private List<WebElement> representations;

    @FindBy(xpath = "//dt[contains(text(), 'We request the design is:')]//following-sibling::*[1]")
    private WebElement additionalRequest;

    // CONSTRUCTOR
    public Summary(WebDriver driver) {
        super(driver);

        assertThat(verifyPageUrl()).as("SUMMARY page URL").isTrue();
        assertThat(verifyPageLoaded()).as("SUMMARY page loaded").isTrue();
    }

    /**
     * Click on Add To Cart Button.
     *
     * @return the EServices_DesignsNewApp_Summary class instance.
     */
    public Summary clickAddToCartButton() {
        addToCart.click();
        waitWhileEServicesBusy();
        return this;
    }

    public String getTotalPayableSummary() {
        return totalPayableSummary.getText();
    }

    public String getDesignNewAppFee() {
        return designNewAppFee.getText();
    }

    public String getDesignRegisterFee() {
        return designRegisterFee.getText();
    }

    public String getDesignExamFee() {
        return designExamFee.getText();
    }

    public String getTotalPayable() {
        return totalPayable.getText();
    }

    public String getMainContactName() {
        return mainContactName.getText();
    }

    public String getMainContactAddressLine1() {
        return mainContactAddressLine1.getText();
    }

    public String getMainContactAddressLine2() {
        return mainContactAddressLine2.getText();
    }

    public String getMainContactAddressLine3() {
        return mainContactAddressLine3.getText();
    }

    public String getMainContactSuburb() {
        return mainContactSuburb.getText();
    }

    public String getMainContactCountry() {
        return mainContactCountry.getText();
    }

    public String getLegalServiceAddressLine1() {
        return legalServiceAddressLine1.getText();
    }

    public String getLegalServiceSuburb() {
        return legalServiceSuburb.getText();
    }

    public String getLegalServiceCountry() {
        return legalServiceCountry.getText();
    }

    public String getMainContactPerson() {
        return mainContactPerson.getText();
    }

    public String getMainContactPhone() {
        return mainContactPhone.getText();
    }

    public String getMainContactFax() {
        return mainContactFax.getText();
    }

    public String getMainContactMobile() {
        return mainContactMobile.getText();
    }

    public String getMainContactEMail() {
        return mainContactEmail.getText();
    }

    public String getProducts() {
        return products.getText();
    }

    public String getSON() {
        return statementOfNewness.getText();
    }

    public String getAdditionalRequest() {
        String ret = "";
        String req = additionalRequest.getText();
        if ("Registered and examined".equals(req.trim())) {
            ret = "REGISTERED_AND_EXAMINED";
        }
        else if ("Registered".equals(req.trim())) {
            ret = "REGISTERED";
        }
        else if ("Published".equals(req.trim())) {
            ret = "PUBLISHED";
        }
        else if ("Registered or published later".equals(req.trim())) {
            ret = "NONE";
        }
        return ret;
    }

    public Summary verifySummary(Map<String, Object> expected) {
        assertThat(expected.get("TOTAL_PAYABLE").equals(getTotalPayableSummary())).as("Total Payable Summary").isTrue();
        assertThat(expected.get("NEWAPP_FEE").equals(getDesignNewAppFee())).as("New App fee").isTrue();
        assertThat(expected.get("REGISTER_FEE").equals(getDesignRegisterFee())).as("Register fee").isTrue();
        assertThat(expected.get("EXAM_FEE").equals(getDesignExamFee())).as("Exam fee").isTrue();
        assertThat(expected.get("TOTAL_PAYABLE").equals(getTotalPayable())).as("Total payable fee").isTrue();

        String[][] expApplicants = (String[][]) expected.get("APPLICANTS");
        List<WebElement> rows = applicantsTable.findElements(By.xpath("tbody/tr"));
        for (int i = 0; i < rows.size(); i++) {
            List<WebElement> cells = rows.get(i).findElements(By.xpath("td"));
            for (int j = 0; j < cells.size(); j++) {
                Assert.assertTrue("Applicants row " + (i + 1) + " col " + (j + 1),
                                  RegExpUtilities.matchesAnyCase(expApplicants[i][j], cells.get(j).getText()));
            }
        }

        assertThat(expected.get("MAINCONTACT_NAME").equals(getMainContactName())).as("Main Contact Name").isTrue();
        Assert.assertTrue("Main Contact Address Line 1",
                          expected.get("MAINCONTACT_ALINE1").equals(getMainContactAddressLine1()));
        if (expected.containsKey("MAINCONTACT_ALINE2")) {
            Assert.assertTrue("Main Contact Address Line 2",
                              expected.get("MAINCONTACT_ALINE2").equals(getMainContactAddressLine2()));
        }
        if (expected.containsKey("MAINCONTACT_ALINE3")) {
            Assert.assertTrue("Main Contact Address Line 3",
                              expected.get("MAINCONTACT_ALINE3").equals(getMainContactAddressLine3()));
        }

        assertThat(expected.get("MAINCONTACT_SUBURB").equals(getMainContactSuburb())).as("Main Contact Suburb").isTrue();
        assertThat(expected.get("MAINCONTACT_COUNTRY").equals(getMainContactCountry())).as("Main Contact Country").isTrue();

        Assert.assertTrue("Legal Service Address Line 1",
                          expected.get("LEGALSERVICE_ALINE1").equals(getMainContactAddressLine1()));
        assertThat(expected.get("LEGALSERVICE_SUBURB").equals(getMainContactSuburb())).as("Legal Service Suburb").isTrue();
        Assert.assertTrue("Legal Service Country",
                          expected.get("LEGALSERVICE_COUNTRY").equals(getMainContactCountry()));

        if (expected.containsKey("DESIGNERS")) {
            String[][] designer = ((String[][]) expected.get("DESIGNERS"));
            for (int i = 0; i < designer.length; i++) {
                String exp = "";
                if (designer[i][0].trim().equals("") || designer[i][0].equals("{blank}")) {
                    exp = String.format("%s %s", designer[i][1], designer[i][2]);
                }
                else {
                    exp = String.format("%s %s %s", designer[i][0], designer[i][1], designer[i][2]);
                }
                assertThat(getDesigner(i).equals(exp)).as("Designer row " + (i + 1)).isTrue();
            }
        }

        String[] files = ((String) expected.get("FILES")).split(";");
        for (int i = 0; i < files.length; i++) {
            assertThat(getRepresentationAlt(i).equals(files[i])).as("Representations alt text row " + (i + 1)).isTrue();
        }

        assertThat(((String) expected.get("REQ_TYPE")).equals(getAdditionalRequest())).as("Additional Request").isTrue();

        return this;
    }

    /**
     * VerifyTables that current page URL matches the expected URL.
     *
     * @return boolean.
     */
    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    /**
     * VerifyPageTitle Matches with given title.
     *
     * @return boolean.
     */
    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

    private String getDesigner(int row) {
        return designers.get(row).getText();
    }

    private String getRepresentationAlt(int row) {
        return representations.get(row).getAttribute("alt");
    }
}
