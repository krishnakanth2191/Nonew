package au.gov.ipaustralia.selenium.eservices.pageobjects.patents;

import org.openqa.selenium.WebDriver;

public class PatentsNewAppAdditionalRequests extends PatentBasePage {

    private static final String PAGE_TITLE = "ADDITIONAL REQUESTS";
    private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/eservices\\/patent\\/.*\\/.*-wizard.xhtml";

    public PatentsNewAppAdditionalRequests(WebDriver driver) {
        super(driver);
    }

    
    /**
     * VerifyPageTitle Matches with given title.
     *
     * @return boolean.
     */
    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

    /**
     * VerifyTables that current page URL matches the expected URL.
     *
     * @return boolean.
     */
    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

}
