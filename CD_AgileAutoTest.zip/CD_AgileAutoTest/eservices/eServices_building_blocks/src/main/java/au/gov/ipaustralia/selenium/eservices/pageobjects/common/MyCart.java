package au.gov.ipaustralia.selenium.eservices.pageobjects.common;

import static org.assertj.core.api.Assertions.assertThat;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

/**
 * Models the MY CART page in eServices
 * 
 * @author Anthony Hallett
 *
 */
public class MyCart extends BasePageEServices {
    private static final String PAGE_TITLE = "MY CART";
    private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/home\\/forms.xhtml\\?tab=MY_CART";

    @FindBy(id = "idSrCartForm:idSrCartBatchRefNumber")
    @CacheLookup
    private WebElement yourCartReference;

    @FindBy(id = "idSrCartForm:idSrCartSubmitButton")
    @CacheLookup
    private WebElement proceedToPay;

    public MyCart(WebDriver driver) {
        super(driver);

        assertThat(verifyPageUrl()).as("MY CART page URL").isTrue();
        assertThat(verifyPageLoaded()).as("MY CART page loaded").isTrue();
    }

    /**
     * Set default value to Your Cart Reference Text field.
     *
     * @return the EServices_DesignsNewApp_MyCart class instance.
     */
    public MyCart setYourCartReferenceTextField() {
        return setYourCartReferenceTextField(getDataValue("YOUR_CART_REFERENCE"));
    }

    /**
     * Set value to Your Cart Reference Text field.
     * 
     * @param yourCartReferenceValue
     *            ...
     * @return the EServices_DesignsNewApp_MyCart class instance.
     */
    public MyCart setYourCartReferenceTextField(String yourCartReferenceValue) {
        yourCartReference.sendKeys(yourCartReferenceValue);
        return this;
    }

    /**
     * Click on Proceed To Pay Button.
     *
     * @return the EServices_DesignsNewApp_MyCart class instance.
     */
    public MyCart clickProceedToPayButton() {
        proceedToPay.click();
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * VerifyTables that current page URL matches the expected URL.
     *
     * @return boolean.
     */
    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    /**
     * VerifyPageTitle Matches with given title.
     *
     * @return boolean.
     */
    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE, "#idServiceRequestCartMainPanel > h2 > span");

    }

}
