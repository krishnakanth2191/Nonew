package au.gov.ipaustralia.selenium.eservices.pageobjects.patents;

import java.util.Random;

import org.apache.log4j.Logger;
import org.openqa.selenium.By.ById;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import au.gov.ipaustralia.selenium.helpers.utilities.DateUtilities;
import au.gov.ipaustralia.selenium.helpers.wait.WaitTool;

/**
 * Test Methods for Patents National Phase Entry Wipo Number page objects
 * 
 * @author Suresh Thumma - 05/11/2017
 * 
 * @Jira AUTO-226
 *
 */

public class PatentsNewAppNationalPhaseEntryWipoPctNumber extends PatentBasePage {

    private static final Logger LOGGER = Logger.getLogger(PatentsNewAppNationalPhaseEntryWipoPctNumber.class);
    private static final String PAGE_TITLE = "WIPO/PCT NUMBER";
    private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/eservices\\/patent\\/.*\\/.*";

    public static final String YEAR_WIPO = "idWizardForm:idInputWipoYear";
    @FindBy(id = YEAR_WIPO)
    private WebElement wipoYear;

    @FindBy(id = "idWizardForm:idInputWipoNumber")
    private WebElement wipoNumber;

    public PatentsNewAppNationalPhaseEntryWipoPctNumber(WebDriver driver) {
        super(driver);

    }

    /**
     * Generates current year and send to text element
     *
     * @return Patent Number
     */
    public PatentsNewAppNationalPhaseEntryWipoPctNumber setWipoYear() {
        WaitTool.waitForElement(driver, ById.id(YEAR_WIPO), timeout);
        String patentNumber = DateUtilities.year();
        LOGGER.info("year to enter" + patentNumber);
        wipoYear.sendKeys(patentNumber);

        return this;
    }

    /**
     * Generates 6 digit Random number and send to text element
     *
     * @return WIPO Number
     */
    public PatentsNewAppNationalPhaseEntryWipoPctNumber setWipoNumber() {
        Random ran = new Random();
        String wipoNum = String.format("%06d", ran.nextInt(999999));
        LOGGER.info("number to enter" + wipoNum);
        wipoNumber.sendKeys(wipoNum);

        return this;
    }

    /**
     * VerifyTables that current page URL matches the expected URL.
     *
     * @return boolean.
     */
    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    /**
     * VerifyPageTitle Matches with given title.
     *
     * @return boolean.
     */
    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

}
