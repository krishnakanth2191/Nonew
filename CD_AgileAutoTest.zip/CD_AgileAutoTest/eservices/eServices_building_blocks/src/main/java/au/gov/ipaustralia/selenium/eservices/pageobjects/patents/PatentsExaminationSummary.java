package au.gov.ipaustralia.selenium.eservices.pageobjects.patents;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import au.gov.ipaustralia.selenium.eservices.pageobjects.generalrequest.GeneralRequestBasePage;

/**
 * Models the Patents Examination Summary page in eServices
 * 
 * @author Jonathan Eastman - Danielle Orth - 27/11/17
 *
 */

public class PatentsExaminationSummary extends GeneralRequestBasePage {

	private static final String PAGE_TITLE = "SUMMARY";
	private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/eservices\\/patent\\/exam-request\\/exam-request-wizard.xhtml";

	@FindBy(id = "idWizardForm:idBtnACTION_ID_ADD_TO_CART")
	private WebElement addToCart;

	public PatentsExaminationSummary(WebDriver driver) {
		super(driver);
	}

	/**
	 * Verify that current page URL matches the expected URL.
	 *
	 * @return true for URL loaded correctly
	 */
	public boolean verifyPageUrl() {
		return verifyPageUrl(PAGE_URL);
	}

	/**
	 * Verify that the page loaded completely.
	 *
	 * @return true for page loaded correctly
	 */
	public boolean verifyPageTitle() {
		return verifyPageTitle(PAGE_TITLE);
	}

	public boolean verifyPageLoaded() {
		return verifyPageTitle();
	}

}
