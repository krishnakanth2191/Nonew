package au.gov.ipaustralia.selenium.eservices.pageobjects.designs;

import org.openqa.selenium.WebDriver;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.BasePageEServices;

/**
 * @author Anthony Hallett
 *
 */
public abstract class DesignsBasePage extends BasePageEServices {

    public DesignsBasePage(WebDriver driver) {
        super(driver);
    }

}
