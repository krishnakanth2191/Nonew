package au.gov.ipaustralia.selenium.eservices.pageobjects.designs;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

/**
 * Models the DESIGN eSERVICES page in eServices
 * 
 * @author Anthony Hallett
 *
 */
public class Designs extends DesignsBasePage {
    private static final String PAGE_TITLE = "DESIGN eSERVICES";
    private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/home\\/forms.xhtml\\?tab=DESIGN";

    @FindBy(id = "idApplyForNewDesign")
    @CacheLookup
    private WebElement applyForADesign;

    @FindBy(id = "idGeneralDesign")
    @CacheLookup
    private WebElement generalEserviceRequest;

    @FindBy(id = "idRenewDesign")
    @CacheLookup
    private WebElement renewalPayment;

    /**
     * @param driver
     *            the WebDriver
     */
    public Designs(WebDriver driver) {
        super(driver);
    }

    /**
     * Click on Apply For A Design Link.
     *
     * @return the ES_Designs class instance.
     */
    public Designs clickApplyForADesignLink() {
        applyForADesign.click();
        return this;
    }

    /**
     * Click on General Eservice Request Link.
     *
     * @return the ES_Designs class instance.
     */
    public Designs clickGeneralEserviceRequestLink() {
        generalEserviceRequest.click();
        return this;
    }

    /**
     * Click on Renewal Payment Link.
     *
     * @return the ES_Designs class instance.
     */
    public Designs clickRenewalPaymentLink() {
        renewalPayment.click();
        return this;
    }

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

}
