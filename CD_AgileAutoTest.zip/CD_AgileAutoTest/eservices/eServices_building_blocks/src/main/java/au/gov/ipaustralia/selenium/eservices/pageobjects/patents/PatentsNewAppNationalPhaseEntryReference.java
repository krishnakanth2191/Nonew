package au.gov.ipaustralia.selenium.eservices.pageobjects.patents;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import au.gov.ipaustralia.selenium.eservices.pageobjects.common.BasePageEServices;
import au.gov.ipaustralia.selenium.helpers.wait.WaitTool;

/**
 * Test Methods for Patents National Phase Entry Reference page objects
 * 
 * @author Suresh Thumma - 05/11/2017
 * 
 * @Jira AUTO-226
 *
 */

public class PatentsNewAppNationalPhaseEntryReference extends PatentBasePage {

    private static final String PAGE_TITLE = "PCT DETAILS";
    private static final String PAGE_URL =
            "\\/ICMWebUI\\/views\\/private\\/eservices\\/patent\\/new-application\\/new-app-wizard.xhtml";

    @FindBy(id = "idWizardForm:idInputCustomerRefNumber")
    private WebElement pctReference;

    static final String BROWSE_FILE_DESRIPTION = "idWizardForm:idPctRequestFileUpload";
    @FindBy(id = BROWSE_FILE_DESRIPTION)
    private WebElement pctRequestForm;

    @FindBy(id = "idWizardForm:idSelectNPEAcknowledgement:0")
    private WebElement acknowledgeNPAYes;

    @FindBy(id = "idWizardForm:idPublishedInEnglishIndicator:0")
    private WebElement filedEnglishYes;

    @FindBy(id = "idWizardForm:idPriorityClaimIndicator:0")
    private WebElement priorityClaimYes;

    public PatentsNewAppNationalPhaseEntryReference(WebDriver driver) {
        super(driver);

    }

    /**
     * Set Given text String Value
     *
     * @return Reference Number
     */
    public PatentsNewAppNationalPhaseEntryReference setPCTRef(String ref) {
        pctReference.sendKeys(ref);
        return this;
    }

    /**
     * @param fileName
     * 
     * @ passing browser elements as common ...and doing file attachment
     * @return File Attachemnt
     * 
     */
    public BasePageEServices attachedPCTReqForm(String fileName) {
        WaitTool.waitForElement(driver, By.id(BROWSE_FILE_DESRIPTION), timeout);
        addFile(fileName, pctRequestForm);
        return this;

    }

    /**
     * Click on the Yes Radio button element
     *
     * @return Clicked on Yes button
     */
    public PatentsNewAppNationalPhaseEntryReference clickAcknowledgeNPAYes() {
        acknowledgeNPAYes.click();
        return this;
    }

    /**
     * Click on the Yes Radio button element
     *
     * @return Clicked on Yes button
     */
    public PatentsNewAppNationalPhaseEntryReference clickFiledEnglishYes() {
        filedEnglishYes.click();
        return this;
    }

    /**
     * Click on the Yes Radio button element
     *
     * @return Clicked on Yes button
     */
    public PatentsNewAppNationalPhaseEntryReference clickPriorityClaimYes() {
        priorityClaimYes.click();
        return this;
    }

    /**
     * VerifyTables that current page URL matches the expected URL.
     *
     * @return boolean.
     */
    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    /**
     * VerifyPageTitle Matches with given title.
     *
     * @return boolean.
     */
    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

}
