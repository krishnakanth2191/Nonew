package au.gov.ipaustralia.selenium.eservices.pageobjects.patents;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import au.gov.ipaustralia.automation.selenium.helpers.db.PAMSDBManager;

/**
 * Models the Patents Examination Details page in eServices
 * 
 * @author Jonathan Eastman - Danielle Orth : 27/11/17
 *
 */

public class PatentsExaminationDetails extends PatentBasePage {

	private static final Logger LOGGER = Logger.getLogger(PatentsExaminationDetails.class);
	private static final String PAGE_TITLE = "EXAMINATION DETAILS";
	private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/eservices\\/patent\\/exam-request\\/exam-request-wizard.xhtml";

	@FindBy(id = "idWizardForm:idApplicationNumber")
	private WebElement applicationNumberField;

	@FindBy(id = "idWizardForm:idAddpatentdetailsAction")
	private WebElement retrievePatentDetails;

	@FindBy(id = "idWizardForm:idSelectExamType1:0")
	private WebElement fullExaminationRadioButton;

	@FindBy(id = "idWizardForm:idRemovepatentdetailsAction")
	private WebElement changeApplicaitonNumber;

	@FindBy(id = "idWizardForm:idPatentExaminationSoeidCheckBoxStatementOfEntitlement")
	private WebElement statementOfEntitlementCheckBox;

	public PatentsExaminationDetails(WebDriver driver) {
		super(driver);
	}

	/**
	 * Insert Patent details
	 * 
	 * @return Reference to object following successful load
	 */
	public PatentsExaminationDetails loadIPRightDetails() {
		String patentNumber = new PAMSDBManager().getPatentId().getFirstDataItem().toString();
		LOGGER.info("Patent number from Database:" + patentNumber);
		applicationNumberField.sendKeys(patentNumber);
		retrievePatentDetails.click();
		return this;
	}

	/**
	 * Select the Full Examination radio button and pulls in options available
	 * for full examination
	 * 
	 * @return This object provisioned for entering details for full examination
	 *         request
	 */

	public PatentsExaminationDetails clickFullExamination() {
		fullExaminationRadioButton.click();
		waitWhileEServicesBusy();

		while (driver.findElements(By.xpath(".//*[@id='singleMessageText']")).size()>0) {
			changeApplicaitonNumber.click();
			loadIPRightDetails();
			fullExaminationRadioButton.click();
			waitWhileEServicesBusy();
		}
		return this;
	}

	/**
	 * Click the Statement of Entitlement check box
	 * 
	 * @return This object provisioned for entering details for statement of
	 *         entitlement
	 */
	public PatentsExaminationDetails clickStatementOfEntitlement() {
		statementOfEntitlementCheckBox.click();
		waitWhileEServicesBusy();
		return this;
	}

	/**
	 * Verify that current page URL matches the expected URL.
	 *
	 * @return true for URL loaded correctly
	 */
	public boolean verifyPageUrl() {
		return verifyPageUrl(PAGE_URL);
	}

	/**
	 * Verify that the page loaded completely.
	 *
	 * @return true for page loaded correctly
	 */
	public boolean verifyPageTitle() {
		return verifyPageTitle(PAGE_TITLE);
	}

	public boolean verifyPageLoaded() {
		return verifyPageTitle();
	}

}
