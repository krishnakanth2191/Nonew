package au.gov.ipaustralia.selenium.eservices.pageobjects.designs;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import au.gov.ipaustralia.selenium.environment.EnvironmentVariables;
import au.gov.ipaustralia.selenium.helpers.wait.WaitTool;

/**
 * Base page for commonality across Single and Multiple designs pages
 * 
 * @author Anthony Hallett
 *
 */
public abstract class DesignsNewAppDesignDetailsBase extends DesignsBasePage {
    private static final String PAGE_URL =
            "\\/ICMWebUI\\/views\\/private\\/eservices\\/design\\/new-application\\/new-app-wizard.xhtml";

    // Designers
    @FindBy(id = "idWizardForm:idDesignerBtnAdd")
    private WebElement addDesigner;

    @FindBy(id = "idWizardForm:idBtnACTION_ID_NEXT")
    private WebElement next;

    @FindBy(id = "idWizardForm:idDesignerSelectTitle")
    private WebElement title;

    @FindBy(id = "idWizardForm:idDesignerInputFirstName")
    private WebElement givenNames;

    @FindBy(id = "idWizardForm:idDesignerBtnSave")
    private WebElement add;

    @FindBy(id = "idWizardForm:idDesignerInputLastName")
    private WebElement familyName;

    // Products
    @FindBy(id = "idWizardForm:designProducts")
    private WebElement product;

    @FindBy(id = "idWizardForm:designNewness")
    private WebElement statementOfNewnessAndDistinctiveness;

    // Representations
    static final String ADD_FILED_ID =
            "idWizardForm:idDesignRepresentationAttachmentsidRepresentationAttachmentsFileBrowseAndAttach";

    @FindBy(id = ADD_FILED_ID)
    private WebElement addFileId;

    @FindBy(id = "idWizardForm:idDesignRepresentationAttachmentsidRepresentationAttachmentsFileAddBtn")
    private WebElement addRep;

    // Priority
    static final String CONV_CLAIM_ID = "idWizardForm:idCheckPriorityConventionalClaim";
    @FindBy(id = CONV_CLAIM_ID)
    private WebElement conventionClaim;

    @FindBy(name = "idWizardForm:idPriorityConventionalClaimPanel_SelectApplicationNumber")
    private List<WebElement> knownAppNumber;

    @FindBy(id = "idWizardForm:idPriorityConventionalClaimPanel_InputApplicationNumber")
    private WebElement applicationNumber;

    static final String FILING_DATE_ID = "idWizardForm:idPriorityConventionalClaimPanel_FilingDateInputDate";

    private static final String VALUE = "VALUE";

    @FindBy(id = FILING_DATE_ID)
    private WebElement filingDate;

    @FindBy(id = "idWizardForm:idPriorityConventionalClaimPanel_SelectCountry")
    private WebElement country;
    @FindBy(id = "idWizardForm:idPriorityConventionalClaimPanel_BtnSave")
    private WebElement addConvClaim;

    @FindBy(id = "idWizardForm:idPriorityConventionalClaimPanel_BtnAdd")
    private WebElement additionalConvClaim;

    @FindBy(name = "idWizardForm:idSelectDesignProtectionRadio")
    private List<WebElement> requestType;

    @FindBy(id = "idWizardForm:idCheckRegisteredExamSr")
    private WebElement registeredAndExamined;

    /**
     * @param driver
     *            the WebDriver
     */
    public DesignsNewAppDesignDetailsBase(WebDriver driver) {
        super(driver);
    }

    /**
     * @return DesignsNewAppDesignDetailsBase instance
     */
    public DesignsNewAppDesignDetailsBase addConventionClaims() {
        if (!getDataValue(DesignsParameters.CONV_CLAIM_FILING_DATE.getValue()).trim().equals("")) {
            String[] numbers = getDataValue(DesignsParameters.CONV_CLAIM_NUMBER.getValue()).split("\n");

            String formatDate1 = dateFromLocal(30);
            String formatDate2 = dateFromLocal(45);
            String[] dates = { formatDate1, formatDate2 };
            String[] countries = getDataValue(DesignsParameters.CONV_CLAIM_COUNTRY.getValue()).split("\n");

            setConventionClaimCheckboxField();

            for (int i = 0; i < countries.length; i++) {
                if (i > 0) {
                    clickAdditionalConvClaimButton();
                }
                if (numbers[i].trim().equals("")) {
                    setKnownAppNoRadioButtonField();
                }
                else {
                    setKnownAppYesRadioButtonField();
                    setApplicationNumberTextField(numbers[i]);
                }
                setFilingDateTextField(dates[i]);
                if ("International Bureau Of The World Intellectual Property Organization (WIPO)".equals(countries[i])) {
                    new Select(country).selectByIndex(100);

                }
                else if ("Office for Harmonization in the Internal Market (Trade Marks and Designs) (OHIM)".equals(countries[i])
                        && "CIDev".equals(EnvironmentVariables.getEnvironmentName())) {
                    setCountryDropDownListField("European Union Intellectual Property Office (EUIPO)");

                }
                else {
                    setCountryDropDownListField(countries[i]);

                }
                clickAddConvClaimButton();
            }

        }
        return this;
    }

    /**
     * @return DesignsNewAppDesignDetailsBase instance
     */
    public DesignsNewAppDesignDetailsBase addFiles() {
        if (getData().containsKey(DesignsParameters.FILE_NAMES.getValue())) {
            addFiles(getData().get(DesignsParameters.FILE_NAMES.getValue()));
        }
        return this;

    }

    /**
     * @param title
     *            ...
     * @param givenName
     *            ...
     * @param familyName
     *            ...
     * @return DesignsNewAppDesignDetailsBase instance
     */
    public DesignsNewAppDesignDetailsBase addNewDesigner(String title,
                                                         String givenName,
                                                         String familyName) {
        clickAddDesignerButton();
        setTitleDropDownListField(title);
        setGivenNamesTextField(givenName);
        setFamilyNameTextField(familyName);
        clickAddButton();

        return this;
    }

    /**
     * @return DesignsNewAppDesignDetailsBase instance
     */
    public DesignsNewAppDesignDetailsBase addNewDesigners() {
        if (!getDataValue(DesignsParameters.DESIGNER_GIVEN_NAME.getValue()).trim().equals("")) {
            String[] designerGivenNames = getDataValue(DesignsParameters.DESIGNER_GIVEN_NAME.getValue()).split("\n");
            String[] familtyNames = getDataValue(DesignsParameters.DESIGNER_FAMILY_NAME.getValue()).split("\n");
            String[] titles = getDataValue(DesignsParameters.DESIGNER_TITLE.getValue()).split("\n");
            for (int i = 0; i < designerGivenNames.length; i++) {
                addNewDesigner(titles[i], designerGivenNames[i], familtyNames[i]);
            }
        }

        return this;
    }

    public DesignsNewAppDesignDetailsBase addNewDesigners(Map<String, Object> source) {
        if (source.containsKey(DesignsParameters.DESIGNERS.getValue())) {
            String[][] designers = ((String[][]) source.get(DesignsParameters.DESIGNERS.getValue()));
            for (int i = 0; i < designers.length; i++) {
                if (designers[i][0].trim().equals("") || designers[i][0].equals("{blank}")) {
                    addNewDesigner(" ", designers[i][1], designers[i][2]);
                }
                else {
                    addNewDesigner(designers[i][0], designers[i][1], designers[i][2]);
                }
            }
        }

        return this;
    }

    /**
     * Click on Add Button.
     *
     * @return the EServices_DesignsNewApp_Designers class instance.
     */
    public DesignsNewAppDesignDetailsBase clickAddButton() {
        this.clickA4J(add);
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * Click on Add Button.
     *
     * @return the EServicesDesignsNewAppPriority class instance.
     */
    public DesignsNewAppDesignDetailsBase clickAddConvClaimButton() {
        this.clickA4J(addConvClaim);
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * Click on Add Designer Button.
     *
     * @return the EServices_DesignsNewApp_Designers class instance.
     */
    public DesignsNewAppDesignDetailsBase clickAddDesignerButton() {
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(addDesigner));
        addDesigner.click();
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * Click on Add Button.
     *
     * @return the EServicesDesignsNewAppPriority class instance.
     */
    public DesignsNewAppDesignDetailsBase clickAdditionalConvClaimButton() {
        this.clickA4J(additionalConvClaim);
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * @return DesignsNewAppDesignDetailsBase instance
     */
    public DesignsNewAppDesignDetailsBase selectApplicant() {
        if (!getDataValue(DesignsParameters.DESIGNER_SELECT_APPLICANT.getValue()).trim().equals("")) {
            String[] names = getData().get(DesignsParameters.DESIGNER_SELECT_APPLICANT.getValue()).split(";");
            for (int i = 0; i < names.length; i++) {
                selectApplicant(names[i]);
                waitWhileEServicesBusy();
            }
        }
        return this;
    }

    /**
     * @param applicantName
     *            ...
     * @return DesignsNewAppDesignDetailsBase instance
     */
    public DesignsNewAppDesignDetailsBase selectApplicant(String applicantName) {
        WebElement label = (new WebDriverWait(driver, timeout)).ignoring(
                                                                         StaleElementReferenceException.class).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//label[contains(text(), '"
                                                                                 + applicantName + "')]")));
        String id = label.getAttribute("for");
        WebElement cb = driver.findElement(By.id(id));
        if (!cb.isSelected()) {
            this.clickA4J(cb);
        }
        return this;
    }

    /**
     * Set default value to Application Number Text field.
     *
     * @return the EServicesDesignsNewAppPriority class instance.
     */
    public DesignsNewAppDesignDetailsBase setApplicationNumberTextField() {
        String countryName = getDataValue(DesignsParameters.CONV_CLAIM_NUMBER.getValue());
        if (countryName.equals("Office for Harmonization in the Internal Market (Trade Marks and Designs) (OHIM)")
                && EnvironmentVariables.getEnvironmentName().equals("CIDev")) {
            countryName = "European Union Intellectual Property Office (EUIPO)";
        }

        return setApplicationNumberTextField(countryName);
    }

    /**
     * Set value to Application Number Text field.
     * 
     * @param applicationNumberValue
     *            ...
     * @return the EServicesDesignsNewAppPriority class instance.
     */
    public DesignsNewAppDesignDetailsBase setApplicationNumberTextField(String applicationNumberValue) {
        applicationNumber.sendKeys(applicationNumberValue);
        return this;
    }

    /**
     * Set we Want To Claim Convention Priority For This Design That Was Applied For In Another Country In The Past Six
     * Months Checkbox field.
     *
     * @return the EServicesDesignsNewAppPriority class instance.
     */
    public DesignsNewAppDesignDetailsBase setConventionClaimCheckboxField() {
        (new WebDriverWait(driver,
                timeout)).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.presenceOfElementLocated(By.id(CONV_CLAIM_ID)));
        WaitTool.sleep(1000);
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(conventionClaim));

        if (!conventionClaim.isSelected()) {
            conventionClaim.click();
            waitWhileEServicesBusy();
        }
        return this;
    }

    /**
     * Set value to Country Drop Down List field.
     * 
     * @param countryValue
     *            ...
     * @return the EServicesDesignsNewAppPriority class instance.
     */
    public DesignsNewAppDesignDetailsBase setCountryDropDownListField(String countryValue) {
        new Select(country).selectByVisibleText(countryValue);
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * Set default value to Family Name Text field.
     *
     * @return the EServices_DesignsNewApp_Designers class instance.
     */
    public DesignsNewAppDesignDetailsBase setFamilyNameTextField() {
        if (getData().containsKey(DesignsParameters.DESIGNER_FAMILY_NAME.getValue())) {
            return setFamilyNameTextField(getData().get(DesignsParameters.DESIGNER_FAMILY_NAME.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * Set value to Family Name Text field.
     * 
     * @param familyNameValue
     *            ...
     * @return the EServices_DesignsNewApp_Designers class instance.
     */
    public DesignsNewAppDesignDetailsBase setFamilyNameTextField(String familyNameValue) {
        familyName.sendKeys(familyNameValue);
        return this;
    }

    /**
     * Set default value to Filing Date Text field.
     *
     * @return the EServicesDesignsNewAppPriority class instance.
     */
    public DesignsNewAppDesignDetailsBase setFilingDateTextField() {
        return setFilingDateTextField(getDataValue(DesignsParameters.CONV_CLAIM_FILING_DATE.getValue()));
    }

    /**
     * Set value to Filing Date Text field.
     * 
     * @param filingDateValue
     *            ...
     * @return the EServicesDesignsNewAppPriority class instance.
     */
    public DesignsNewAppDesignDetailsBase setFilingDateTextField(String filingDateValue) {
        (new WebDriverWait(driver,
                timeout)).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.presenceOfElementLocated(By.id(FILING_DATE_ID)));
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(filingDate));
        filingDate.sendKeys(filingDateValue);
        return this;
    }

    /**
     * Set default value to Given Names Text field.
     *
     * @return the EServices_DesignsNewApp_Designers class instance.
     */
    public DesignsNewAppDesignDetailsBase setGivenNamesTextField() {
        if (getData().containsKey(DesignsParameters.DESIGNER_GIVEN_NAME.getValue())) {
            return setGivenNamesTextField(getDataValue(DesignsParameters.DESIGNER_GIVEN_NAME.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * Set value to Given Names Text field.
     * 
     * @param givenNamesValue
     *            ...
     * @return the EServices_DesignsNewApp_Designers class instance.
     */
    public DesignsNewAppDesignDetailsBase setGivenNamesTextField(String givenNamesValue) {
        new WebDriverWait(driver, timeout).until(ExpectedConditions.visibilityOf(givenNames));
        givenNames.sendKeys(givenNamesValue);
        return this;
    }

    /**
     * Set value to No Radio Button field.
     *
     * @return the EServicesDesignsNewAppPriority class instance.
     */
    public DesignsNewAppDesignDetailsBase setKnownAppNoRadioButtonField() {
        for (WebElement el : knownAppNumber) {
            if (el.getAttribute(VALUE).equals("false")) {
                if (!el.isSelected()) {
                    el.click();
                }
                break;
            }
        }
        return this;
    }

    /**
     * Set value to Yes Radio Button field.
     *
     * @return the EServicesDesignsNewAppPriority class instance.
     */
    public DesignsNewAppDesignDetailsBase setKnownAppYesRadioButtonField() {
        for (WebElement el : knownAppNumber) {
            if (el.getAttribute(VALUE).equals("true")) {
                if (!el.isSelected()) {
                    el.click();
                }
                break;
            }
        }
        return this;
    }

    /**
     * Set default value to Provide A Generic Products To Which The Design Relates Eg. A Tshirt Or Plate Cup Textarea
     * field.
     *
     * @return the EServices_DesignsNewApp_Products class instance.
     *
     */
    public DesignsNewAppDesignDetailsBase setProductTextareaField() {
        return setProductTextareaField(getDataValue(DesignsParameters.GENERIC_PRODUCTS.getValue()));
    }

    /**
     * Set value to Provide A Generic Products To Which The Design Relates Eg. A Tshirt Or Plate Cup Textarea field.
     *
     * @param productName
     *            ...
     * @return the EServices_DesignsNewApp_Products class instance.
     */
    public DesignsNewAppDesignDetailsBase setProductTextareaField(String productName) {
        product.sendKeys(productName);
        return this;
    }

    /**
     * @return DesignsNewAppDesignDetailsBase instance
     */
    public DesignsNewAppDesignDetailsBase setRequestTypeRadioButtonField() {
        String requestTypeValue = getDataValue(DesignsParameters.REQUEST_TYPE.getValue()).trim();
        if ("".equals(requestTypeValue)) {
            return this;
        }
        else {
            return setRequestTypeRadioButtonField(requestTypeValue);
        }
    }

    /**
     * Set the radio button to the parameter value
     *
     * @param requestTypeValue
     *            REGISTERED; REGISTERED_AND_EXAMINED; PUBLISHED; NONE
     *
     * @return the EServicesDesignsNewAppPriority class instance.
     */
    public DesignsNewAppDesignDetailsBase setRequestTypeRadioButtonField(String requestTypeValue) {
        (new WebDriverWait(driver,
                timeout)).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.presenceOfElementLocated(By.id("idWizardForm:idSelectDesignProtectionRadio:0")));

        for (WebElement el : requestType) {
            if (el.getAttribute(VALUE).equals(requestTypeValue)) {
                flash(el);
                if (!el.isSelected()) {
                    this.clickA4J(el);
                    waitWhileEServicesBusy();
                }
                break;
            }
        }
        return this;
    }

    /**
     * Set the radio button when using Futher Response only
     * 
     * REGISTERED_AND_EXAMINED
     * 
     * @return DesignsNewAppDesignDetailsBase class instance.
     */
    public DesignsNewAppDesignDetailsBase setRequestTypeRadioButtonFieldRegandExam() {
        (new WebDriverWait(driver,
                timeout)).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.presenceOfElementLocated(By.id("idWizardForm:idCheckRegisteredExamSr")));
        if (!registeredAndExamined.isSelected()) {
            registeredAndExamined.click();
            waitWhileEServicesBusy();
        }

        return this;
    }

    /**
     * Set default value to Statement Of Newness And Distinctiveness Textarea field.
     *
     * @return the EServices_DesignsNewApp_Products class instance.
     */
    public DesignsNewAppDesignDetailsBase setStatementOfNewnessAndDistinctivenessTextareaField() {
        return setStatementOfNewnessAndDistinctivenessTextareaField(getDataValue(DesignsParameters.STATEMENT_OF_NEWNESS.getValue()));
    }

    /**
     * Set value to Statement Of Newness And Distinctiveness Textarea field.
     * 
     * @param son
     *            statement of newness and distinctiveness
     * @return the EServices_DesignsNewApp_Products class instance.
     */
    public DesignsNewAppDesignDetailsBase setStatementOfNewnessAndDistinctivenessTextareaField(String son) {
        statementOfNewnessAndDistinctiveness.sendKeys(son);
        return this;
    }

    /**
     * Set default value to Title Drop Down List field.
     *
     * @return the EServices_DesignsNewApp_Designers class instance.
     */
    public DesignsNewAppDesignDetailsBase setTitleDropDownListField() {
        String personTitle = getDataValue(DesignsParameters.DESIGNER_TITLE.getValue()).trim();
        if (!personTitle.equals("")) {
            return setTitleDropDownListField(personTitle);
        }
        else {
            return this;
        }
    }

    /**
     * Set value to Title Drop Down List field.
     * 
     * @param titleValue
     *            ...
     * @return the EServices_DesignsNewApp_Designers class instance.
     */
    public DesignsNewAppDesignDetailsBase setTitleDropDownListField(String titleValue) {
        if (!titleValue.trim().equals("")) {
            new Select(title).selectByVisibleText(titleValue);
            waitWhileEServicesBusy();
        }
        return this;
    }

    /**
     * @param files
     *            a ';' delineated list of file names
     * @return DesignsNewAppDesignDetailsBase instance
     */
    public DesignsNewAppDesignDetailsBase addFiles(String files) {
        String[] fileNames;

        fileNames = files.split(";");
        for (int i = 0; i < fileNames.length; i++) {

            if (!(i == 0)) {
                (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(addRep));
                addRep.click();
                waitWhileEServicesBusy();
                // Sleep needed as sometimes Add Represntations button is
                // getting frozen
                WaitTool.sleep(1000);
                (new WebDriverWait(driver,
                        timeout)).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.presenceOfElementLocated(By.id(ADD_FILED_ID)));
                (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(addFileId));

            }

            addFilesCommon(fileNames[i]);

        }
        return null;
    }

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }
}
