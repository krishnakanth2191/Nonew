package au.gov.ipaustralia.selenium.eservices.pageobjects.patents;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import au.gov.ipaustralia.automation.selenium.helpers.db.ATMOSSDBManager;
import au.gov.ipaustralia.automation.selenium.helpers.db.DatabaseManagerException;
import au.gov.ipaustralia.selenium.helpers.wait.WaitTool;

/**
 * Models the Renewal of IP Right(s) page in eServices
 * 
 * @author Suresh Thumma
 */
public class RenewalOfIPRights extends PatentBasePage {

    private static final String PAGE_TITLE = "RENEWAL OF IP RIGHT(S)";
    private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/eservices\\/renewal-wizard\\.xhtml";

    @FindBy(id = "idWizardForm:idFldUserRef")
    private WebElement yourRef;

    @FindBy(id = "idWizardForm:idFldIPRightType")
    private WebElement ipRightType;

    @FindBy(id = "idWizardForm:idFldIpRightNumber")
    private WebElement ipRightNumber;

    @FindBy(id = "idWizardForm:idAddIpRightAction")
    private WebElement addButton;

    @FindBy(id = "idWizardForm:idBtnACTION_ID_ADD_TO_CART")
    private WebElement addToCart;

    public RenewalOfIPRights(WebDriver driver) {
        super(driver);
    }

    /**
     * @param refText
     *            ...
     * @return RenewalOfIPRights instance
     */
    public RenewalOfIPRights setYourRefText(String refText) {
        yourRef.sendKeys(refText);
        return this;
    }

    /**
     * @param type
     *            ...
     * @return RenewalOfIPRights instance
     */
    public RenewalOfIPRights selectIPRightType(String type) {
        new Select(ipRightType).selectByVisibleText(type);
        return this;
    }

    /**
     * @param number
     *            ...
     * @return RenewalOfIPRights instance
     */
    public RenewalOfIPRights setIPRightNumber(String number) {
        ipRightNumber.sendKeys(number);
        return this;
    }

    /**
     * @return RenewalOfIPRights instance
     */
    public RenewalOfIPRights clickAddButton() {
        addButton.click();
        return this;
    }

    /**
     * @return RenewalOfIPRights instance
     */
    public RenewalOfIPRights clickAddToCartButton() {
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(addToCart));
        addToCart.click();
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * @return Renewable TM Number in IP Right Number Field
     */
    public RenewalOfIPRights setTMRenewalNumber() throws DatabaseManagerException {
        String tmRenewalNumber = "";
        WaitTool.waitUntilClickable(driver, timeout, ipRightNumber);
        tmRenewalNumber = (new ATMOSSDBManager().getTradeMarkRenewalNumber().getFirstDataItem().toString());
        ipRightNumber.sendKeys(tmRenewalNumber);
        return this;
    }

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

}
