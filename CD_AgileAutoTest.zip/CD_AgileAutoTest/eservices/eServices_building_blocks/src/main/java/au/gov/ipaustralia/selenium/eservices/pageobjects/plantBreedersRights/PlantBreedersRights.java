package au.gov.ipaustralia.selenium.eservices.pageobjects.plantBreedersRights;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import au.gov.ipaustralia.selenium.eservices.pageobjects.common.BasePageEServices;

public class PlantBreedersRights extends BasePageEServices {

    private static final String PAGE_TITLE = "PLANT BREEDER'S RIGHTS eSERVICES";
    private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/home\\/forms.xhtml?tab=PBR";

    @FindBy(id = "idpbrGeneralLinkText")
    private WebElement generalRequestLink;

    @FindBy(id = "idPbrNewAppLinkText")
    private WebElement newAppLink;

    public PlantBreedersRights(WebDriver driver) {
        super(driver);
    }

    public PlantBreedersRights clickGeneralRequestLink() {
        generalRequestLink.click();
        return this;
    }

    public PlantBreedersRights clickNewAppLink() {
        newAppLink.click();
        return this;
    }

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

}
