package au.gov.ipaustralia.selenium.eservices.pageobjects.patents;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import au.gov.ipaustralia.selenium.helpers.wait.WaitTool;

/**
 * Models the Patents Examination Submitter Details page in eServices
 * 
 * @author Jonathan Eastman
 *
 */

public class PatentsExaminationSubmitterDetails extends PatentBasePage {
    
    private static final String PAGE_TITLE = "SUBMITTER DETAILS";
    private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/eservices\\/patent\\/exam-request\\/exam-request-wizard.xhtml";
    
    @FindBy(id = "idWizardForm:idSelectRoleType:0")
    private WebElement applicantRadioButton;
    
    @FindBy(id = "idWizardForm:idReference")
    private WebElement yourReferenceTextField;
    
    public PatentsExaminationSubmitterDetails(WebDriver driver) {
        super(driver);
        
    }
    
    /**
     * Selects the Applicant radio button
     * 
     * @return Returns Patents Examination Submitter Details page with Applicant Radio Button selected
     */
    public PatentsExaminationSubmitterDetails clickApplicantRadioButton() {
        applicantRadioButton.click();
        return this;
    }
    
    
    /**
     * Sets the Reference text field to parsed string
     * 
     * @param reference Custom Reference text
     * 
     * @return Returns this object with Reference text set to customer reference text
     */
    public PatentsExaminationSubmitterDetails setYourReferenceTextField(String reference) {
        yourReferenceTextField.sendKeys(reference);
        WaitTool.sleep(500);
        return this;
    }

    /**
     * Verify that the page loaded completely.
     *
     * @return boolean.
     */
    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    /**
     * Verify that the page loaded completely.
     *
     * @return boolean.
     */
    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

}
