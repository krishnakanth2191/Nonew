package au.gov.ipaustralia.selenium.eservices.pageobjects.designs;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Models the MULTIPLE DESIGNS page in eServices
 * 
 * @author Anthony Hallett
 *
 */
public class DesignsNewAppMultipleDesigns extends DesignsNewAppDesignDetailsBase {

    private static final String PAGE_TITLE = "MULTIPLE DESIGNS";
    private static final String PAGE_URL =
            "\\/ICMWebUI\\/views\\/private\\/eservices\\/design\\/new-application\\/new-app-wizard.xhtml";

    @FindBy(id = "idWizardForm:idNumberOfDesignsSelect")
    private WebElement numberOfDesigns;

    static final String STEP2_ID = "idWizardForm:tabProductsProceedButton";
    @FindBy(id = STEP2_ID)
    private WebElement proceedToStep2;

    @FindBy(id = "idWizardForm:tabRepresentationsProceedButton")
    private WebElement proceedToStep3;

    static final String CUST_REF_ID = "idWizardForm:reference";
    @FindBy(id = CUST_REF_ID)
    private WebElement customerRef;

    @FindBy(id = "idWizardForm:tabAdditionalRequestsProceedButton")
    private WebElement proceedToStep4;

    @FindBy(id = "idWizardForm:saveDesignButton")
    private WebElement saveDesign;

    @FindBy(id = "idWizardForm:idAddDesignButton")
    private WebElement addDesign;

    /**
     * @param driver
     *            the WebDriver
     */
    public DesignsNewAppMultipleDesigns(WebDriver driver) {
        super(driver);
    }

    /**
     * Set default value to How Many Designs Are There In This Application Drop Down List field.
     *
     * @return the EServicesDesignsNewAppMultipleDesigns class instance.
     */
    public DesignsNewAppMultipleDesigns setNumberOfDesignsDropDownListField() {
        return setNumberOfDesignsDropDownListField(getDataValue("NUMBER_OF_DESIGNS"));
    }

    /**
     * Set value to How Many Designs Are There In This Application Drop Down List field.
     *
     * @param howManyDesigns
     *            ...
     * @return the EServicesDesignsNewAppMultipleDesigns class instance.
     */
    public DesignsNewAppMultipleDesigns setNumberOfDesignsDropDownListField(String howManyDesigns) {
        new Select(numberOfDesigns).selectByVisibleText(howManyDesigns);
        return this;
    }

    /**
     * Click on Save Design Button.
     *
     * @return the EServicesDesignsNewAppDesigners class instance.
     */
    public DesignsNewAppMultipleDesigns clickSaveDesignButton() {
        (new WebDriverWait(driver,
                timeout).ignoring(StaleElementReferenceException.class)).until(ExpectedConditions.elementToBeClickable(saveDesign));
        saveDesign.click();
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * Click on Add Design Button.
     *
     * @return the EServicesDesignsNewAppDesigners class instance.
     */
    public DesignsNewAppMultipleDesigns clickAddDesignButton() {
        (new WebDriverWait(driver,
                timeout).ignoring(StaleElementReferenceException.class)).until(ExpectedConditions.elementToBeClickable(addDesign));
        addDesign.click();
        return this;
    }

    /**
     * Click on Proceed to Step 4 Button.
     *
     * @return the EServicesDesignsNewAppDesigners class instance.
     */
    public DesignsNewAppMultipleDesigns clickProceedToStep4Button() {
        (new WebDriverWait(driver,
                timeout).ignoring(StaleElementReferenceException.class)).until(ExpectedConditions.elementToBeClickable(proceedToStep4));
        proceedToStep4.click();
        return this;
    }

    /**
     * Click on Proceed to Step 3 Button.
     *
     * @return the EServicesDesignsNewAppDesigners class instance.
     */
    public DesignsNewAppMultipleDesigns clickProceedToStep3Button() {
        (new WebDriverWait(driver,
                timeout).ignoring(StaleElementReferenceException.class)).until(ExpectedConditions.elementToBeClickable(proceedToStep3));
        proceedToStep3.click();
        return this;
    }

    /**
     * Click on Proceed to Step 2 Button.
     *
     * @return the EServicesDesignsNewAppDesigners class instance.
     */
    public DesignsNewAppMultipleDesigns clickProceedToStep2Button() {
        (new WebDriverWait(driver,
                timeout)).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.presenceOfElementLocated(By.id(STEP2_ID)));
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(proceedToStep2));
        proceedToStep2.click();
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * Set default value to Customer Reference Text field.
     *
     * @return the EServicesDesignsNewAppDesigners class instance.
     */
    public DesignsNewAppMultipleDesigns setCustomerRefTextField() {
        if (getData().containsKey(DesignsParameters.CUSTOMER_REFERENCE.getValue())) {
            return setCustomerRefTextField(getDataValue(DesignsParameters.CUSTOMER_REFERENCE.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * Set value to Customer Reference Text field.
     * 
     * @param referenceValue
     *            ...
     * @return the EServicesDesignsNewAppDesigners class instance.
     */
    public DesignsNewAppMultipleDesigns setCustomerRefTextField(String referenceValue) {
        (new WebDriverWait(driver,
                timeout)).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.presenceOfElementLocated(By.id(CUST_REF_ID)));
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(customerRef));
        customerRef.click();
        customerRef.sendKeys(referenceValue);
        return this;
    }

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }
}
