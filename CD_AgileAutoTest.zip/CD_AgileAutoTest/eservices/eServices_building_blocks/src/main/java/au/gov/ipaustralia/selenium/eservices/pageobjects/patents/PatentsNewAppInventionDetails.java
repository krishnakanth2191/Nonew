package au.gov.ipaustralia.selenium.eservices.pageobjects.patents;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class PatentsNewAppInventionDetails extends PatentBasePage {

	private static final String PAGE_TITLE = "INVENTION DETAILS";
	private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/eservices\\/patent\\/.*\\/.*-wizard.xhtml";

	@FindBy(id = "idWizardForm:idInputInventionTitle")
	private WebElement description;

	@FindBy(id = "idWizardForm:idInventorBtnAdd")
	private WebElement addInventor;

	@FindBy(id = "idWizardForm:idInventorSelectTitle")
	private WebElement inventorTitle;

	@FindBy(id = "idWizardForm:idInventorInputFirstName")
	private WebElement inventorGivenName;

	@FindBy(id = "idWizardForm:idInventorInputLastName")
	private WebElement inventorLastName;

	@FindBy(id = "idWizardForm:idInventorBtnSave")
	private WebElement saveInventor;

	public PatentsNewAppInventionDetails(WebDriver driver) {
		super(driver);
	}

	public PatentsNewAppInventionDetails setInventionDescription(String inventionDetail) {
		description.sendKeys(inventionDetail);
		return this;
	}

	public PatentsNewAppInventionDetails clickAddInventor() {
		addInventor.click();
		return this;
	}

	public PatentsNewAppInventionDetails selectInventorTitle(String title) {
		new Select(inventorTitle).selectByVisibleText(title);
		return this;
	}

	public PatentsNewAppInventionDetails setInventorName(String inventorGName) {
		inventorGivenName.sendKeys(inventorGName);
		return this;
	}

	public PatentsNewAppInventionDetails setInventorLastName(String inventorLName) {
		inventorLastName.sendKeys(inventorLName);
		return this;
	}

	public PatentsNewAppInventionDetails clickSaveInventor() {
		saveInventor.click();
		return this;
	}

	/**
	 * VerifyPageTitle Matches with given title.
	 *
	 * @return boolean.
	 */

	public boolean verifyPageUrl() {
		return verifyPageUrl(PAGE_URL);
	}

	/**
	 * Verify that the page loaded completely.
	 *
	 * @return boolean.
	 */
	public boolean verifyPageTitle() {
		return verifyPageTitle(PAGE_TITLE);
	}

	public boolean verifyPageLoaded() {
		return verifyPageTitle();
	}

}
