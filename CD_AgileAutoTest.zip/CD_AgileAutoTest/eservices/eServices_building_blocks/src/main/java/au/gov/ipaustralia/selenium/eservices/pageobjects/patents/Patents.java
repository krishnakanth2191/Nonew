package au.gov.ipaustralia.selenium.eservices.pageobjects.patents;

import static org.assertj.core.api.Assertions.assertThat;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Patents extends PatentBasePage {

    private static final String PAGE_TITLE = "PATENT eSERVICES";
    private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/home\\/forms.xhtml\\?tab=PATENT";

    @FindBy(id = "idPatentGeneralLinkText")
    private WebElement generalEServiceRequest;

    @FindBy(id = "idNewPatentStandardLinkText")
    private WebElement newStandardPatent;

    @FindBy(id = "idRenewPatent")
    private WebElement renewPatent;

    @FindBy(id = "idPatentExamReqLinkText")
    private WebElement examinationRequest;

    @FindBy(id = "idNewPatentNPELinkText")
    private WebElement nationalPhase;

    public Patents(WebDriver driver) {
        super(driver);

        assertThat(verifyPageUrl()).as("Patent eServices page URL").isTrue();
        assertThat(verifyPageLoaded()).as("Patent eServices page is loaded").isTrue();
    }

    /**
     * Click on General Eservices link
     *
     * @return the Patets_Home class instance.
     */
    public Patents clickGeneralEServicesLink() {
        generalEServiceRequest.click();
        return this;
    }

    /**
     * Click on New Standard Patent Link
     *
     * @return the Patets_Home class instance.
     */
    public Patents clickNewStandardPatent() {
        newStandardPatent.click();
        return this;
    }

    /**
     * Click on Renew Patent Link
     *
     * @return the Patets_Home class instance.
     */
    public Patents clickRenewPatent() {
        renewPatent.click();
        return this;
    }

    /**
     * Click on Examination Request Link
     *
     * @return the Patets_Home class instance.
     */
    public Patents clickExaminationRequest() {
        examinationRequest.click();
        return this;
    }

    /**
     * Click on National Phase Link
     *
     * @return the Patets_Home class instance.
     */
    public Patents clickNationalPhase() {
        nationalPhase.click();
        return this;
    }

    /**
     * VerifyTables that current page URL matches the expected URL.
     *
     * @return boolean.
     */
    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    /**
     * VerifyTables that the page loaded completely.
     *
     * @return boolean.
     */
    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    /**
     * VerifyPageTitle Matches with given title.
     *
     * @return boolean.
     */
    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

}
