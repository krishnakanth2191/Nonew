package au.gov.ipaustralia.selenium.eservices.pageobjects.designs;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Models the History page in eServices
 * 
 * @author Anthony Hallett
 *
 */
public class History extends DesignsBasePage {
    private static final String PAGE_TITLE = "eSERVICES HISTORY";
    private static final String PAGE_URL =
            "\\/ICMWebUI\\/views\\/private\\/portfolio\\/srhistory\\/service-request-history.xhtml";

    @FindBy(id = "serviceRequestHistoryForm:idServiceRequestHistoryTable:0:batchId")
    private WebElement rowOneBatchId;

    @FindBy(id = "serviceRequestHistoryForm:idServiceRequestHistoryTable:0:ipRightId")
    private WebElement rowOneIPNumber;

    @FindBy(id = "serviceRequestHistoryForm:idServiceRequestHistoryTable")
    private WebElement historyTable;

    public History(WebDriver driver) {
        super(driver);
        assertThat(verifyPageUrl()).as("eSERVICES HISTORY URL").isTrue();
        assertThat(verifyPageLoaded()).as("'eSERVICES HISTORY' page loaded").isTrue();
    }

    /**
     * @return the newly created batch id (hopefully :-))
     */
    public String getFirstBatchID() {
        return rowOneBatchId.getText();
    }

    /**
     * @return the newly created IpNumber (hopefully :-))
     */
    public String getFirstIPNumber() {
        return rowOneIPNumber.getText();
    }

    public History openView(String serviceRequestType,
                            String ipRight) {
        boolean found = false;
        List<WebElement> rows =
                driver.findElements(By.xpath("//tbody[@id='serviceRequestHistoryForm:idServiceRequestHistoryTable:tb']/tr"));
        for (int i = 0; i < rows.size(); i++) {
            String rowId = "serviceRequestHistoryForm:idServiceRequestHistoryTable:" + i;
            String type = driver.findElement(By.id(rowId + ":srType")).getText();
            String ipRightNum = driver.findElement(By.id(rowId + ":ipRightId")).getText();
            if (type.equals(serviceRequestType) && ipRightNum.equals(ipRight)) {
                found = true;
                WebElement link = driver.findElement(By.id(rowId + ":idPreviewBtn"));
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", link);
                break;
            }
        }
        if (!found) {
            String msge = String.format("%s SR for right number %s not found in first %s rows of history.",
                                        serviceRequestType,
                                        ipRight,
                                        rows.size());
            throw new NullPointerException(msge);
        }

        return this;
    }

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);

    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE, "#page-header > h2 > span");

    }

}
