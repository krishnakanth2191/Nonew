package au.gov.ipaustralia.selenium.eservices.pageobjects.designs;

/**
 * Calling Enum Values
 * 
 * @author Suresh Thumma
 *
 */
public enum DesignsParameters {

                               SKIP_ROW("SKIP_ROW"),
                               USER_NAME("USER_NAME"),
                               CATEGORY("CATEGORY"),
                               ASSOCIATED_IPRIGHT("ASSOCIATED_IPRIGHT"),
                               CUSTOMER_REFERENCE("CUSTOMER_REFERENCE"),
                               CUSTOMER_TYPE("CUSTOMER_TYPE"),
                               CUSTOMER_TYPE_APPLICANT("APPLICANT"),
                               NEW_APPLICANT_TYPE("NEW_APPLICANT_TYPE"),
                               NEW_APPLICANT_TYPE_INDIVIDUAL("INDIVIDUAL"),
                               NEW_APPLICANT_TYPE_ORGANISATION("ORGANISATION"),
                               TITLE_OR_LEGAL_NAME("TITLE_OR_LEGAL_NAME"),
                               GIVEN_NAME_OR_ACN("GIVEN_NAME_OR_ACN"),
                               FAMILY_NAME_OR_ABN("FAMILY_NAME_OR_ABN"),
                               COUNTRY("COUNTRY"),
                               ADDRESS_LINE_1("ADDRESS_LINE_1"),
                               ADDRESS_LINE_2("ADDRESS_LINE_2"),
                               ADDRESS_LINE_3("ADDRESS_LINE_3"),
                               SUBURB_TOWN("SUBURB_TOWN"),
                               STATE("STATE"),
                               POSTCODE("POSTCODE"),
                               DESIGNER_SELECT_APPLICANT("DESIGNER_SELECT_APPLICANT"),
                               DESIGNER_TITLE("DESIGNER_TITLE"),
                               DESIGNER_GIVEN_NAME("DESIGNER_GIVEN_NAME"),
                               DESIGNER_FAMILY_NAME("DESIGNER_FAMILY_NAME"),
                               GENERIC_PRODUCTS("GENERIC_PRODUCTs"),
                               STATEMENT_OF_NEWNESS("STATEMENT_OF_NEWNESS"),
                               FILE_NAMES("FILE_NAMES"),
                               CONV_CLAIM_NUMBER("CONV_CLAIM_NUMBER"),
                               CONV_CLAIM_FILING_DATE("CONV_CLAIM_FILING_DATE"),
                               CONV_CLAIM_COUNTRY("CONV_CLAIM_COUNTRY"),
                               REQUEST_TYPE("REQUEST_TYPE"),
                               YOUR_CART_REFERENCE("YOUR_CART_REFERENCE"),
                               NAME_ON_CARD("NAME_ON_CARD"),
                               CREDIT_CARD_TYPE("CREDIT_CARD_TYPE"),
                               CREDIT_CARD_NUMBER("CREDIT_CARD_NUMBER"),
                               EXPIRY_MONTH("EXPIRY_MONTH"),
                               EXPIRY_YEAR("EXPIRY_YEAR"),
                               CCV("CCV"),
                               DESIGNERS("DESIGNERS"),
                               FILE_NAME("FILE_NAME"),
                               FILE_PATH("FILE_PATH"),
                               ESERVICES("ESERVICES");
    private String header;

    DesignsParameters(String value) {
        this.header = value;
    }

    public String getValue() {
        return header;
    }

}
