package au.gov.ipaustralia.selenium.eservices.pageobjects.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import au.gov.ipaustralia.automation.selenium.helpers.db.PPAYDBManager;
import au.gov.ipaustralia.selenium.eservices.pageobjects.designs.DesignsBasePage;

public class MakeAPayment extends DesignsBasePage {

    private static final String PAGE_TITLE = "PAYMENT DETAILS";
    private static final String PAGE_URL =
            "\\/ICMWebUI\\/views\\/private\\/make-a-payment\\/make-a-payment-wizard.xhtml";

    @FindBy(id = "idWizardForm:idFldUserRef")
    private WebElement yourReference;

    @FindBy(id = "idWizardForm:paymentOption:3")
    private WebElement otherPayment;

    @FindBy(id = "idWizardForm:amountField")
    private WebElement paymentAmount;

    @FindBy(id = "idWizardForm:otherPaymentInstructions")
    private WebElement paymentInstructions;
    
    @FindBy(id = "idWizardForm:paymentOption:0")
    private WebElement invitationToPay;
    
    @FindBy(id = "idWizardForm:itpBusinessLineField")
    private WebElement typeOfIPRight;
    
    @FindBy(id = "idWizardForm:itpField")
    private WebElement itpReferenceField;
    
    @FindBy(id = "idWizardForm:idLookupItpAction")
    private WebElement retrieveDetailsITP;
    
    @FindBy(id = "idWizardForm:patenItpPicklist:0:SelectBox")
    private WebElement itpPayNow;

    public MakeAPayment(WebDriver driver) {
        super(driver);
    }

    public MakeAPayment setYourReferenceTextField(String yourReferenceValue) {
        yourReference.sendKeys(yourReferenceValue);
        return this;
    }

    public MakeAPayment setPaymentAmount(String amount) {
        paymentAmount.sendKeys(amount);
        return this;
    }

    public MakeAPayment setPaymentInstructions(String instructions) {
        paymentInstructions.sendKeys(instructions);
        return this;
    }

    public MakeAPayment clickOtherPayment() {
        otherPayment.click();
        return this;
    }
    
    /**
     * Selects the Invitation to Pay radio button
     * 
     * @return This object provisioned for entering IP Right Type details
     */
    public MakeAPayment clickInvitationToPay() {
        invitationToPay.click();
        waitWhileEServicesBusy();
        return this;
    }
    
    /**
     * Selects IP Right type from drop down box
     * 
     * @param ipRightType Type of IP Right to make payment for, either Patents or Designs
     * 
     * @return This object provisioned for entering ITP Request details
     */
    public MakeAPayment setIPRightType(String ipRightType) {
        new Select(typeOfIPRight).selectByVisibleText(ipRightType);
        waitWhileEServicesBusy();
        return this;
    }
    
    /**
     * Inserts and receives ITP Payment number details
     * 
     * @return Reference to object following successful load with ITP Details
     */
    public MakeAPayment loadITPPaymentNumber() {
        String itpNumber = new PPAYDBManager().getITPNumber().getFirstDataItem().toString();
        itpReferenceField.sendKeys(itpNumber);
        retrieveDetailsITP.click();
        waitWhileEServicesBusy();
        return this;
    }
    
    /**
     * Click first Pay Now check box in ITP Payment details
     * 
     * @return This object with updated payment amount details and next button enabled
     */
    public MakeAPayment clickPayNow() {
        itpPayNow.isEnabled();
        itpPayNow.click();
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * Sets payment amount from data provider AMOUNT column
     * 
     * @return Make A Payment instance with payment amount data included
     */
    public MakeAPayment setPaymentAmount() {
        if (getData().containsKey("AMOUNT")) {
            return setPaymentAmount(getData().get("AMOUNT"));
        }
        else {
            return this;
        }
    }

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

}
