package au.gov.ipaustralia.selenium.eservices.pageobjects.generalrequest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Models the General Request Details page for eServices
 * 
 * @author Danielle Orth - 23/11/2017
 *
 */

public class GeneralRequestDetails extends GeneralRequestBasePage {

	private static final String PAGE_TITLE = "GENERAL eSERVICE REQUEST DETAILS";
	private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/eservices\\/.*\\/.*-wizard.xhtml";

	@FindBy(id = "idWizardForm:idAddIpRightAction")
	private WebElement retrievePatentDetails;

	@FindBy(id = "idWizardForm:idNumberOfMonthsSelect")
	private WebElement monthsToPayDropdownList;

	/**
	 * Page Constructor with WebDriver
	 */
	public GeneralRequestDetails(WebDriver driver) {
		super(driver);
	}

	/**
	 * Select Number of Months to Pay option
	 * 
	 * @return String of the number of Months to Pay as monthsToPay
	 */
	public GeneralRequestDetails setMonthsToPay(String monthsToPay) {
		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(monthsToPayDropdownList));
		new Select(monthsToPayDropdownList).selectByVisibleText(monthsToPay);
		waitWhileEServicesBusy();
		return this;
	}

	/**
	 * Click listener for retrieving patent information
	 * 
	 * @return Patent details are displayed
	 */
	public GeneralRequestDetails clickAddDetailsButton() {
		retrievePatentDetails.click();
		waitWhileEServicesBusy();
		return this;
	}

	/**
	 * Verify that current page URL matches the expected URL.
	 *
	 * @return true for URL loaded correctly
	 */
	public boolean verifyPageUrl() {
		return verifyPageUrl(PAGE_URL);
	}

	/**
	 * Verify that the page loaded completely.
	 *
	 * @return true for page loaded correctly
	 */
	public boolean verifyPageTitle() {
		return verifyPageTitle(PAGE_TITLE);
	}

	public boolean verifyPageLoaded() {
		return verifyPageTitle();
	}
}
