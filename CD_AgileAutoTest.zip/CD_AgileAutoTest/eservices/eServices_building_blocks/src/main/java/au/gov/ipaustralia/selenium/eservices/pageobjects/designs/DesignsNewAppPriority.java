package au.gov.ipaustralia.selenium.eservices.pageobjects.designs;

import static org.assertj.core.api.Assertions.assertThat;

import org.openqa.selenium.WebDriver;

/**
 * Models the PRIORITY/REQUESTS page in eServices
 * 
 * @author Anthony Hallett
 *
 */
public class DesignsNewAppPriority extends DesignsNewAppDesignDetailsBase {
    private static final String PAGE_TITLE = "PRIORITY/REQUESTS";

    public DesignsNewAppPriority(WebDriver driver) {
        super(driver);

        assertThat(verifyPageUrl()).as("PRIORITY/REQUESTS page URL").isTrue();
        assertThat(verifyPageLoaded()).as("PRIORITY/REQUESTS page loaded").isTrue();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }
}
