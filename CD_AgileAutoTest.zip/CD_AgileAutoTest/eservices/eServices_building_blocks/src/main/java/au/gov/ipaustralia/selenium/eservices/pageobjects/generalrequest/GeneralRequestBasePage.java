package au.gov.ipaustralia.selenium.eservices.pageobjects.generalrequest;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import au.gov.ipaustralia.automation.selenium.helpers.db.PAMSDBManager;
import au.gov.ipaustralia.selenium.eservices.pageobjects.common.BasePageEServices;

/**
 * Models the General Request Details page in eServices
 * 
 * @author Jonathan Eastman
 * 			 - Danielle Orth 23/11/2017
 *
 */

public class GeneralRequestBasePage extends BasePageEServices {
	private static final Logger LOGGER = Logger.getLogger(GeneralRequestBasePage.class);

	@FindBy(id = "idWizardForm:idFldIpRightNumber")
	private WebElement ipRightNumberTextField;
	
	@FindBy(id = "idWizardForm:idSrHeirarchyDropdownList:0:level")
	private WebElement ipRightType;

	@FindBy(id = "idWizardForm:idSrHeirarchyDropdownList:1:level")
	private WebElement requestCategory;

	@FindBy(id = "idWizardForm:idSrHeirarchyDropdownList:2:level")
	private WebElement requestType;

	@FindBy(id = "idWizardForm:idBtnACTION_ID_ADD_TO_CART")
	private WebElement addToCart;

	public GeneralRequestBasePage(WebDriver driver) {
		super(driver);
	}

	/**
	 * Insert Patent details
	 * 
	 * @return Reference to object following successful load
	 */
	public GeneralRequestBasePage setPatentsIpRightNumber() {
		String patentNumber = new PAMSDBManager().getPatentForRenewal().getFirstDataItem().toString();
		LOGGER.info("\n     Patent IP Right Number Utilised: " + patentNumber);
		ipRightNumberTextField.sendKeys(patentNumber);
		return this;
	}

	/**
	 * @return Adds current transaction to the cart and navigates to the MyCart
	 *         Page
	 */
	public void clickAddToCartButton() {
		addToCart.click();
		waitWhileEServicesBusy();
	}

	/**
	 * Set value to IP Right Type Drop Down List field.
	 * 
	 * @param ipRightTypeValue
	 *            ...
	 * @return the GeneralRequest class instance.
	 */
	public GeneralRequestBasePage setIpRightDropDownListField(String ipRightTypeValue) {
		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(ipRightType));
		new Select(ipRightType).selectByVisibleText(ipRightTypeValue);
		waitWhileEServicesBusy();
		return this;
	}

	/**
	 * Set value to Request Category Drop Down List field.
	 * 
	 * @param requestCategoryValue
	 *            ...
	 * @return the GeneralRequest class instance.
	 */
	public GeneralRequestBasePage setRequestCategoryDropDownListField(String requestCategoryValue) {
		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(requestCategory));
		new Select(requestCategory).selectByVisibleText(requestCategoryValue);
		waitWhileEServicesBusy();
		return this;
	}

	/**
	 * Set value to Request Type Drop Down List field.
	 * 
	 * @param requestTypeValue
	 *            ...
	 * @return the GeneralRequest class instance.
	 */
	public GeneralRequestBasePage setRequestTypeDropDownListField(String requestTypeValue) {
		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(requestType));
		new Select(requestType).selectByVisibleText(requestTypeValue);
		waitWhileEServicesBusy();
		return this;
	}
}
