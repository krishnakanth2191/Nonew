/**
 * 
 */
package au.gov.ipaustralia.selenium.eservices.pageobjects.patents;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import au.gov.ipaustralia.selenium.eservices.pageobjects.common.BasePageEServices;

/**
 * @author Anthony Hallett
 *
 */
public abstract class PatentBasePage extends BasePageEServices {

    @FindBy(css = "div.data-row.file-upload > span.icm-formbuttonbg > input")
    private WebElement attach;

    public PatentBasePage(WebDriver driver) {
        super(driver);
    }

}
