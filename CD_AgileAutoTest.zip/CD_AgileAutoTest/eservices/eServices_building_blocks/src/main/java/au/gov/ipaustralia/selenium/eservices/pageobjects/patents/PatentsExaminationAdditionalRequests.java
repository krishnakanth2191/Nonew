package au.gov.ipaustralia.selenium.eservices.pageobjects.patents;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import au.gov.ipaustralia.selenium.helpers.wait.WaitTool;

/**
 * Models the Patent Examination Additional Request page in eServices
 * 
 * @author Jonathan Eastman
 *
 */
public class PatentsExaminationAdditionalRequests extends PatentBasePage {

	private static final String PAGE_TITLE = "ADDITIONAL REQUESTS";
	private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/eservices\\/patent\\/exam-request\\/exam-request-wizard.xhtml";

	
	@FindBy(id = "idWizardForm:idAmendmentBoolean")
	private WebElement requestAmendmentButton;

	static final String BROWSE_FILE_DESRIPTION = "idWizardForm:idPatentExamAmendmentFileUpload";
	@FindBy(id = BROWSE_FILE_DESRIPTION)
	private WebElement browseAmendment;

	/**
	 * Constructor with WebDriver
	 * 
	 */
	public PatentsExaminationAdditionalRequests(WebDriver driver) {
		super(driver);
	}
	
	/**
	 * Click the Statement of Request Amendment Button check box
	 * 
	 * @return This object been clicked
	 * 
	 */
	public PatentsExaminationAdditionalRequests clickRequestAmendmentButton() {
		requestAmendmentButton.click();
		waitWhileEServicesBusy();
		return this;
	}

	/**
	 * @param fileName
	 * 
	 * @ passing browser elements as common ...and doing file attachment
	 * @return File Attachment
	 * 
	 */
	public PatentsExaminationAdditionalRequests attachAmendment(String fileName) {
		WaitTool.waitForElement(driver, By.id(BROWSE_FILE_DESRIPTION), timeout);
		addFile(fileName, browseAmendment);
		return this;

	}

    /**
     * Verify that current page URL matches the expected URL.
     *
     * @return boolean.
     */
	public boolean verifyPageUrl() {
		return verifyPageUrl(PAGE_URL);
	}

    /**
     * Verify that the page loaded completely.
     *
     * @return boolean.
     */
	public boolean verifyPageTitle() {
		return verifyPageTitle(PAGE_TITLE);
	}

	public boolean verifyPageLoaded() {
		return verifyPageTitle();
	}

}
