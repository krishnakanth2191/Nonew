package au.gov.ipaustralia.selenium.eservices.pageobjects.trademarks;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TradeMarksNewAppGoodsAndServices extends TradeMarksBasePage {

    private static final Logger LOGGER = Logger.getLogger(TradeMarksNewAppGoodsAndServices.class);
    private static final String PAGE_TITLE = "GOODS AND SERVICES";
    private static final String PAGE_URL =
            "\\/ICMWebUI\\/views\\/private\\/eservices\\/trademark\\/.*\\/.*wizard.xhtml";

    @FindBy(name = "idWizardForm:idGoodsAndServicesSelectionCategory")
    private List<WebElement> selectionCategory;

    @FindBy(id = "idWizardForm:searchFilter")
    private WebElement searchTerm;

    @FindBy(id = "idWizardForm:searchButton")
    private WebElement searchButton;

    static final String ADD_SELECTED_ID = "idWizardForm:addSelectedItemsButton";
    @FindBy(id = ADD_SELECTED_ID)
    private WebElement addSelectedButton;

    static final String CLASS_NUMBER_ID =
            "idWizardForm:idGoodsAndServicesStepGoodsAndServicesUserEnteredSelectClassNumber";
    @FindBy(id = CLASS_NUMBER_ID)
    private WebElement addYourOwnClassNumber;

    @FindBy(id = "idWizardForm:idGoodsAndServicesStepGoodsAndServicesUserEnteredDescriptionField")
    private WebElement addYourOwnList;

    @FindBy(id = "idWizardForm:idGoodsAndServicesStepSaveGoodsAndServicesBtn")
    private WebElement saveYourOwnListButton;

    @FindBy(id = "idWizardForm:idGandsCopyParentIdentifier")
    private WebElement copyTradeMarkNumber;

    @FindBy(id = "idWizardForm:idRetrieveCopyGandSButton")
    private WebElement copyRetrieveDetailsButton;

    @FindBy(id = "idWizardForm:idGoodsAndServicesStepGoodsAndServicesUserEnteredAddBtn")
    private WebElement copyAddAnotherButton;

    public TradeMarksNewAppGoodsAndServices(WebDriver driver) {
        super(driver);
    }

    /**
     * @return TradeMarksNewApp_GoodsAndServices instance
     */
    public TradeMarksNewAppGoodsAndServices setSelectioinCategoryRadioButton() {
        String cat = getDataValue(TradeMarkParameters.SELECT_LIST_CATEGORY.getValue()).trim();
        if (!cat.equals("")) {
            return setSelectioinCategoryRadioButton(cat);
        }
        else {
            return this;
        }
    }

    /**
     * Set value to selection category Radio Button group.
     * 
     * @param selectionCategoryValue
     *            ...
     * @return the TradeMarksNewApp_GoodsAndServices class instance.
     */
    public TradeMarksNewAppGoodsAndServices setSelectioinCategoryRadioButton(String selectionCategoryValue) {
        for (WebElement el : selectionCategory) {
            if (el.getAttribute("value").equals(selectionCategoryValue)) {
                if (!el.isSelected()) {
                    el.click();
                }
                break;
            }
        }
        return this;
    }

    /**
     * @return TradeMarksNewApp_GoodsAndServices instance
     */
    public TradeMarksNewAppGoodsAndServices fillNominateSection() {
        setSelectioinCategoryRadioButton();
        if ("SEARCH".equals(getDataValue(TradeMarkParameters.SELECT_LIST_CATEGORY.getValue()))) {
            setSearchTextField();
            clickSearchButton();
            selectSearchResult();
            clickAddSelectedButton();
        }
        else if ("COPY".equals(getDataValue(TradeMarkParameters.SELECT_LIST_CATEGORY.getValue()))) {
            setCopyTradeMarkNumberTextField();
            clickCopyRetrieveDetailsButton();
            assertThat(verifyCopyAddAnotherButtonBisplayed()).isTrue();

            String[] testClass = getDataValue(TradeMarkParameters.ADD_YOUR_OWN_CLASS.getValue()).split("\n");
            String[] list = getDataValue(TradeMarkParameters.ADD_YOUR_OWN_LIST.getValue()).split("\n");

            for (int i = 0; i < testClass.length; i++) {
                if (i == 0) {
                    clickcopyAddAnotherButton();
                }

                selectClassNumberDropDownField(testClass[i]);
                waitWhileEServicesBusy();
                setAddYourOwnListTextField(list[i]);
                clickSaveYourOwnListButton();
                waitWhileEServicesBusy();
            }

        }
        else if (!getDataValue(TradeMarkParameters.ADD_YOUR_OWN_CLASS.getValue()).trim().equals("")) {

            String[] testClass = getDataValue(TradeMarkParameters.ADD_YOUR_OWN_CLASS.getValue()).split("\n");
            String[] list = getDataValue(TradeMarkParameters.ADD_YOUR_OWN_LIST.getValue()).split("\n");

            for (int i = 0; i < testClass.length; i++) {
                if (i > 0) {
                    clickcopyAddAnotherButton();
                }

                selectClassNumberDropDownField(testClass[i]);
                waitWhileEServicesBusy();
                setAddYourOwnListTextField(list[i]);
                clickSaveYourOwnListButton();
                waitWhileEServicesBusy();
            }

            return this;

        }
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * @return TradeMarksNewApp_GoodsAndServices instance
     */
    public TradeMarksNewAppGoodsAndServices setSearchTextField() {
        String term = getDataValue(TradeMarkParameters.SEARCH_TERM.getValue()).trim();
        if (!term.equals("")) {
            return setSearchTextField(term);
        }
        else {
            return this;
        }
    }

    /**
     * Set value to Search Term Text field.
     * 
     * @param searchValue
     *            ...
     * @return the EServices_DesignsNewApp_Priority class instance.
     */
    public TradeMarksNewAppGoodsAndServices setSearchTextField(String searchValue) {
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(searchTerm));
        searchTerm.click();
        searchTerm.sendKeys(searchValue);
        return this;
    }

    public TradeMarksNewAppGoodsAndServices selectSearchResult() {
        String results = getDataValue(TradeMarkParameters.SELECT_RESULTS.getValue()).trim();
        if (!results.equals("")) {
            String[] items = results.split(";");
            for (int i = 0; i < items.length; i++) {
                selectSearchResult(items[i]);
            }
        }
        return this;
    }

    /**
     * @param result
     *            ...
     * @return TradeMarksNewApp_GoodsAndServices instance
     */
    public TradeMarksNewAppGoodsAndServices selectSearchResult(String result) {
        (new WebDriverWait(driver, timeout)).ignoring(
                                                      StaleElementReferenceException.class).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//label[contains(text(), '"
                                                              + result + "')]")));
        try {
            Thread.sleep(1000);
        }
        catch (InterruptedException e) {
            LOGGER.info("Interrupted!", e);

            Thread.currentThread().interrupt();
        }
        WebElement label = driver.findElement(By.xpath("//label[contains(text(), '" + result + "')]"));
        String id = label.getAttribute("for");
        WebElement cb = driver.findElement(By.id(id));
        if (!cb.isSelected()) {
            cb.click();
        }
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * @return TradeMarksNewApp_GoodsAndServices instance
     */
    public TradeMarksNewAppGoodsAndServices clickSearchButton() {
        if ("SEARCH".equals(getDataValue(TradeMarkParameters.SELECT_LIST_CATEGORY.getValue()))) {
            (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(searchButton));
            searchButton.click();
        }
        return this;
    }

    public TradeMarksNewAppGoodsAndServices startSearch() {
        searchButton.click();
        return this;
    }

    /**
     * Click on Add Selected Item(s) Button.
     *
     * @return the TradeMarksNewApp_Details class instance.
     */
    public TradeMarksNewAppGoodsAndServices clickAddSelectedButton() {

        (new WebDriverWait(driver,
                timeout)).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.presenceOfElementLocated(By.id(ADD_SELECTED_ID)));
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(addSelectedButton));
        addSelectedButton.click();
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * @return TradeMarksNewApp_GoodsAndServices instance
     */
    public TradeMarksNewAppGoodsAndServices selectClassNumberDropDownField() {
        String number = getDataValue(TradeMarkParameters.ADD_YOUR_OWN_CLASS.getValue()).trim();
        if (!number.equals("")) {
            return selectClassNumberDropDownField(number);
        }
        else {
            return this;
        }
    }

    /**
     * @param classNumber
     *            ...
     * @return TradeMarksNewApp_GoodsAndServices instance
     */
    public TradeMarksNewAppGoodsAndServices selectClassNumberDropDownField(String classNumber) {
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.presenceOfElementLocated(By.id(CLASS_NUMBER_ID)));
        new Select(addYourOwnClassNumber).selectByVisibleText(classNumber);
        return this;
    }

    /**
     * @return TradeMarksNewApp_GoodsAndServices instance
     */
    public TradeMarksNewAppGoodsAndServices setAddYourOwnListTextField() {
        String list = getDataValue(TradeMarkParameters.ADD_YOUR_OWN_LIST.getValue()).trim();
        if (!list.equals("")) {
            return setAddYourOwnListTextField(list);
        }
        else {
            return this;
        }
    }

    /**
     * @param text
     *            your own G and S text
     * @return TradeMarksNewApp_GoodsAndServices instance
     */
    public TradeMarksNewAppGoodsAndServices setAddYourOwnListTextField(String text) {
        addYourOwnList.sendKeys(text);
        return this;
    }

    /**
     * @return TradeMarksNewApp_GoodsAndServices instance
     */
    public TradeMarksNewAppGoodsAndServices clickSaveYourOwnListButton() {
        saveYourOwnListButton.click();
        return this;
    }

    /**
     * @return TradeMarksNewApp_GoodsAndServices instance
     */
    public TradeMarksNewAppGoodsAndServices setCopyTradeMarkNumberTextField() {
        String tmNumber = getDataValue(TradeMarkParameters.COPY_FROM_TM.getValue()).trim();
        if (!tmNumber.equals("")) {
            return setCopyTradeMarkNumberTextField(tmNumber);
        }
        else {
            return this;
        }
    }

    /**
     * @param tmNumber
     *            trademark number
     * @return TradeMarksNewApp_GoodsAndServices instance
     * 
     */
    public TradeMarksNewAppGoodsAndServices setCopyTradeMarkNumberTextField(String tmNumber) {
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(copyTradeMarkNumber));
        copyTradeMarkNumber.sendKeys(tmNumber);
        return this;
    }

    /**
     * @return TradeMarksNewApp_GoodsAndServices instance
     */
    public TradeMarksNewAppGoodsAndServices clickCopyRetrieveDetailsButton() {
        copyRetrieveDetailsButton.click();
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * @return TradeMarksNewApp_GoodsAndServices instance
     */
    public TradeMarksNewAppGoodsAndServices clickcopyAddAnotherButton() {
        copyAddAnotherButton.click();
        return this;
    }

    /**
     * @return TradeMarksNewApp_GoodsAndServices instance
     */
    public boolean verifyCopyAddAnotherButtonBisplayed() {
        return copyAddAnotherButton.isDisplayed();
    }

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

}
