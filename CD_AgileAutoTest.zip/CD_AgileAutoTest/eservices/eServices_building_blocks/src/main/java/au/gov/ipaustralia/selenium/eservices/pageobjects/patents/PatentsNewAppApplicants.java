package au.gov.ipaustralia.selenium.eservices.pageobjects.patents;

import org.openqa.selenium.WebDriver;

public class PatentsNewAppApplicants extends PatentBasePage {

    private static final String PAGE_TITLE = "APPLICANTS";
    private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/eservices\\/patent\\/.*\\/.*-wizard.xhtml";

    public PatentsNewAppApplicants(WebDriver driver) {
        super(driver);
    }

    /**
     * Verify that the page loaded completely.
     *
     * @return boolean.
     */
    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    /**
     * VerifyPageTitle Matches with given title.
     *
     * @return boolean.
     */
    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }
}
