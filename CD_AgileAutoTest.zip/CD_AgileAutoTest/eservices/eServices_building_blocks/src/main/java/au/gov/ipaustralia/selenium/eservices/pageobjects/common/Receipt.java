package au.gov.ipaustralia.selenium.eservices.pageobjects.common;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.management.RuntimeErrorException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import au.gov.ipaustralia.selenium.browser.ThreadSafeWebDriverStorage;
import au.gov.ipaustralia.selenium.environment.EnvironmentVariables;

/**
 * Models the Official Receipt page in eServices
 * 
 * @author Anthony Hallett
 */
public class Receipt extends BasePageEServices {
    private static final Logger LOGGER = Logger.getLogger(Receipt.class);
    private static final String PAGE_TITLE = "Official Receipt";
    private static final String PAGE_URL =
            "\\/ICMWebUI\\/views\\/private\\/eservices\\/service-request-cart-acknowledgement.xhtml";

    @FindBy(css = "#j_id222 dd:nth-child(1)")

    private WebElement batchIDField;

    public Receipt(WebDriver driver) {
        super(driver);
    }

    /**
     * @return the batch reference
     */
    public String getBatchReference() {
        String divID = "";
        if (EnvironmentVariables.getConfiguredItem("ESERVICES", "version").equals("plain")) {
            divID = "j_id222";
        }
        else {
            divID = "j_id287";
        }
        WebElement div = driver.findElement(By.id(divID));
        Pattern px = Pattern.compile("([A-Z]{4}-\\d{10})");
        Matcher m = px.matcher(div.getText());
        if (m.find()) {
            return m.group(1);
        }
        else {
            return "";
        }
    }

    /**
     * receipt page cannot be assessed by selenium if test env invokes the (external) nab test site .. driver can only
     * switch to handles it knows about .. redirects after payment thru the nab sites break this
     * 
     * Hacky McHackface is to close all driver instances, instantiate a new one and get required receipt details from
     * eServ history ..
     * 
     */
    public void closeDriver() {
        WebDriver d = driver;
        try {
            if (!d.getTitle().contains("Official receipt")) {
                throw new RuntimeErrorException(null, "'Official receipt' page not found.");
            }
        }
        catch (NoSuchWindowException e) {
            LOGGER.info("No Element Found", e);

        }
        finally {
            try {
                ThreadSafeWebDriverStorage.quitWebDriver(driver);
            }
            catch (Exception e) {
                LOGGER.info("Driver Not Found", e);
            }
        }
        return;
    }

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);

    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE, "#SRReceiptHeader");

    }
}
