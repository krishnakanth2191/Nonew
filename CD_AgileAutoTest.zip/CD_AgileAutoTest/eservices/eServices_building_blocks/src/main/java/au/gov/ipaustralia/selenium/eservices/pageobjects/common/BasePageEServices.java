package au.gov.ipaustralia.selenium.eservices.pageobjects.common;

import java.util.Vector;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import au.gov.ipaustralia.automation.selenium.helpers.db.ATMOSSDBManager;
import au.gov.ipaustralia.automation.selenium.helpers.db.DatabaseManagerException;
import au.gov.ipaustralia.selenium.environment.EnvironmentVariables;
import au.gov.ipaustralia.selenium.helpers.wait.WaitTool;
import au.gov.ipaustralia.testng.helpers.BasePage;

/**
 * No logic here This is a purely pragmatic collection of attributes and methods
 * which are convenient to use across multiple eServices pages
 * 
 * @author Anthony Hallett
 *
 */
public class BasePageEServices extends BasePage {

	private static final Logger LOGGER = Logger.getLogger(BasePageEServices.class);
	private String homeUrl;
	private String cssSelectorForTitle = "span.panel-title.wizard-panel-title";

	@FindBy(id = "idWaitScreenCDiv")
	private WebElement processingSpinner;

	static final String SIGN_OUT_ID = "logoutLabel";
	@FindBy(id = SIGN_OUT_ID)
	private WebElement signOutLink;

	@FindBy(id = "signoutWarningYesLink")
	private WebElement warningYesLink;

	static final String SUBMIT_ID = "idSrCartForm:idSrCartSubmitButton";
	@FindBy(id = SUBMIT_ID)
	private WebElement submit;

	@FindBy(id = "idAcknowledgementForm:idButtonClose")
	private WebElement close;

	@FindBy(css = "div.data-row.file-upload > input")
	private WebElement browseFiles;

	@FindBy(css = "div.data-row.file-upload > span.icm-formbuttonbg > input")
	private WebElement attach;

	static final String NEXT_ID = "idWizardForm:idBtnACTION_ID_NEXT";
	@FindBy(id = NEXT_ID)
	private WebElement next;

	/**
	 * @param driver
	 *            the WebDriver
	 */
	public BasePageEServices(WebDriver driver) {
		this.driver = driver;
		setHomeUrl(EnvironmentVariables.getConfiguredItem("ESERVICES", "home_url"));
		try {
			String fileName = driver.getClass().getName();
			LOGGER.info("File name from Driver : " + fileName);
			capture(driver, fileName);
		} finally {
			LOGGER.info("Screenshot Taken");
		}
	}

	/**
	 * Navigate back to the home page from anywhere in the app
	 * 
	 */

	public void openHomePage() {
		driver.get(homeUrl);
	}

	/**
	 * Waits for any loading gifs to disappear
	 * 
	 */
	public void waitWhileEServicesBusy() {
		Vector<WebElement> spinners = new Vector<>();
		WebElement waiting = driver
				.findElement(By.xpath("//*[contains(text(),'Processing your request. Please wait...')]"));
		spinners.add(waiting);
		spinners.add(processingSpinner);
		(new WebDriverWait(driver, timeout * 8)).pollingEvery(05, TimeUnit.SECONDS)
				.until(ExpectedConditions.invisibilityOfAllElements(spinners));
	}

	/**
	 * 
	 */
	public void signOut() {
		waitWhileEServicesBusy();
		signOutLink.click();
		waitWhileEServicesBusy();
		warningYesLink.click();
	}

	/**
	 * @return true if signout link is displayed
	 */
	public boolean isSignOutVisible() {
		boolean found = false;
		try {
			signOutLink.isDisplayed();
			found = true;
		} catch (Exception e) {
			LOGGER.info("Signout not Visible", e);
			found = false;
		}
		return found;
	}

	public BasePageEServices clickCloseButton() {
		close.click();
		return this;
	}

	/**
	 * VerifyTables that the page loaded completely.
	 * 
	 * @param pageLoadedText
	 *            ...
	 * @return boolean
	 */
	public boolean verifyPageLoaded(final String pageLoadedText) {
		(new WebDriverWait(driver, timeout)).until(new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver d) {
				return d.getPageSource().contains(pageLoadedText);
			}
		});
		return true;
	}

	/**
	 * VerifyTables that the page title completely.
	 * 
	 * @param pageTitle
	 *            ...
	 * @return boolean
	 */
	public boolean verifyPageTitle(final String pageTitle) {
		return verifyPageTitle(pageTitle, cssSelectorForTitle);
	}

	public boolean verifyPageTitle(final String pageTitle, final String titleCssSelector) {
		(new WebDriverWait(driver, timeout).ignoring(StaleElementReferenceException.class))
				.until(new ExpectedCondition<Boolean>() {
					@Override
					public Boolean apply(WebDriver d) {
						WebElement titleField = d.findElement(By.cssSelector(titleCssSelector));
						LOGGER.info("Webpage Tilte " + titleField.getText());
						return titleField.getText().contains(pageTitle);
					}
				});

		return driver.findElement(By.cssSelector(titleCssSelector)).getText().contains(pageTitle);
	}

	/**
	 * @return the home page url
	 */

	public String getHomeUrl() {
		return homeUrl;
	}

	/**
	 * Sets the home page url for the target environment
	 * 
	 * @param homeUrl
	 *            ...
	 */

	public void setHomeUrl(String homeUrl) {
		this.homeUrl = homeUrl;
	}

	/**
	 * Set a a4joutstanding variable to true and add an A4J listener to change
	 * the variable after ajax completes.
	 */
	protected void setPendingA4jRequest() {
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript(
				"window.a4joutstanding = true;A4J.AJAX.AddListener({onafterajax: function() {window.a4joutstanding = false}});");
	}

	/**
	 * Wait for A4J request to complete.
	 */
	protected void waitForA4JRequestToComplete() {
		WebDriverWait wait = new WebDriverWait(getDriver(), timeout);
		JavascriptWaitForCondition condition = new JavascriptWaitForCondition("return !window.a4joutstanding;");
		wait.until(condition);
	}

	/**
	 * Click an element that uses an A4J submit and wait for the Ajax request to
	 * complete.
	 * 
	 * @param element
	 *            The WebElement to click
	 */
	protected void clickA4J(WebElement element) {
		this.setPendingA4jRequest();

		element.click();

		this.waitForA4JRequestToComplete();
	}

	/**
	 * Wait for page to load.
	 */
	protected void waitForPageLoad() {
		WebDriverWait wait = new WebDriverWait(getDriver(), timeout);
		JavascriptWaitForCondition condition = new JavascriptWaitForCondition(
				"return document.readyState == 'complete';");
		wait.until(condition);
	}

	/**
	 * Click on Submit Button.
	 *
	 * @return the class instance.
	 */
	public BasePageEServices clickSubmitButton() {
		WaitTool.waitForLoad(driver, timeout);
		WaitTool.waitForElement(driver, By.xpath(SUBMIT_ID), timeout);
		submit.click();
		return this;
	}

	/**
	 * Debug convenience method - adds and removes a border around the target a
	 * few times so that the element is easily identified in AUT
	 */
	public WebElement flash(final WebElement element) {

		for (int i = 0; i < 3; i++) {
			((JavascriptExecutor) this.driver).executeScript("arguments[0].style.border='1px solid darkblue'", element);
			try {
				Thread.sleep(100);
			} catch (final InterruptedException e) {
				LOGGER.info("Element not Found", e);
				// Restore interrupted state...
				Thread.currentThread().interrupt();
			}
			((JavascriptExecutor) this.driver).executeScript("arguments[0].style.border='none'", element);
		}
		return element;
	}

	protected String getTMNumber(String key) throws DatabaseManagerException {
		String tradeMarkNumber = "";
		if (getData().containsKey(key)) {
			tradeMarkNumber = getData().get(key);
			Pattern px = Pattern.compile("\\{(.*)\\}");
			Matcher m = px.matcher(tradeMarkNumber);
			if (m.find()) {
				tradeMarkNumber = (new ATMOSSDBManager()).getPendingTradeMarkID(m.group(1)).getFirstDataItem()
						.toString();
			}
		}

		return tradeMarkNumber;
	}

	/**
	 * @param fileName
	 * 
	 *            once file gets uploaded this needs to be deleted using file
	 *            Delete method
	 * 
	 * @param browser
	 *            this can be used across all eservices for file upload ...
	 */

	public void addFile(String fileName, WebElement browse) {

		String finalPath = EnvironmentVariables.getResourcesTestDataFolder(fileName);

		LOGGER.info("Final desitanation path............" + finalPath);
		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(browse));
		browse.sendKeys(finalPath);
		waitWhileEServicesBusy();
		attach.click();
		waitWhileEServicesBusy();
		WaitTool.sleep(3000);
		EnvironmentVariables.fileDelete(finalPath);
	}

	/**
	 * @param fileName
	 * 
	 * @ passing browser elements as common ...
	 * @return
	 * @return TradeMarksNewApp_Details instance
	 */
	public BasePageEServices addFilesCommon(String fileName) {
		addFile(fileName, browseFiles);
		return this;

	}

	public BasePageEServices clickNextButton() {
		WaitTool.waitForElementPresent(driver, By.id(NEXT_ID), timeout);
		WaitTool.waitUntilClickable(driver, timeout, next);
		flash(next);
		next.click();
		waitWhileEServicesBusy();
		return this;
	}

	/**
	 * @return date in dd/mm/yyyy format
	 */
	public String dateFromLocal(int days) {
		String dateFormat = "yyyy-MM-dd";
		final String newFormat = "dd/MM/yyyy";

		LocalDate date = LocalDate.now().minusDays(days);
		String newdate = date.toString();

		DateTimeFormatter formatterOld = DateTimeFormat.forPattern(dateFormat);
		DateTimeFormatter formatterNew = DateTimeFormat.forPattern(newFormat);

		LocalDate localDate = formatterOld.parseLocalDate(newdate);

		return formatterNew.print(localDate);
	}

}
