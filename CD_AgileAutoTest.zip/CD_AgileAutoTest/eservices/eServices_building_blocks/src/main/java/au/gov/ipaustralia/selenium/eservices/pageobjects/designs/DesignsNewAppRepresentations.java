package au.gov.ipaustralia.selenium.eservices.pageobjects.designs;

import static org.assertj.core.api.Assertions.assertThat;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Models the REPRESENTATIONS page in eServices
 * 
 * @author Anthony Hallett
 *
 */
public class DesignsNewAppRepresentations extends DesignsNewAppDesignDetailsBase {

    private static final String PAGE_TITLE = "REPRESENTATIONS";

    @FindBy(className = "errorMessage")
    private WebElement uploadStatus;

    public DesignsNewAppRepresentations(WebDriver driver) {
        super(driver);

        assertThat(verifyPageUrl()).as("REPRESENTATIONS page URL").isTrue();
        assertThat(verifyPageLoaded()).as("REPRESENTATIONS page loaded").isTrue();
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

}
