package au.gov.ipaustralia.selenium.eservices.pageobjects.plantBreedersRights;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import au.gov.ipaustralia.selenium.eservices.pageobjects.common.BasePageEServices;

public class PlantBreedersRightsAttachments extends BasePageEServices {

    private static final String PAGE_TITLE = "ATTACHMENTS";
    private static final String PAGE_URL =
            "\\/ICMWebUI\\/views\\/private\\/eservices\\/pbr\\/new-application\\/new-app-wizard.xhtml";

    @FindBy(id = "idWizardForm:idSupportingDocumentsApplicationPart1FileUpload")
    private WebElement addPartOneForm;

    @FindBy(id = "idWizardForm:idSupportingDocumentsQualifiedPersonFormFileUpload")
    private WebElement addQualifiedPersonForm;

    @FindBy(id = "idWizardForm:idSupportingDocumentsPhotographFileUpload")
    private WebElement addPhotograph;

    @FindBy(id = "idWizardForm:idSupportingDocumentsApplicationPart1FileUploadFileUploadButton")
    private WebElement attachPartOneForm;

    @FindBy(id = "idWizardForm:idSupportingDocumentsQualifiedPersonFormFileUploadFileUploadButton")
    private WebElement attachQualifiedPersonForm;

    @FindBy(id = "idWizardForm:idSupportingDocumentsPhotographFileUploadFileUploadButton")
    private WebElement attachPhotograph;

    public PlantBreedersRightsAttachments(WebDriver driver) {
        super(driver);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

}
