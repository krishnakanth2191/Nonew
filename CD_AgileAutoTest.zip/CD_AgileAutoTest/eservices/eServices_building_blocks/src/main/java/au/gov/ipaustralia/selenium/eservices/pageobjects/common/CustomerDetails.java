package au.gov.ipaustralia.selenium.eservices.pageobjects.common;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Models the CUSTOMER DETAILS page in eServices
 * 
 * @author Anthony Hallett
 *
 */
public class CustomerDetails extends BasePageEServices {

    private static final String PAGE_LOADED_TEXT = "Customer number";
    private static final String PAGE_URL = "/ICMWebUI/views/private/self-services/customer-details.xhtml";

    @FindBy(xpath = "//*[contains(text(), 'Customer number')]/following-sibling::*/span")
    @CacheLookup
    private WebElement customerID;

    @FindBy(id = "idCustomerDetailsForm:idButtonCancelEditDisable")
    @CacheLookup
    private WebElement cancel;

    /**
     * @param driver
     *            the WebDriver
     */
    public CustomerDetails(WebDriver driver) {
        super(driver);
    }

    /**
     * get the text of the Customer Number field
     * 
     * @return the customer number
     */
    public String getCustomerID() {
        (new WebDriverWait(driver,
                timeout)).until(ExpectedConditions.presenceOfElementLocated(By.id("idCustomerDetailsForm")));
        return customerID.getText();
    }

    /**
     * Click on Cancel Button.
     *
     * @return the EServices_CustomerDetails class instance.
     */
    public CustomerDetails clickCancelButton() {
        cancel.click();
        return this;
    }

    /**
     * VerifyTables that the page loaded completely.
     *
     * @return boolean.
     */

    public boolean verifyPageLoaded() {
        return verifyPageLoaded(PAGE_LOADED_TEXT);
    }

    /**
     * VerifyTables that current page URL matches the expected URL.
     *
     * @return boolean.
     */

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    public boolean verifyPageTitle() {
        // unimplemented .. not valid for this particular page
        return false;
    }

}
