package au.gov.ipaustralia.selenium.eservices.pageobjects.patents;

import org.openqa.selenium.WebDriver;

public class PatentsNewAppRelatedApplications extends PatentBasePage {

    private static final String PAGE_TITLE = "RELATED APPLICATIONS";
    private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/eservices\\/patent\\/.*\\/.*-wizard.xhtml";

    public PatentsNewAppRelatedApplications(WebDriver driver) {
        super(driver);
    }

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

}
