package au.gov.ipaustralia.selenium.eservices.pageobjects.generalrequest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Models the General Request Details page for Patents transactions
 * 
 * @author Jonathan Eastman - Danielle Orth - 23/11/2017
 *
 */

public class GeneralRequestPatents extends GeneralRequestBasePage {

	private static final String PAGE_TITLE = "GENERAL eSERVICE REQUEST";
	private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/eservices\\/.*\\/.*-wizard.xhtml";

	@FindBy(id = "idWizardForm:idSelectPhysicalMediaForGeneralSr:0")
	private WebElement physicalMediaYes;

	@FindBy(id = "idWizardForm:idSelectPhysicalMediaForGeneralSr:1")
	private WebElement physicalMediaNo;

	/**
	 * Page Constructor with WebDriver
	 */
	public GeneralRequestPatents(WebDriver driver) {
		super(driver);
	}

	/**
	 * Verify that current page URL matches the expected URL.
	 *
	 * @return true for URL loaded correctly
	 */
	public boolean verifyPageUrl() {
		return verifyPageUrl(PAGE_URL);
	}

	/**
	 * Verify that the page loaded completely.
	 *
	 * @return true for page loaded correctly
	 */
	public boolean verifyPageTitle() {
		return verifyPageTitle(PAGE_TITLE);
	}

	public boolean verifyPageLoaded() {
		return verifyPageTitle();
	}
}
