package au.gov.ipaustralia.selenium.eservices.pageobjects.designs;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

/**
 * Models the DESIGN CATEGORY page in eServices
 * 
 * @author Anthony Hallett
 *
 */
public class DesignsNewAppCategory extends DesignsBasePage {

    private static final String PAGE_TITLE = "DESIGN CATEGORY";
    private static final String PAGE_URL =
            "\\/ICMWebUI\\/views\\/private\\/eservices\\/design\\/new-application\\/new-app-wizard.xhtml";

    @FindBy(id = "idWizardForm:idDesignNewAppSelectAppOpt:0")
    @CacheLookup
    private WebElement oneDesign;

    @FindBy(id = "idWizardForm:idDesignNewAppSelectAppOpt:1")
    @CacheLookup
    private WebElement multiDesign;

    @FindBy(id = "idWizardForm:idDesignNewAppSelectAppOpt:2")
    @CacheLookup
    private WebElement excludedDesign;

    @FindBy(id = "idWizardForm:idDesignNewAppSelectAppOpt:3")
    @CacheLookup
    private WebElement furtherDesign;

    @FindBy(name = "idWizardForm:idDesignNewAppSelectAppOpt")
    @CacheLookup
    private List<WebElement> designCategoryOptionsGroup;

    @FindBy(id = "idWizardForm:idBtnACTION_ID_START")
    @CacheLookup
    private WebElement start;

    public DesignsNewAppCategory(WebDriver driver) {
        super(driver);

        assertThat(verifyPageUrl()).as("DESIGN CATEGORY page URL").isTrue();
        assertThat(verifyPageLoaded()).as("DESIGN CATEGORY page loaded").isTrue();
    }

    /**
     * Click on Start Button.
     *
     * @return the ES_DesignsNewApp_Category class instance.
     */
    public DesignsNewAppCategory clickStartButton() {
        start.click();
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * @return DesignsNewApp_Category instance
     */
    public DesignsNewAppCategory selectDesignCategory() {
        if (getData().containsKey("CATEGORY")) {
            return selectDesignCategory(getData().get("CATEGORY"));
        }
        else {
            return selectDesignCategory("SINGLE_DESIGN");
        }

    }

    /**
     * selects the option button for the nominated category
     * 
     * @param category
     *            the' value' attribute of the required option <br>
     *            SINGLE_DESIGN; MULTIPLE_DESIGNS; EXISTING_EXCLUDED_APPLICATION; FURTHER_DESIGN_APPLICATION
     * @return DesignsNewApp_Category instance
     */
    public DesignsNewAppCategory selectDesignCategory(String category) {
        for (WebElement el : designCategoryOptionsGroup) {
            if (el.getAttribute("value").equals(category)) {
                if (!el.isSelected()) {
                    el.click();
                }
                break;
            }
        }
        return this;
    }

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

}
