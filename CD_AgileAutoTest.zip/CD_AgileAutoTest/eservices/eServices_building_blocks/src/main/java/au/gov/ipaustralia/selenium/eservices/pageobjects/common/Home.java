package au.gov.ipaustralia.selenium.eservices.pageobjects.common;

import static org.assertj.core.api.Assertions.assertThat;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Models the landing page (after login) in eServices
 * 
 * @author Anthony Hallett
 *
 */
public class Home extends BasePageEServices {

    private static final String PAGE_LOADED_TEXT = "My Portfolio";
    private static final String PAGE_URL = "\\/ICMWebUI\\/";

    @FindBy(id = "idIcmHomeTopMenuForm:idCorrespondenceLink")
    @CacheLookup
    private WebElement eservicesCorrespondence;

    @FindBy(id = "idIcmHomeTopMenuForm:idServiceRequestHistoryLink")
    @CacheLookup
    private WebElement eservicesHistory;

    @FindBy(id = "idIcmHomeTopMenuForm:idEditCustomerDetails")
    @CacheLookup
    private WebElement customerDetails;

    @FindBy(id = "idIcmHomeTopMenuForm:idDesignsLink")
    @CacheLookup
    private WebElement designs;
    
    @FindBy(id = "idStructuredGeneralDesignsServiceRequestsLinkText")
    @CacheLookup
    private WebElement designsServiceRequests;

    @FindBy(id = "idIcmHomeTopMenuForm:idOtherRequestsLink")
    @CacheLookup
    private WebElement freedomOfInformation;

    @FindBy(id = "idIcmHomeTopMenuForm:idMakeAPaymentLink")
    @CacheLookup
    private WebElement generalPaymentsIncludesInvitationToPay;

    @FindBy(id = "idIcmHomeTopMenuForm:idCartLink")
    @CacheLookup
    private WebElement myCart;

    @FindBy(id = "idIcmHomeTopMenuForm:idPatentsLink")
    @CacheLookup
    private WebElement patents;

    @FindBy(id = "idIcmHomeTopMenuForm:idPBRLink")
    @CacheLookup
    private WebElement plantBreedersRights;

    @FindBy(id = "idIcmHomeTopMenuForm:idRenewIp")
    @CacheLookup
    private WebElement renewalPayment;

    @FindBy(id = "idIcmHomeTopMenuForm:idLoadDraftLink")
    @CacheLookup
    private WebElement resumeASavedEservice;

    @FindBy(id = "idIcmHomeTopMenuForm:idTmHeadstart2PaymentLink")
    @CacheLookup
    private WebElement tmHeadstartPreapplicationServicePart2;

    @FindBy(id = "idIcmHomeTopMenuForm:idRegisterTm")
    @CacheLookup
    private WebElement tradeMarkRegistrationPayment;

    @FindBy(id = "idIcmHomeTopMenuForm:idTradeMarksLink")
    @CacheLookup
    private WebElement tradeMarksIncludingTmHeadstart;

    @FindBy(id = "idIcmHomeTopMenuForm:idEditUserDetails")
    @CacheLookup
    private WebElement userDetails;

    @FindBy(id = "idIcmHomeTopMenuForm:idMakeAPaymentLinkText")
    private WebElement makeAPaymentLink;

    public Home(WebDriver driver) {
        super(driver);

        assertThat(verifyPageUrl()).as("eServices 'Home' page URL").isTrue();
        assertThat(verifyPageLoaded()).as("eServices 'Home' page loaded").isTrue();
    }

    /**
     * Click on Designs Link.
     *
     * @return the ES_Home class instance.
     */
    public Home clickDesignsLink() {
        designs.click();
        return this;
    }


    /**
     * Click on Designs Service Requests link.
     *
     * @return the DES_AMENDMENTS class instance.
     */
	public Home clickDesignsServiceRequests() {
		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(designsServiceRequests));
		designsServiceRequests.click();
		return this;
	}
    
    /**
     * Click on PBRLink Link.
     *
     * @return the ES_Home class instance.
     */

    public Home clickPBRLink() {
        plantBreedersRights.click();
        return this;
    }

    /**
     * Click on the Make A Payment link
     * 
     * @return the ES_Home class instance
     */
    public Home clickMakeAPayment() {
        makeAPaymentLink.click();
        return this;
    }

    /**
     * Click on Trade Marks Including Tm Headstart Link.
     *
     * @return the ES_Home class instance.
     */
    public Home clickTradeMarksIncludingTmHeadstartLink() {
        tradeMarksIncludingTmHeadstart.click();
        return this;
    }

    /**
     * Click on Customer Details Link.
     *
     * @return the ES_Home class instance.
     */
    public Home clickCustomerDetailsLink() {
        customerDetails.click();
        return this;
    }

    /**
     * Click on eServices History Link.
     *
     * @return the ES_Home class instance.
     */
    public Home clickEservicesHistoryLink() {
        eservicesHistory.click();
        waitWhileEServicesBusy();
        return this;
    }

    /**
     * Click on Patents Link.
     *
     * @return the ES_Home class instance.
     */
    public Home clickPatentsLink() {
        patents.click();
        return this;
    }

    /**
     * Click on Renewal Patents Link.
     *
     * @return the ES_Home class instance.
     */
    public Home clickRenewalPayment() {
        renewalPayment.click();
        return this;
    }

    /**
     * Click on Trade Mark Registration Payment Link.
     *
     * @return the ES_Home class instance.
     */
    public Home clickTradeMarkRegistrationPayment() {
        tradeMarkRegistrationPayment.click();
        return this;
    }

    /**
     * VerifyTables that the page loaded completely.
     *
     * @return boolean.
     */

    public boolean verifyPageLoaded() {
        return verifyPageLoaded(PAGE_LOADED_TEXT);
    }

    /**
     * VerifyTables that current page URL matches the expected URL.
     *
     * @return boolean.
     */

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    public boolean verifyPageTitle() {
        // not implemented ... not valid for this particular page
        return false;
    }

}
