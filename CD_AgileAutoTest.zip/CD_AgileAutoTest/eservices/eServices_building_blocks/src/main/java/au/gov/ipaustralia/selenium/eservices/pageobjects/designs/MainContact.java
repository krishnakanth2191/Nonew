package au.gov.ipaustralia.selenium.eservices.pageobjects.designs;

import static org.assertj.core.api.Assertions.assertThat;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Models the MAIN CONTACT page in eServices
 * 
 * @author Anthony Hallett
 *
 */
public class MainContact extends DesignsBasePage {

    private static final Logger LOGGER = Logger.getLogger(MainContact.class);
    private static final String PAGE_TILTE = "MAIN CONTACT";
    private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/eservices\\/.*\\/.*\\/.*-wizard.xhtml";

    @FindBy(id = "idWizardForm:idNominatedContactInputPhoneNumber")
    private WebElement contactPhone;

    @FindBy(id = "idWizardForm:idNominatedContactInputContactName")
    private WebElement contactName;

    @FindBy(id = "idWizardForm:idNominatedContactInputEmailAddress")
    private WebElement contactEmail;

    @FindBy(id = "idWizardForm:idNominatedContactInputFaxNumber")
    private WebElement contactFaxNumber;

    @FindBy(id = "idWizardForm:idNominatedContactInputMobileNumber")
    private WebElement contactMobileNumber;

    public MainContact(WebDriver driver) {
        super(driver);

        assertThat(verifyPageUrl()).as("MAIN CONTACT page URL").isTrue();
        assertThat(verifyPageLoaded()).as("MAIN CONTACT page loaded").isTrue();
    }

    /**
     * @return MainContact instance
     */
    public MainContact setContactPhoneTextField() {
        if (getData().containsKey("CONTACT_PHONE")) {
            return setContactPhoneTextField(getData().get("CONTACT_PHONE"));
        }
        else {
            return this;
        }

    }

    /**
     * @param phoneNo
     *            ...
     * @return MainContact instance
     */
    public MainContact setContactPhoneTextField(String phoneNo) {
        contactPhone.sendKeys(phoneNo);
        return this;
    }

    /**
     * @return MainContact instance
     */
    public MainContact setContactNameTextField() {
        if (getData().containsKey("CONTACT_NAME")) {
            return setContactNameTextField(getData().get("CONTACT_NAME"));
        }
        else {
            return this;
        }

    }

    /**
     * @param name
     *            ...
     * @return MainContact instance
     */
    public MainContact setContactNameTextField(String name) {
        contactName.sendKeys(name);
        return this;
    }

    /**
     * @return MainContact instance
     */
    public MainContact setContactEmailTextField() {
        if (getData().containsKey("CONTACT_EMAIL")) {
            return setContactEmailTextField(getData().get("CONTACT_EMAIL"));
        }
        else {
            return this;
        }

    }

    /**
     * @param email
     *            ...
     * @return MainContact instance
     */
    public MainContact setContactEmailTextField(String email) {
        contactEmail.sendKeys(email);
        return this;
    }

    /**
     * @return MainContact instance
     */
    public MainContact setContactFaxNumberTextField() {
        if (getData().containsKey("CONTACT_FAX_NUM")) {
            return setContactFaxNumberTextField(getData().get("CONTACT_FAX_NUM"));
        }
        else {
            return this;
        }

    }

    /**
     * @param faxNum
     *            ...
     * @return MainContact instance
     */
    public MainContact setContactFaxNumberTextField(String faxNum) {
        contactFaxNumber.sendKeys(faxNum);
        return this;
    }

    /**
     * @return MainContact instance
     */
    public MainContact setContactMobileNumberTextField() {
        if (getData().containsKey("CONTACT_Mobile_NUM")) {
            return setContactMobileNumberTextField(getData().get("CONTACT_Mobile_NUM"));
        }
        else {
            return this;
        }
    }

    /**
     * @param mobileNum
     *            ...
     * @return MainContact instance
     */
    public MainContact setContactMobileNumberTextField(String mobileNum) {
        contactMobileNumber.sendKeys(mobileNum);
        return this;
    }

    /**
     * @return MainContact instance
     */
    public MainContact selectMainApplicant() {
        if (getData().containsKey("TM_Main_Contact")) {
            String name = getData().get("TM_Main_Contact");
            selectMainApplicant(name);
            setContactNameTextField();
            setContactPhoneTextField();
            setContactFaxNumberTextField();
            setContactMobileNumberTextField();
            setContactEmailTextField();

        }
        return this;
    }

    /**
     * @param applicantName
     *            ...
     * @return MainContact instance
     */
    public MainContact selectMainApplicant(String applicantName) {
        (new WebDriverWait(driver, timeout)).ignoring(
                                                      StaleElementReferenceException.class).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//label[contains(text(), '"
                                                              + applicantName + "')]")));
        try {
            Thread.sleep(1000);
        }
        catch (InterruptedException e) {
            LOGGER.info("Element not loaded", e);
            Thread.currentThread().interrupt();
        }
        WebElement label = driver.findElement(By.xpath("//label[contains(text(), '" + applicantName + "')]"));
        String id = label.getAttribute("for");
        WebElement cb = driver.findElement(By.id(id));
        if (!cb.isSelected()) {
            cb.click();
        }
        waitWhileEServicesBusy();
        return this;
    }

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TILTE);
    }

}
