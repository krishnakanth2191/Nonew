package au.gov.ipaustralia.selenium.eservices.pageobjects.designs;

import static org.assertj.core.api.Assertions.assertThat;

import org.openqa.selenium.WebDriver;

/**
 * Models the PRODUCTS page in eServices
 * 
 * @author Anthony Hallett
 *
 */
public class DesignsNewAppProducts extends DesignsNewAppDesignDetailsBase {

    private static final String PAGE_TITLE = "PRODUCTS";

    public DesignsNewAppProducts(WebDriver driver) {
        super(driver);

        assertThat(verifyPageUrl()).as("PRODUCTS page URL").isTrue();
        assertThat(verifyPageLoaded()).as("PRODUCTS page loaded").isTrue();
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }
}
