package au.gov.ipaustralia.selenium.eservices.pageobjects.generalrequest;

import org.openqa.selenium.WebDriver;

/**
 * Models the General Request Details page for Designs transactions
 * @author Jonathan Eastman
 *
 */

public class GeneralRequestDesigns extends GeneralRequestBasePage {

    public GeneralRequestDesigns(WebDriver driver) {
        super(driver);
    }

  
}
