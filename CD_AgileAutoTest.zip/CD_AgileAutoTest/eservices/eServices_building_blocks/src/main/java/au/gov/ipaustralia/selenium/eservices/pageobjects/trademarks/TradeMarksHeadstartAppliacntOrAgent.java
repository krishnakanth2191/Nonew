package au.gov.ipaustralia.selenium.eservices.pageobjects.trademarks;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TradeMarksHeadstartAppliacntOrAgent extends TradeMarksBasePage {

    private static final String PAGE_TITLE = "APPLICANT OR AGENT";
    private static final String PAGE_URL =
            "\\/ICMWebUI\\/views\\/private\\/eservices\\/trademark\\/headstart-one\\/headstart-one-wizard.xhtml";

    @FindBy(name = "idWizardForm:tmHeadstartOneSubmissionCategorySelect")
    private List<WebElement> applicantOrAgentOptionGroup;

    @FindBy(id = "idWizardForm:tmHeadstartOneInputCustomerRefNumber")
    private WebElement yourReference;

    @FindBy(name = "idWizardForm:idSelectContactOption")
    private List<WebElement> contactGroup;

    @FindBy(id = "idWizardForm:idOptOutText")
    private WebElement contactTime;

    public TradeMarksHeadstartAppliacntOrAgent(WebDriver driver) {
        super(driver);
    }

    /**
     * Set default value to Your Reference Text field.
     *
     * @return the ES_DesignsNewApp_Applicant class instance.
     */
    public TradeMarksHeadstartAppliacntOrAgent setYourReferenceTextField() {
        if (getData().containsKey(TradeMarkParameters.CUSTOMER_REFERENCE.getValue())) {
            return setYourReferenceTextField(getData().get(TradeMarkParameters.CUSTOMER_REFERENCE.getValue()));
        }
        else {
            return this;
        }

    }

    /**
     * @return TradeMarksHeadstart_AppliacntOrAgent instance
     */
    public TradeMarksHeadstartAppliacntOrAgent selectApplicantOrAgent() {
        if (getData().containsKey(TradeMarkParameters.CUSTOMER_TYPE.getValue())) {
            return selectApplicantOrAgent(getData().get(TradeMarkParameters.CUSTOMER_TYPE.getValue()));
        }
        else {
            return selectApplicantOrAgent(TradeMarkParameters.APPLICANT.getValue());
        }

    }

    /**
     * @return TradeMarksHeadstart_AppliacntOrAgent instance
     */
    public TradeMarksHeadstartAppliacntOrAgent selectContactBy() {
        if (getData().containsKey(TradeMarkParameters.CONTACT_BY)) {
            return selectContactBy(getData().get(TradeMarkParameters.CONTACT_BY));
        }
        else {
            return selectApplicantOrAgent(TradeMarkParameters.APPLICANT.getValue());
        }

    }

    /**
     * @param type
     *            BYEMAIL or BYPHONE
     * @return TradeMarksHeadstart_AppliacntOrAgent instance
     */
    public TradeMarksHeadstartAppliacntOrAgent selectContactBy(String type) {
        for (WebElement el : contactGroup) {
            if (el.getAttribute("value").equals(type)) {
                if (!el.isSelected()) {
                    el.click();
                }
                break;
            }
        }
        return this;
    }

    /**
     * selects the option button for the nominated type
     * 
     * @param type
     *            the' value' attribute of the required option <br>
     *            APPLICANT; AGENT
     * @return TradeMarksHeadstart_AppliacntOrAgent instance
     */
    public TradeMarksHeadstartAppliacntOrAgent selectApplicantOrAgent(String type) {
        for (WebElement el : applicantOrAgentOptionGroup) {
            if (el.getAttribute("value").equals(type)) {
                if (!el.isSelected()) {
                    el.click();
                }
                break;
            }
        }
        return this;
    }

    /**
     * Set value to Your Reference Text field.
     * 
     * @param yourReferenceValue
     *            ...
     * @return the ES_DesignsNewApp_Applicant class instance.
     */
    public TradeMarksHeadstartAppliacntOrAgent setYourReferenceTextField(String yourReferenceValue) {
        yourReference.sendKeys(yourReferenceValue);
        return this;
    }

    /**
     * @return TradeMarksHeadstart_AppliacntOrAgent instance
     */
    public TradeMarksHeadstartAppliacntOrAgent setContactTimeTextField() {
        if (getData().containsKey(TradeMarkParameters.CONTACT_TIME.getValue())) {
            return setContactTimeTextField(getData().get(TradeMarkParameters.CONTACT_TIME.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * @param time
     *            ...
     * @return TradeMarksHeadstart_AppliacntOrAgent instance
     */
    public TradeMarksHeadstartAppliacntOrAgent setContactTimeTextField(String time) {
        contactTime.sendKeys(time);
        return this;
    }

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

}
