package au.gov.ipaustralia.selenium.eservices.pageobjects.designs;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import au.gov.ipaustralia.automation.selenium.helpers.db.ATMOSSDBManager;

/**
 * Models Designs Pre-Registration for formality check notices in eServices
 * 
 * @author Danielle Orth (bimord) 
 * @since 21/11/2017
 */
public class DesignsResponsePreRegistration extends DesignsBasePage {

	private static final Logger LOGGER = Logger.getLogger(DesignsResponsePreRegistration.class);
	private static final String PAGE_TITLE = "WHAT DO YOU WISH TO DO?";
	private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/eservices\\/general\\/structured-sr-classifier-wizard.xhtml*";

	@FindBy(id = "idWizardForm:idMENU_ITEM_FORMALITIES_RESPONSE")
	@CacheLookup
	private WebElement respondToFormalitiesNotice;

	@FindBy(id = "idWizardForm:idFldIpRightNumber")
	@CacheLookup
	private WebElement ipRightNumber;

	@FindBy(id = "idWizardForm:idAddIpRightAction")
	@CacheLookup
	private WebElement addButton;

	@FindBy(id = "idWizardForm:idMethodTypeForLodgingFormalitiesResponse:1")
	@CacheLookup
	private WebElement uploadResponseDocumentsOption;

	@FindBy(id = "idWizardForm:idBtnACTION_ID_NEXT")
	@CacheLookup
	private WebElement nextButton;

	@FindBy(id = "idWizardForm:idBtnACTION_ID_ADD_TO_CART")
	@CacheLookup
	private WebElement addToCart;

	public DesignsResponsePreRegistration(WebDriver driver) {
		super(driver);
	}

	/**
	 * Click on 'Respond to a Formalities Notice' link.
	 *
	 * @return the DES_AMENDMENTS class instance.
	 */
	public DesignsResponsePreRegistration clickRespondToFormalitiesNotice() {
		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(respondToFormalitiesNotice));
		respondToFormalitiesNotice.click();
		waitWhileEServicesBusy();
		return this;
	}

	/**
	 * @return Designs IP Right Number in IP Right Number Field
	 */
	public DesignsResponsePreRegistration setDesignsFormalitiesNoticeNumber() {
		String designsFormalitiesNoticeNumber = (new ATMOSSDBManager().getDesignsFormalitiesNoticeNumber()
				.getFirstDataItem().toString());
		LOGGER.info("\n     Design IP Right Number Utilised: " + designsFormalitiesNoticeNumber);
		ipRightNumber.sendKeys(designsFormalitiesNoticeNumber);
		return this;
	}

	/**
	 * Click on 'Retrieve Details' button
	 *
	 * @return displays details of the inputed IP Right Number
	 */
	public DesignsResponsePreRegistration clickRetrieveDetailsButton() {
		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(ipRightNumber));
		addButton.click();
		waitWhileEServicesBusy();
		return this;
	}

	/**
	 * Click on the upload response documents radio button.
	 *
	 * @return ability to upload documents
	 */
	public DesignsResponsePreRegistration clickLodgeDocumentResponse() {
		(new WebDriverWait(driver, timeout))
				.until(ExpectedConditions.elementToBeClickable(uploadResponseDocumentsOption));
		uploadResponseDocumentsOption.click();
		waitWhileEServicesBusy();
		return this;
	}

	/**
	 * Click on 'Add to Cart' button
	 * 
	 * @return IP Right added to cart ready for processing
	 */
	public DesignsResponsePreRegistration clickAddToCartButton() {
		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(addToCart));
		addToCart.click();
		waitWhileEServicesBusy();
		return this;
	}

    /**
     * Verify that current page URL matches the expected URL.
     *
     * @return boolean.
     */
	public boolean verifyPageUrl() {
		return verifyPageUrl(PAGE_URL);
	}

    /**
     * Verify that the page loaded completely.
     *
     * @return boolean.
     */
	public boolean verifyPageTitle() {
		return verifyPageTitle(PAGE_TITLE);
	}

	public boolean verifyPageLoaded() {
		return verifyPageTitle();
	}
}
