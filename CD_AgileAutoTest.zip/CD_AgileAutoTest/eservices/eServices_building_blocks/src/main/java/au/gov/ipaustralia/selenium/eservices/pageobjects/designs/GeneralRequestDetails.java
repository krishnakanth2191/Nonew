package au.gov.ipaustralia.selenium.eservices.pageobjects.designs;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import au.gov.ipaustralia.selenium.environment.EnvironmentVariables;
import au.gov.ipaustralia.selenium.helpers.wait.WaitTool;

/**
 * Models the GENERAL eSERVICE REQUEST DETAILS page in eServices
 * 
 * @author Anthony Hallett
 *
 */
public class GeneralRequestDetails extends DesignsBasePage {

	private static final Logger LOGGER = Logger.getLogger(GeneralRequestDetails.class);
	private static final String PAGE_TITLE = "GENERAL eSERVICE REQUEST DETAILS";
	private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/eservices\\/general\\/general-wizard.xhtml";
	private static final String CASE_FOUND = "Case Found";
	private static final String CASE_NOT_FOUND = "Case NOT Found";

	@FindBy(id = "idWizardForm:idFldIpRightNumber")
	private WebElement ipRightNumberTextField;

	@FindBy(xpath = "//*[@id='idWizardForm:idAddIpRightAction']")
	private WebElement retrieveDetailsButton;

	@FindBy(xpath = "//*[@id='idWizardForm:idWizWarnDialogBtnCancel']")
	private WebElement alertRetrieveDetailsNo;

	@FindBy(id = "idWizardForm:idGeneralAttachment0-DesignGeneralSupportingDocFileUpload")
	private WebElement browseFile;

	@FindBy(id = "idWizardForm:idNumberOfMonthsSelect")
	private WebElement monthsToPayEOT;

	@FindBy(id = "idWizardForm:idGeneralAttachment0-DesignGeneralSupportingDocFileUpload")
	private WebElement generalFileUpload;

	@FindBy(id = "idWizardForm:idGeneralAttachment0-DesignRepImagesidRepresentationAttachmentsFileBrowseAndAttach")
	private WebElement generalRepFileUpload;

	@FindBy(id = "idWizardForm:idGeneralAttachment0-DesignGeneralSupportingDocFileUploadFileUploadButton")
	private WebElement attach;

	static final String ADD_FILE_ID = "idWizardForm:idGeneralAttachment0-DesignRepImagesidRepresentationAttachmentsFileBrowseAndAttach";

	@FindBy(id = ADD_FILE_ID)
	private WebElement browseRep;

	@FindBy(id = "idWizardForm:idGeneralAttachment0-nonDesignAttachmentFileUpload")
	private WebElement browseRepOther;

	@FindBy(id = "idWizardForm:idGeneralAttachment0-DesignRepImagesidRepresentationAttachmentsFileBrowseAndAttachFileUploadButton")
	private WebElement attachRep;

	@FindBy(id = "idWizardForm:idGeneralAttachment0-nonDesignAttachmentFileUploadFileUploadButton")
	private WebElement attachRepOther;

	@FindBy(id = "idWizardForm:idGeneralAttachment0-DesignRepImagesidRepresentationAttachmentsFileAddBtn")
	private WebElement addAnotherRep;

	public GeneralRequestDetails(WebDriver driver) {
		super(driver);
	}

	/**
	 * @param monthNumeber
	 *            ..
	 * @return GeneralRequestDetails instance
	 */
	public GeneralRequestDetails setMonthsToPayEOT(String monthNumeber) {
		monthsToPayEOT.sendKeys(monthNumeber);
		waitWhileEServicesBusy();
		return this;
	}

	/**
	 * @param file
	 *            attachement..
	 * @return GeneralRequestDetails instance
	 */
	public GeneralRequestDetails attachGeneralFileUpload(String fileName) {
		generalFileUpload.sendKeys(fileName);
		return this;
	}

	/**
	 * @param file
	 *            attachement..
	 * @return GeneralRequestDetails instance
	 */
	public GeneralRequestDetails attachGeneralRepFileUpload(String fileName) {
		generalRepFileUpload.sendKeys(fileName);
		return this;
	}

	/**
	 * @return this instance (can chain method calls)
	 */
	public String getTaskType() {
		String workCaseId = "";
		Boolean status = driver.findElements(By.xpath("//*[@id='idWizardForm:idChangeIpRightAction']")).size() > 0;
		if (status) {
			workCaseId = CASE_FOUND;
		} else {
			workCaseId = CASE_NOT_FOUND;
		}
		return workCaseId;
	}

	/**
	 * @param ipRightNumeber
	 *            ...
	 * @return GeneralRequestDetails instance
	 */
	public GeneralRequestDetails setIPRight(String ipRightNumber, int waitSeconds) {
		String workCaseID = "";
		int waited = 0;
		ipRightNumberTextField.sendKeys(ipRightNumber);
		retrieveDetailsButton.click();
		waitWhileEServicesBusy();
		int noOfTries = waitSeconds / 5;
		for (int i = 0; i < noOfTries; i++) {
			workCaseID = getTaskType();
			LOGGER.info(workCaseID);
			if (workCaseID.equals(CASE_NOT_FOUND)) {
				WaitTool.sleep(5000);
				waited += 5;
				retrieveDetailsButton.click();
				waitWhileEServicesBusy();
			} else {
				waited = waited / 60;
				LOGGER.info("Waited at EServices for " + waited + " Minutes");
				break;
			}
		}
		return this;
	}

	/**
	 * @param ipRightNumeber
	 *            ...
	 * @return GeneralRequestDetails instance
	 */
	public GeneralRequestDetails setIPRightEOT(String ipRightNumber, int waitSeconds) {
		String workCaseID = "";
		ipRightNumberTextField.sendKeys(ipRightNumber);
		retrieveDetailsButton.click();
		waitWhileEServicesBusy();
		int noOfTries = waitSeconds / 5;
		for (int i = 0; i < noOfTries; i++) {
			workCaseID = getTaskType();
			LOGGER.info(workCaseID);
			if (workCaseID.equals(CASE_NOT_FOUND)) {
				Boolean alert = driver.findElements(By.xpath("//*[@id='idWizardForm:idWizWarnDialogBtnCancel']"))
						.size() > 0;
				if (alert) {
					(new WebDriverWait(driver, timeout))
							.until(ExpectedConditions.elementToBeClickable(alertRetrieveDetailsNo));
					alertRetrieveDetailsNo.click();

				}

				WaitTool.sleep(5000);
				retrieveDetailsButton.click();
				waitWhileEServicesBusy();
			} else {
				noOfTries = noOfTries / 60;
				LOGGER.info("Waited at ESerives for " + noOfTries + " Minutes");
				break;
			}
		}
		return this;
	}

	/**
	 * @return GeneralRequestDetails instance
	 */
	public GeneralRequestDetails addFile() {
		if (getData().containsKey(DesignsParameters.FILE_NAME)) {
			addFile(getData().get(DesignsParameters.FILE_NAME));
		}
		return this;

	}

	/**
	 * @param file
	 *            ...
	 * @return GeneralRequestDetails instance
	 */
	public GeneralRequestDetails addFile(String file) {

		String finalPath = EnvironmentVariables.getResourcesTestDataFolder(file);

		LOGGER.info("Final desitanation path............" + finalPath);
		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(browseFile));
		browseFile.sendKeys(finalPath);
		waitWhileEServicesBusy();
		attach.click();
		waitWhileEServicesBusy();
		WaitTool.sleep(3000);
		EnvironmentVariables.fileDelete(finalPath);
		return this;
	}

	/**
	 * @param files
	 *            a ';' delineated list of file names
	 * @return DesignsNewAppDesignDetailsBase instance
	 */
	public GeneralRequestDetails addRepsGeneral(String files) {
		String[] fileNames;

		fileNames = files.split(";");
		for (int i = 0; i < fileNames.length; i++) {

			if (!(i == 0)) {
				(new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(addAnotherRep));
				addAnotherRep.click();
				waitWhileEServicesBusy();		
				WaitTool.sleep(1000);
				(new WebDriverWait(driver, timeout)).ignoring(StaleElementReferenceException.class)
						.until(ExpectedConditions.presenceOfElementLocated(By.id(ADD_FILE_ID)));
				(new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(browseRep));

			}

			addFilesCommon(fileNames[i]);

		}
		return null;
	}

	public boolean verifyPageUrl() {
		return verifyPageUrl(PAGE_URL);
	}

	public boolean verifyPageLoaded() {
		return verifyPageTitle();
	}

	public boolean verifyPageTitle() {
		return verifyPageTitle(PAGE_TITLE);
	}
}