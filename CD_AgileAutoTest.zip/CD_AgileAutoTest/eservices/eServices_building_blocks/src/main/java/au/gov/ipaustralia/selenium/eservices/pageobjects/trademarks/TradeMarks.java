/**
 * 
 */
package au.gov.ipaustralia.selenium.eservices.pageobjects.trademarks;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

/**
 * @author Anthony Hallett
 *
 */
public class TradeMarks extends TradeMarksBasePage {

    private static final String PAGE_TITLE = "TRADE MARK eSERVICES";
    private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/home\\/forms.xhtml\\?tab=TRADEMARK";

    @FindBy(id = "idApplyForNewTm")
    @CacheLookup
    private WebElement applyForAnAustralianTradeMark;

    @FindBy(id = "idTmIrpi1")
    @CacheLookup
    private WebElement applicationForInternationalRegistrationMadridProtocol;

    @FindBy(id = "idTmHeadstart1")
    @CacheLookup
    private WebElement headStartApplicationPart1;

    @FindBy(id = "idGeneralTradeMark")
    private WebElement generalRequest;

    public TradeMarks(WebDriver driver) {
        super(driver);
    }

    /**
     * Click on Application For International Registration Madrid Protocol Link.
     *
     * @return the TradeMarks class instance.
     */
    public TradeMarks clickApplicationForInternationalRegistrationMadridProtocolLink() {
        applicationForInternationalRegistrationMadridProtocol.click();
        return this;
    }

    /**
     * Click on Apply For An Australian Trade Mark Link.
     *
     * @return the TradeMarks class instance.
     */
    public TradeMarks clickApplyForAnAustralianTradeMarkLink() {
        applyForAnAustralianTradeMark.click();
        return this;
    }

    /**
     * Click on Apply For An Australian Trade Mark Link.
     *
     * @return the TradeMarks class instance.
     */
    public TradeMarks clickHeadStartApplicationPart1Link() {
        headStartApplicationPart1.click();
        return this;
    }

    public TradeMarks clickGeneralRequest() {
        generalRequest.click();
        return this;
    }

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

}
