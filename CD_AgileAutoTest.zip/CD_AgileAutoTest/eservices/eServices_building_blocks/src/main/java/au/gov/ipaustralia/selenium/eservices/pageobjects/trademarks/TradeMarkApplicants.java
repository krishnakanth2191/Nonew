package au.gov.ipaustralia.selenium.eservices.pageobjects.trademarks;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Models the APPLICANTS / APPLICANT DESTAILS page in eServices
 * 
 * @author Anthony Hallett
 *
 */
public class TradeMarkApplicants extends TradeMarksBasePage {

    private static final Logger LOGGER = Logger.getLogger(TradeMarkApplicants.class);
    private static final String PAGE_TITLE = "APPLICANT"; // APPLICANTS or APPLICANT
    // DETAILS
    private static final String PAGE_URL = "\\/ICMWebUI\\/views\\/private\\/eservices\\/.*\\/.*\\/.*-wizard.xhtml";

    @FindBy(id = "idWizardForm:idWizWarnDialogBtnOk")
    private WebElement withoutDesignerYes;

    @FindBy(id = "idWizardForm:idApplicantBtnAdd")
    private WebElement addAnotherApplicant;

    @FindBy(name = "idWizardForm:idApplicantSelectCustomerType")
    private List<WebElement> customerTypeOptionGroup;

    @FindBy(id = "idWizardForm:idApplicantSelectTitle")
    private WebElement title;

    @FindBy(id = "idWizardForm:idApplicantInputCompanyName")
    private WebElement companyName;

    @FindBy(id = "idWizardForm:idApplicantInputCompanyNameWiMessage")
    private WebElement companyNameWithMessage;

    @FindBy(id = "idWizardForm:idApplicantInputGivenName")
    private WebElement givenName;

    @FindBy(id = "idWizardForm:idApplicantInputACN")
    private WebElement acn;

    @FindBy(id = "idWizardForm:idApplicantInputFamilyName")
    private WebElement familyName;

    @FindBy(id = "idWizardForm:idApplicantInputABN")
    private WebElement abn;

    @FindBy(id = "idWizardForm:idApplicantSelectCountry")
    private WebElement country;

    @FindBy(id = "idWizardForm:idApplicantInputAddressLine1")
    private WebElement addressLine1;

    @FindBy(id = "idWizardForm:idApplicantInputAddressLine2")
    private WebElement addressLine2;

    @FindBy(id = "idWizardForm:idApplicantInputAddressLine3")
    private WebElement addressLine3;

    // AU
    @FindBy(id = "idWizardForm:idApplicantInputAUSuburb")
    private WebElement auSuburbtown;

    @FindBy(id = "idWizardForm:idApplicantSelectAUState")
    private WebElement auState;

    @FindBy(id = "idWizardForm:idApplicantInputAUPostCode")
    private WebElement auPostCode;

    // USA
    @FindBy(id = "idWizardForm:idApplicantInputUSLocality")
    private WebElement usaLocality;

    @FindBy(id = "idWizardForm:idApplicantInputUSState")
    private WebElement usaState;

    @FindBy(id = "idWizardForm:idApplicantInputUSZipcode")
    private WebElement usaZipCode;

    // Japan
    @FindBy(id = "idWizardForm:idApplicantInputJPCity")
    private WebElement japanCity;

    @FindBy(id = "idWizardForm:idApplicantInputJPState")
    private WebElement japanPrefecture;

    @FindBy(id = "idWizardForm:idApplicantInputJPPostCode")
    private WebElement japanPostCode;

    // France
    @FindBy(id = "idWizardForm:idApplicantInputFRCity")
    private WebElement franceCEDEX;

    @FindBy(id = "idWizardForm:idApplicantInputFRPostCode")
    private WebElement francePostCode;

    // Other
    @FindBy(id = "idWizardForm:idApplicantInputSuburb")
    private WebElement otherSuburb;

    @FindBy(id = "idWizardForm:idApplicantInputState")
    private WebElement otherState;

    @FindBy(id = "idWizardForm:idApplicantInputPostCode")
    private WebElement otherPostCode;

    @FindBy(id = "idWizardForm:idApplicantBtnSave")
    private WebElement saveApplicant;

    @FindBy(id = "idWizardForm:idBtnSelectEnteredAddress")
    private WebElement keepThisAddressButton;

    /**
     * @param driver
     *            the WebDriver
     */
    public TradeMarkApplicants(WebDriver driver) {
        super(driver);

        assertThat(verifyPageUrl()).as("APPLICANT page URL").isTrue();
        assertThat(verifyPageLoaded()).as("APPLICANT page loaded").isTrue();
    }

    /**
     * @return this instance (can chain method calls)
     */
    public TradeMarkApplicants clickAddNewApplicantButton() {
        addAnotherApplicant.click();
        return this;
    }

    /**
     * Overload to allow data driving
     * 
     * @return this instance (can chain method calls)
     */
    public TradeMarkApplicants selectNewApplicantType() {
        if (getData().containsKey("NEW_APPLICANT_TYPE")) {
            return selectNewApplicantType(getData().get("NEW_APPLICANT_TYPE"));
        }
        else {
            return selectNewApplicantType("INDIVIDUAL");
        }

    }

    /**
     * selects the option button for the nominated type
     * 
     * @param type
     *            the' value' attribute of the required option <br>
     *            INDIVIDUAL; ORGANISATION
     * @return this instance (can chain method calls)
     */
    public TradeMarkApplicants selectNewApplicantType(String type) {
        for (WebElement el : customerTypeOptionGroup) {
            if (el.getAttribute("value").equals(type)) {
                if (!el.isSelected()) {
                    this.clickA4J(el);
                }
                break;
            }
        }
        return this;
    }

    /**
     * Convenience method to fill all fields required to add a new individual applicant
     * 
     * @param title
     *            ...
     * @param givenName
     *            ...
     * @param familyName
     *            ...
     * @param country
     *            ...
     * @param line1
     *            ...
     * @param line2
     *            ...
     * @param line3
     *            ...
     * @param suburb
     *            ...
     * @param stateName
     *            ...
     * @param postCode
     *            ...
     * @return this instance (can chain method calls)
     */
    public TradeMarkApplicants addNewIndividual(String title,
                                                String givenName,
                                                String familyName,
                                                String country,
                                                String line1,
                                                String line2,
                                                String line3,
                                                String suburb,
                                                String stateName,
                                                String postCode) {
        selectNewApplicantType(TradeMarkParameters.NEW_APPLICANT_TYPE_INDIVIDUAL.getValue());
        if (!title.trim().equals("")) {
            setTitleDropDownListField(title);
        }
        setGivenNameTextField(givenName);
        setFamilyNameTextField(familyName);

        addAddress(country, line1, line2, line3, suburb, stateName, postCode);

        return this;
    }

    /**
     * Convenience method to fill all fields required to add a new organisation applicant
     * 
     * @param legalName
     *            ...
     * @param acnText
     *            ...
     * @param abnText
     *            ...
     * @param country
     *            ...
     * @param line1
     *            ...
     * @param line2
     *            ...
     * @param line3
     *            ...
     * @param suburb
     *            ...
     * @param stateName
     *            ...
     * @param postCode
     *            ...
     * @return this instance (can chain method calls)
     */
    public TradeMarkApplicants addNewOrganisation(String legalName,
                                                  String acnText,
                                                  String abnText,
                                                  String country,
                                                  String line1,
                                                  String line2,
                                                  String line3,
                                                  String suburb,
                                                  String stateName,
                                                  String postCode) {
        selectNewApplicantType(TradeMarkParameters.NEW_APPLICANT_TYPE_ORGANISATION.getValue());
        setCompanyNameTextField(legalName);
        setACNTextField(acnText);
        setABNTextField(abnText);

        addAddress(country, line1, line2, line3, suburb, stateName, postCode);

        return this;
    }

    /**
     * Adding a new applicant using the data provider
     * 
     * @return this instance (can chain method calls)
     */
    public TradeMarkApplicants addNewApplicants() {
        if (!getDataValue(TradeMarkParameters.NEW_APPLICANT_TYPE.getValue()).trim().equals("")) {
            String[] types = getDataValue(TradeMarkParameters.NEW_APPLICANT_TYPE.getValue()).split("\n");
            String[] titles = getDataValue(TradeMarkParameters.TITLE_OR_LEGAL_NAME.getValue()).split("\n");
            String[] givens = getDataValue(TradeMarkParameters.GIVEN_NAME_OR_ACN.getValue()).split("\n");
            String[] families = getDataValue(TradeMarkParameters.FAMILY_NAME_OR_ABN.getValue()).split("\n");

            String[] countries = getDataValue(TradeMarkParameters.COUNTRY.getValue()).split("\n");
            String[] line1s = getDataValue(TradeMarkParameters.ADDRESS_LINE_1.getValue()).split("\n");
            String[] line2s = getDataValue(TradeMarkParameters.ADDRESS_LINE_2.getValue()).split("\n");
            String[] line3s = getDataValue(TradeMarkParameters.ADDRESS_LINE_3.getValue()).split("\n");
            String[] suburbs = getDataValue(TradeMarkParameters.SUBURB_TOWN.getValue()).split("\n");
            String[] states = getDataValue(TradeMarkParameters.STATE.getValue()).split("\n");
            String[] postcodes = getDataValue(TradeMarkParameters.POSTCODE.getValue()).split("\n");
            for (int i = 0; i < types.length; i++) {
                if (i > 0) {
                    clickAddNewApplicantButton();
                }
                else if (getDataValue(TradeMarkParameters.CUSTOMER_TYPE.getValue()).equals(TradeMarkParameters.CUSTOMER_TYPE_APPLICANT.getValue())) {
                    clickAddNewApplicantButton();
                }

                if (types[i].equals(TradeMarkParameters.NEW_APPLICANT_TYPE_INDIVIDUAL.getValue())) {
                    addNewIndividual(titles[i],
                                     givens[i],
                                     families[i],
                                     countries[i],
                                     line1s[i],
                                     line2s[i],
                                     line3s[i],
                                     suburbs[i],
                                     states[i],
                                     postcodes[i]);
                }
                else if (types[i].equals(TradeMarkParameters.NEW_APPLICANT_TYPE_ORGANISATION.getValue())) {
                    addNewOrganisation(titles[i],
                                       givens[i],
                                       families[i],
                                       countries[i],
                                       line1s[i],
                                       line2s[i],
                                       line3s[i],
                                       suburbs[i],
                                       states[i],
                                       postcodes[i]);
                }

            }

        }

        return this;

    }

    /**
     * Convenience method to fill all address fields
     * 
     * @param country
     *            ...
     * @param line1
     *            ...
     * @param line2
     *            ...
     * @param line3
     *            ...
     * @param suburb
     *            ...
     * @param stateName
     *            ...
     * @param postCode
     *            ...
     * @return this instance (can chain method calls)
     */
    public TradeMarkApplicants addAddress(String country,
                                          String line1,
                                          String line2,
                                          String line3,
                                          String suburb,
                                          String stateName,
                                          String postCode) {

        setCountryDropDownListField(country);
        waitWhileEServicesBusy();
        setAddressLine1TextField(line1);
        setAddressLine2TextField(line2);
        setAddressLine3TextField(line3);

        if ("United States of America".equals(country)) {
            setUsaLocalityTextField(suburb);
            setUsaState(stateName);
            setUsaZipCode(postCode);
        }
        else if ("Japan".equals(country)) {
            setJapanCity(suburb);
            setJapanPrefecture(stateName);
            setJapanPostCode(postCode);
        }
        else if ("Australia".equals(country)) {
            setAUSuburbtownTextField(suburb);
            setAUStateDropDownListField(stateName);
            setAUPostcodeTextField(postCode);
        }
        else if ("France".equals(country)) {
            setFranceCEDEX(suburb);
            setFrancePostCode(postCode);
        }
        else if ("Germany".equals(country)) {
            // not mapped yet :-)

        }
        else {
            setOtherCity(suburb);
            setOtherState(stateName);
            setOtherPostCode(postCode);
        }
        clickSaveApplicantButton();

        try {
            if (keepThisAddressButton.isDisplayed()) {
                keepThisAddressButton.click();
                waitWhileEServicesBusy();
            }
        }
        catch (NoSuchElementException e) {
            LOGGER.info("Address is good .. move along", e);
        }

        return this;

    }

    /**
     * Set default value to Title Drop Down List field.
     *
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setTitleDropDownListField() {
        if (getData().containsKey(TradeMarkParameters.TITLE_OR_LEGAL_NAME.getValue())) {
            if (getDataValue(TradeMarkParameters.TITLE_OR_LEGAL_NAME.getValue()).trim().equals("")) {
                return this;
            }
            else {
                return selectNewApplicantType(getData().get(TradeMarkParameters.TITLE_OR_LEGAL_NAME.getValue()));
            }
        }
        else {
            return this;
        }

    }

    /**
     * Set value to Title Drop Down List field.
     * 
     * @param titleValue
     *            ...
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setTitleDropDownListField(String titleValue) {
        new Select(title).selectByVisibleText(titleValue);
        return this;
    }

    /**
     * Set default value to Company Name Text field.
     *
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setCompanyNameTextField() {
        if (getData().containsKey(TradeMarkParameters.TITLE_OR_LEGAL_NAME.getValue())) {
            return setCompanyNameTextField(getData().get(TradeMarkParameters.TITLE_OR_LEGAL_NAME.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * Set value to Company Name Text field.
     * 
     * @param companyNameText
     *            ...
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setCompanyNameTextField(String companyNameText) {
        try {
            companyName.sendKeys(companyNameText);
        }
        catch (Exception e) {
            LOGGER.info("Company Name Text not Found", e);
            companyNameWithMessage.sendKeys(companyNameText);
        }
        return this;
    }

    /**
     * Set default value to Given Name Text field.
     *
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setGivenNameTextField() {
        if (getData().containsKey(TradeMarkParameters.GIVEN_NAME_OR_ACN.getValue())) {
            return setGivenNameTextField(getData().get(TradeMarkParameters.GIVEN_NAME_OR_ACN.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * Set value to Given Name Text field.
     * 
     * @param givenNameValue
     *            ...
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setGivenNameTextField(String givenNameValue) {
        new WebDriverWait(driver, timeout).until(ExpectedConditions.visibilityOf(givenName));
        givenName.sendKeys(givenNameValue);
        return this;
    }

    public TradeMarkApplicants setACNTextField() {
        if (getData().containsKey(TradeMarkParameters.GIVEN_NAME_OR_ACN.getValue())) {
            return setACNTextField(getData().get(TradeMarkParameters.GIVEN_NAME_OR_ACN.getValue()));
        }
        else {
            return this;
        }

    }

    /**
     * @param acnText
     *            ...
     * @return this instance (can chain method calls)
     */
    public TradeMarkApplicants setACNTextField(String acnText) {
        acn.sendKeys(acnText);
        return this;
    }

    /**
     * Set default value to Family Name Text field.
     *
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setFamilyNameTextField() {
        if (getData().containsKey(TradeMarkParameters.FAMILY_NAME_OR_ABN.getValue())) {
            return setFamilyNameTextField(getData().get(TradeMarkParameters.FAMILY_NAME_OR_ABN.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * Set value to Family Name Text field.
     * 
     * @param familyNameValue
     *            ...
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setFamilyNameTextField(String familyNameValue) {
        familyName.sendKeys(familyNameValue);
        return this;
    }

    public TradeMarkApplicants setABNTextField() {
        if (getData().containsKey(TradeMarkParameters.FAMILY_NAME_OR_ABN.getValue())) {
            return setABNTextField(getData().get(TradeMarkParameters.FAMILY_NAME_OR_ABN.getValue()));
        }
        else {
            return this;
        }

    }

    /**
     * @param abnText
     *            ...
     * @return this instance (can chain method calls)
     */
    public TradeMarkApplicants setABNTextField(String abnText) {
        abn.sendKeys(abnText);
        return this;
    }

    /**
     * Set default value to Country Drop Down List field.
     *
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setCountryDropDownListField() {
        if (getData().containsKey(TradeMarkParameters.COUNTRY.getValue())) {
            return setCountryDropDownListField(getData().get(TradeMarkParameters.COUNTRY.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * Set value to Country Drop Down List field.
     * 
     * @param countryValue
     *            ...
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setCountryDropDownListField(String countryValue) {
        Select countryElem = new Select(country);
        WebElement selectedOption = countryElem.getFirstSelectedOption();

        // If the correct country is already selected then we don't want to do
        // anything, because an A4J request won't be
        // triggered.
        if (selectedOption != null && !StringUtils.equals(selectedOption.getText(), countryValue)) {
            this.setPendingA4jRequest();

            countryElem.selectByVisibleText(countryValue);

            this.waitForA4JRequestToComplete();
        }
        return this;
    }

    /**
     * Set default value to Address Line 1 Text field.
     *
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setAddressLine1TextField() {
        if (getData().containsKey(TradeMarkParameters.ADDRESS_LINE_1.getValue())) {
            return setAddressLine1TextField(getData().get(TradeMarkParameters.ADDRESS_LINE_1.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * Set value to Address Line 1 Text field.
     * 
     * @param addressLine1Value
     *            ...
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setAddressLine1TextField(String addressLine1Value) {
        addressLine1.sendKeys(addressLine1Value);
        return this;
    }

    /**
     * Set default value to Address Line 2 Text field.
     *
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setAddressLine2TextField() {
        if (getData().containsKey(TradeMarkParameters.ADDRESS_LINE_2.getValue())) {
            return setAddressLine2TextField(getData().get(TradeMarkParameters.ADDRESS_LINE_2.getValue()));
        }
        else {
            return this;
        }

    }

    /**
     * Set value to Address Line 2 Text field.
     * 
     * @param addressLine2Value
     *            ...
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setAddressLine2TextField(String addressLine2Value) {
        addressLine2.sendKeys(addressLine2Value);
        return this;
    }

    /**
     * Set default value to Address Line 3 Text field.
     *
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setAddressLine3TextField() {
        if (getData().containsKey(TradeMarkParameters.ADDRESS_LINE_3.getValue())) {
            return setAddressLine3TextField(getData().get(TradeMarkParameters.ADDRESS_LINE_3.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * Set value to Address Line 3 Text field.
     * 
     * @param addressLine3Value
     *            ...
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setAddressLine3TextField(String addressLine3Value) {
        addressLine3.sendKeys(addressLine3Value);
        return this;
    }

    /**
     * Set default value to Suburbtown Text field.
     *
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setAUSuburbtownTextField() {
        if (getData().containsKey(TradeMarkParameters.SUBURB_TOWN.getValue())) {
            return setAUSuburbtownTextField(getData().get(TradeMarkParameters.SUBURB_TOWN.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * Set value to Suburbtown Text field.
     * 
     * @param suburbtownValue
     *            ...
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setAUSuburbtownTextField(String suburbtownValue) {
        auSuburbtown.sendKeys(suburbtownValue);
        return this;
    }

    /**
     * @param city
     *            ...
     * @return this instance (can chain method calls)
     */
    public TradeMarkApplicants setOtherCity(String city) {
        otherSuburb.sendKeys(city);
        return this;
    }

    /**
     * Set default value to Other Suburbtown Text field.
     *
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setOtherCity() {
        if (!getDataValue(TradeMarkParameters.SUBURB_TOWN.getValue()).trim().equals("")) {
            return setOtherCity(getData().get(TradeMarkParameters.SUBURB_TOWN.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * Set default value to Other State Text field.
     *
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setOtherState() {
        if (!getDataValue(TradeMarkParameters.STATE.getValue()).trim().equals("")) {
            return setJapanPrefecture(getData().get(TradeMarkParameters.STATE.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * @param state
     *            ...
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setOtherState(String state) {
        otherState.sendKeys(state);
        return this;
    }

    /**
     * Set default value to Other postcode Text field.
     * 
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setOtherPostCode() {
        if (!getDataValue(TradeMarkParameters.POSTCODE.getValue()).trim().equals("")) {
            return setJapanPostCode(getData().get(TradeMarkParameters.POSTCODE.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * @param code
     *            ...
     * @return Applicants class instance
     */
    public TradeMarkApplicants setOtherPostCode(String code) {
        otherPostCode.sendKeys(code);
        return this;
    }

    /**
     * @param city
     *            ...
     * @return Applicants class instance
     */
    public TradeMarkApplicants setFranceCEDEX(String city) {
        franceCEDEX.sendKeys(city);
        return this;
    }

    /**
     * Set default value to Other France CEDEX Text field.
     *
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setFranceCEDEX() {
        if (!getDataValue(TradeMarkParameters.SUBURB_TOWN.getValue()).trim().equals("")) {
            return setFranceCEDEX(getData().get(TradeMarkParameters.SUBURB_TOWN.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * Set default value to France postcode Text field.
     *
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setFrancePostCode() {
        if (!getDataValue(TradeMarkParameters.POSTCODE.getValue()).trim().equals("")) {
            return setFrancePostCode(getData().get(TradeMarkParameters.POSTCODE.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * @param code
     *            ...
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setFrancePostCode(String code) {
        francePostCode.sendKeys(code);
        return this;
    }

    /**
     * @param city
     *            ...
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setJapanCity(String city) {
        japanCity.sendKeys(city);
        return this;
    }

    /**
     * Set default value to Japan city Text field.
     *
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setJapanCity() {
        if (!getDataValue(TradeMarkParameters.SUBURB_TOWN.getValue()).trim().equals("")) {
            return setJapanCity(getData().get(TradeMarkParameters.SUBURB_TOWN.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * Set default value to Japan Prefecture Text field.
     *
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setJapanPrefecture() {
        if (!getDataValue(TradeMarkParameters.STATE.getValue()).trim().equals("")) {
            return setJapanPrefecture(getData().get(TradeMarkParameters.STATE.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * @param state
     *            ...
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setJapanPrefecture(String state) {
        japanPrefecture.sendKeys(state);
        return this;
    }

    public TradeMarkApplicants setJapanPostCode() {
        if (!getDataValue(TradeMarkParameters.POSTCODE.getValue()).trim().equals("")) {
            return setJapanPostCode(getData().get(TradeMarkParameters.POSTCODE.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * Set default value to Japan Postcode Text field.
     * 
     * @param code
     *            ...
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setJapanPostCode(String code) {
        japanPostCode.sendKeys(code);
        return this;
    }

    /**
     * Set default value to USA Locality Text field.
     *
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setUsaLocalityTextField() {
        if (!getDataValue(TradeMarkParameters.SUBURB_TOWN.getValue()).trim().equals("")) {
            return setUsaLocalityTextField(getData().get(TradeMarkParameters.SUBURB_TOWN.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * @param locality
     *            ...
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setUsaLocalityTextField(String locality) {
        usaLocality.sendKeys(locality);
        return this;
    }

    /**
     * Set default value to USA State Text field.
     *
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setUsaState() {
        if (!getDataValue(TradeMarkParameters.STATE.getValue()).trim().equals("")) {
            return setUsaState(getData().get(TradeMarkParameters.STATE.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * @param state
     *            ...
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setUsaState(String state) {
        usaState.sendKeys(state);
        return this;
    }

    /**
     * Set default value to USA Zipcode Text field.
     *
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setUsaZipCode() {
        if (!getDataValue(TradeMarkParameters.POSTCODE.getValue()).trim().equals("")) {
            return setUsaZipCode(getData().get(TradeMarkParameters.POSTCODE.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * @param zip
     *            ...
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setUsaZipCode(String zip) {
        usaZipCode.sendKeys(zip);
        return this;
    }

    /**
     * Set default value to State Drop Down List field.
     *
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setAUStateDropDownListField() {
        if (getData().containsKey(TradeMarkParameters.STATE.getValue())) {
            return setAUStateDropDownListField(TradeMarkParameters.STATE.getValue());
        }
        else {
            return this;
        }
    }

    /**
     * Set value to State Drop Down List field.
     * 
     * @param stateValue
     *            ...
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setAUStateDropDownListField(String stateValue) {
        String resolvedState = "";
        if ("act".equalsIgnoreCase(stateValue)) {
            resolvedState = "Australian Capital Territory";
        }
        else if ("nsw".equalsIgnoreCase(stateValue)) {
            resolvedState = "New South Wales";
        }
        else if ("nt".equalsIgnoreCase(stateValue)) {
            resolvedState = "Northern Territory";
        }
        else if ("qld".equalsIgnoreCase(stateValue)) {
            resolvedState = "Queensland";
        }
        else if ("sa".equalsIgnoreCase(stateValue)) {
            resolvedState = "South Australia";
        }
        else if ("tas".equalsIgnoreCase(stateValue)) {
            resolvedState = "Tasmania";
        }
        else if ("vic".equalsIgnoreCase(stateValue)) {
            resolvedState = "Victoria";
        }
        else if ("wa".equalsIgnoreCase(stateValue)) {
            resolvedState = "Western Australia";
        }
        else {
            resolvedState = stateValue;
        }
        new Select(auState).selectByVisibleText(resolvedState);
        return this;
    }

    /**
     * Set default value to Postcode Text field.
     *
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setAUPostcodeTextField() {
        if (getData().containsKey(TradeMarkParameters.POSTCODE.getValue())) {
            return setAUPostcodeTextField(getData().get(TradeMarkParameters.POSTCODE.getValue()));
        }
        else {
            return this;
        }
    }

    /**
     * Set value to Postcode Text field.
     * 
     * @param postcodeValue
     *            ...
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants setAUPostcodeTextField(String postcodeValue) {
        auPostCode.sendKeys(postcodeValue);
        return this;
    }

    /**
     * Click on Save Applicant Button.
     *
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants clickSaveApplicantButton() {
        this.clickA4J(saveApplicant);
        return this;
    }

    /**
     * @return the Applicants class instance (can chain method calls)
     */
    public TradeMarkApplicants clickYesNoDesigher() {
        withoutDesignerYes.click();
        return this;
    }

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    }

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

}
