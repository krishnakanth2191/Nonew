package au.gov.ipaustralia.selenium.eservices.pageobjects.plantBreedersRights;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import au.gov.ipaustralia.selenium.eservices.pageobjects.common.BasePageEServices;

public class PlantBreedersRightsApplicantOrAgent extends BasePageEServices {

    private static final String PAGE_TITLE = "APPLICANT OR AGENT";
    private static final String PAGE_URL =
            "\\/ICMWebUI\\/views\\/private\\/eservices\\/pbr\\/new-application\\/new-app-wizard.xhtml";

    @FindBy(id = "idWizardForm:pbrNewAppInputCustomerRefNumber")
    private WebElement yourReference;

    @FindBy(id = "idWizardForm:pbrNewAppInputProposedVarietyName")
    private WebElement varietyName;

    public PlantBreedersRightsApplicantOrAgent(WebDriver driver) {
        super(driver);
    }

    public PlantBreedersRightsApplicantOrAgent setYourReferenceTextField(String yourReferenceValue) {
        yourReference.sendKeys(yourReferenceValue);
        return this;
    }

    public PlantBreedersRightsApplicantOrAgent setVarietyNameTextField(String plantVarietyName) {
        varietyName.sendKeys(plantVarietyName);
        return this;
    }

    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    public boolean verifyPageLoaded() {
        return verifyPageTitle();
    };

    public boolean verifyPageTitle() {
        return verifyPageTitle(PAGE_TITLE);
    }

}
