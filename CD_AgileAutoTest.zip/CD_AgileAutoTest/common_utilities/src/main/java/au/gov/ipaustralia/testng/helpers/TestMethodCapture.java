package au.gov.ipaustralia.testng.helpers;

import java.lang.reflect.Method;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ITestResult;

import au.gov.ipaustralia.automation.selenium.fate.FateData;

/**
 * Captures the currently executing test method so it can be accessed by the test, e.g. to retrieve the test method's
 * name. This class is thread-safe.
 *
 * <p>
 * Register this class as a <a href="http://testng.org/doc/documentation-main.html#testng-listeners">TestNG listener</a>
 * , then access the method and result from test code with the static {@link #getTestMethod} and {@link #getTestResult}
 * methods.
 *
 * <p>
 * Annotating a test class with {@code @Listeners(TestMethodCapture.class)} is the suggested way to enable capturing if
 * your test's correctness will depend on this listener being enabled.
 */
public class TestMethodCapture implements IInvokedMethodListener {

    private static final Logger LOGGER = Logger.getLogger(TestMethodCapture.class);

    private static ThreadLocal<Method> currentMethods = new ThreadLocal<>();
    private static ThreadLocal<ITestResult> currentResults = new ThreadLocal<>();

    @Override
    public void beforeInvocation(final IInvokedMethod method,
                                 final ITestResult testResult) {
        final boolean beforeMethodConfiguration = method.getTestMethod().isBeforeMethodConfiguration();
        if (beforeMethodConfiguration) {
            if (testResult.getParameters().length > 0) {
                TestMethodCapture.currentMethods.set((Method) testResult.getParameters()[0]);

            }
        }
        else {
            TestMethodCapture.currentMethods.set(method.getTestMethod().getConstructorOrMethod().getMethod());
        }
        TestMethodCapture.currentResults.set(testResult);
    }

    @Override
    public void afterInvocation(final IInvokedMethod method,
                                final ITestResult testResult) {
        final boolean beforeMethodConfiguration = method.getTestMethod().isBeforeMethodConfiguration();
        if (!beforeMethodConfiguration) {
            TestMethodCapture.currentMethods.remove();
            TestMethodCapture.currentResults.remove();
        }
    }

    public static Method getTestMethod() {
        return TestMethodCapture.checkNotNull(TestMethodCapture.currentMethods.get(),
                                              "Did you forget to register the %s listener?",
                                              TestMethodCapture.class.getName());
    }

    /**
     * Parameters passed from a data provider are accessible in the test result.
     */
    public static ITestResult getTestResult() {
        return TestMethodCapture.checkNotNull(TestMethodCapture.currentResults.get(),
                                              "Did you forget to register the %s listener?",
                                              TestMethodCapture.class.getName());
    }

    public static String getTestDescription() {
        final Method testMethod = TestMethodCapture.getTestMethod();
        final ITestResult testResult = TestMethodCapture.getTestResult();

        if (testMethod != null && testResult != null) {
            final String testMethodName =
                    testMethod.getDeclaringClass().getCanonicalName() + "." + testMethod.getName();
            final Object[] parameters = testResult.getParameters();
            final String[] parameterNames = new String[parameters.length];
            for (int i = 0; i < parameters.length; i++) {
                Object parameter = parameters[i];
                if (parameter instanceof FateData) {
                    final FateData fateData = (FateData) parameter;
                    parameterNames[i] = fateData.getIpRightNumber();
                }
                else {
                    parameterNames[i] = Objects.toString(parameter);
                }
            }
            return testMethodName + "(" + StringUtils.join(parameterNames, ", ") + ")";
        }
        else {
            return "";
        }
    }

    private static <T> T checkNotNull(final T o,
                                      final String msg,
                                      final Object param) {
        if (o == null) {
            LOGGER.warn(String.format(msg, param));
        }
        return o;
    }
}
