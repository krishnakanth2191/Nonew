package au.gov.ipaustralia.testng.helpers;

import java.lang.reflect.Method;

import org.apache.log4j.Logger;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import au.gov.ipaustralia.selenium.browser.ThreadSafeWebDriverStorage;

@Listeners(TestMethodCapture.class)
public class GenericTestSuite {

	private static final Logger LOGGER = Logger.getLogger(GenericTestSuite.class);
	String suiteName = "";

	@BeforeClass
	public void start() {

		suiteName = this.getClass().getSimpleName();

		LOGGER.info(new String(new char[suiteName.length() + 26]).replace("\0", "*"));
		LOGGER.info("*    Starting suite: " + suiteName + "    *");
		LOGGER.info(new String(new char[suiteName.length() + 26]).replace("\0", "*"));
		LOGGER.info("");

	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		LOGGER.info("Starting " + method.getName());
		Test note = method.getAnnotation(Test.class);
		Reporter.log(note.description());
	}

	public void quitDriver() {
		ThreadSafeWebDriverStorage.quitWebDriver();
	}

}
