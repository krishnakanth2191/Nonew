package au.gov.ipaustralia.selenium.fileReader;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import au.gov.ipaustralia.selenium.environment.EnvironmentVariables;

/**
 * Utilities for test data MSExcel spreadsheets
 * 
 * @author cpahan
 *
 */
public class ExcelReader {

	private static final Logger LOGGER = Logger.getLogger(ExcelReader.class);

	/**
	 * Overload with application default test data folder structure <br>
	 * NOTE if worksheet has a column called 'SKIP_ROW', and it's cell contains
	 * any value other than 'no' or empty, the row will not be included in the
	 * array.
	 * 
	 * @param aut..
	 *            application under test
	 * @param inputFile
	 *            ...
	 * @param sheetName
	 *            ...
	 * @return 2D array with element [*}[0] a data map for a row in the
	 *         worksheet
	 */
	public Object[][] getRowDataMap(String aut, String inputFile, String sheetName) {
		String filePath = EnvironmentVariables.getTestDataFolder(inputFile);

		return getRowDataMap(filePath, sheetName);
	}

	/**
	 * <br>
	 * NOTE if worksheet has a column called 'SKIP_ROW', and it's cell contains
	 * any value other than 'no' or empty, the row will not be included in the
	 * array.
	 * 
	 * @param inputFile
	 *            full file path and name
	 * @param sheetName
	 *            target MSExcel worksheet
	 * @return 2D array with element [*}[0] a data map for a row in the
	 *         worksheet
	 */
	public Object[][] getRowDataMap(String inputFile, String sheetName) {
		int cellTypeId;
		Sheet sheet = null;
		Map<String, String> dataMap = null;
		FileInputStream fis = null;
		Object[][] dataset = null;
		Workbook workbook = null;

		boolean skipRowColFound = false;
		int skipRowColumnIndex = -1;

		// Creating index map
		Map<String, Integer> index = new HashMap<>();
		try {
			fis = new FileInputStream(inputFile);
			workbook = new XSSFWorkbook(fis);
			workbook.setForceFormulaRecalculation(true);
			sheet = workbook.getSheet(sheetName);
			sheet.setForceFormulaRecalculation(true);
			workbook.close();

			// mapping column index with column name.
			Row firstRow = sheet.getRow(0);
			for (Cell cell : firstRow) {
				if (cell.getStringCellValue().trim().equalsIgnoreCase("SKIP_ROW")) {
					skipRowColFound = true;
					skipRowColumnIndex = cell.getColumnIndex();
				} else {
					index.put(cell.getStringCellValue(), cell.getColumnIndex());
				}
			}

			// get total rows count present in sheet
			int rowCount = sheet.getLastRowNum();
			// temp resizable collection to allow for skip rows
			Vector<Map<String, String>> dataVector = new Vector<>();

			// running for loop for each excel row and storing values in map
			rowiterator: for (int i = 0; i < rowCount; i++) {
				// initialize excel row map
				dataMap = new HashMap<>();
				Row rowData = sheet.getRow(i + 1);

				// poi getRow sometimes throws npe for an empty cell
				// :-(
				Cell skipRowCell = null;
				try {
					if (skipRowColFound) {
						skipRowCell = rowData.getCell(skipRowColumnIndex);
					}
				} catch (NullPointerException e) {
					LOGGER.info("Null Pointer Exception", e);
				}

				if (skipRowColFound && (skipRowCell != null)) {
					int skipCellType = skipRowCell.getCellType();
					if (skipCellType == 1 && "no".equalsIgnoreCase(skipRowCell.getStringCellValue().trim())) {
						// no == do not skip
					} else if (skipCellType == 1 && "".equalsIgnoreCase(skipRowCell.getStringCellValue().trim())) {
						// empty string or spaces == do not skip
					} else if (skipCellType == 3) {
						// empty cell == do not skip
					} else {
						// skip
						continue rowiterator;
					}
				}

				for (String key : index.keySet()) {
					int columnnum = index.get(key);
					// poi getRow sometimesometimes throws npe for an empty
					// cell :-(
					Cell targetCell = null;
					try {
						targetCell = rowData.getCell(columnnum);
					} catch (NullPointerException e) {
						LOGGER.info("Empty Cell found", e);
					}

					if ((targetCell != null)) {
						cellTypeId = targetCell.getCellType();
						if (cellTypeId == 0) { // numeric
							DecimalFormat df = new DecimalFormat("#");
							dataMap.put(key, df.format(targetCell.getNumericCellValue()));
							// string or formula
						} else if (cellTypeId == 1 || cellTypeId == 2) {
							dataMap.put(key, targetCell.getStringCellValue());
							// empty or error
						} else if (cellTypeId == 3 || cellTypeId == 5) {
							dataMap.put(key, "");
						} else if (cellTypeId == 4) { // boolean
							dataMap.put(key, Boolean.toString(targetCell.getBooleanCellValue()));
						}
					} else {
						dataMap.put(key, "");
					}
				}
				dataVector.addElement(dataMap);
			}
			dataset = new Object[dataVector.size()][1];
			for (int i = 0; i < dataVector.size(); i++) {
				dataset[i][0] = dataVector.get(i);
			}
			EnvironmentVariables.fileDelete(inputFile);
		} catch (FileNotFoundException e) {
			LOGGER.info("File Not Found", e);
		} catch (IOException e) {
			LOGGER.info("in and out Exception", e);

		}
		return dataset;
	}
}
