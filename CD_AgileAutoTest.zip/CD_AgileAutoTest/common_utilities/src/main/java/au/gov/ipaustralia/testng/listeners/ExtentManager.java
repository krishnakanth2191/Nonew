package au.gov.ipaustralia.testng.listeners;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.ReportConfigurator;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentManager {

    private static ExtentManager instance;

    private final ExtentReports extentReports;

    private final ThreadLocal<ExtentTest> parentTest = new ThreadLocal<>();

    private final ThreadLocal<ExtentTest> test = new ThreadLocal<>();

    public static synchronized ExtentManager getInstance() {

        if (ExtentManager.instance == null) {
            ExtentManager.instance = new ExtentManager();
        }

        return ExtentManager.instance;
    }

    private ExtentManager() {
        this.extentReports = this.createInstance("test-output/extent.html");
    }

    public ExtentReports createInstance(final String fileName) {
        final ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(fileName);
        htmlReporter.config().setTestViewChartLocation(ChartLocation.BOTTOM);
        htmlReporter.config().setChartVisibilityOnOpen(true);
        htmlReporter.config().setTheme(Theme.STANDARD);
        htmlReporter.config().setDocumentTitle(fileName);
        htmlReporter.config().setEncoding("utf-8");
        htmlReporter.config().setReportName(fileName);

        final ExtentReports reports = new ExtentReports();
        reports.attachReporter(htmlReporter);

        return reports;
    }

    public ExtentReports getExtentReports() {
        return this.extentReports;
    }

    public ExtentTest setTest(final ExtentTest test) {
        this.test.set(test);

        return test;
    }

    public ExtentTest getTest() {
        return this.test.get();
    }

    public ExtentTest setParent(final ExtentTest test) {
        this.parentTest.set(test);
        return test;
    }

    public ExtentTest getParentTest() {
        return this.parentTest.get();
    }

    public ExtentTest createTest(final String testName) {
        return this.extentReports.createTest(testName);
    }

    public void flush() {
        this.extentReports.flush();
    }

    public ReportConfigurator path() {
        return this.extentReports.config();
    }
    
}
