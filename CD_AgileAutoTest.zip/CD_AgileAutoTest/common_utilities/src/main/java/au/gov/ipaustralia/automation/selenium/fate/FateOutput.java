package au.gov.ipaustralia.automation.selenium.fate;

import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

final class FateOutput {

    private final Path dataFile;

    private final List<FateData> data;

    public FateOutput(final Path dataFile, final List<FateData> data) {
        super();
        this.dataFile = dataFile;

        final Map<String, List<FateData>> ipRightUniqueData =
                data.stream().collect(Collectors.groupingBy(FateData::getIpRightNumber));

        this.data =
                ipRightUniqueData.entrySet().stream().map(entry -> entry.getValue().get(0)).collect(Collectors.toList());
    }

    public Path getDataFile() {
        return this.dataFile;
    }

    public List<FateData> getData() {
        return this.data;
    }

}