package au.gov.ipaustralia.automation.selenium.helpers.db;

import java.util.HashMap;
import java.util.Map;

import au.gov.ipaustralia.selenium.environment.EnvironmentVariables;

/**
 * Interactions with the RIO Designs database
 * 
 * @author Anthony Hallett
 *
 */
public class IPRDBManager extends DatabaseManager {
    private String schemaName;
    private String customerID;

    public IPRDBManager() {
        super("RIODesigns");
        this.schemaName = EnvironmentVariables.getConfiguredItem("RIODesigns", "database-schema");
        this.customerID = EnvironmentVariables.getConfiguredItem("RIODesigns", "customer-id");
    }

    /**
     * @param status...
     * @param customer...
     * @param role...
     * @return RIODesignsData instance
     * 
     */
    public IPRDBManager getIPRight(String status,
                                   String customer,
                                   String role) {
        customerID = customer;
        return getIPRight(status, role);
    }

    /**
     * Uses configuration customer-id
     * 
     * @param status...
     * @param role...
     * @return RIODesignsData instance
     */
    public IPRDBManager getIPRight(String status,
                                   String role) {
        String roleCode = "";
        String[] roles = role.split(";");
        for (int i = 0; i < roles.length; i++) {
            if (i == 0) {
                roleCode += "'" + roles[i].toUpperCase() + "'";
            }
            else {
                roleCode += ", '" + roles[i].toUpperCase() + "'";
            }
        }

        String sQuery = "/*auto test data */\n";

        sQuery += "select distinct I.APPL_NUMBER as IP_RIGHT\n";
        sQuery += "from " + schemaName + ".IP_DTL I\n";
        sQuery += "join " + schemaName + ".PARTYROLE_IPDTL_ASSOC PR on (I.IP_DTL_ID = PR.IP_DTL_ID)\n";
        sQuery += "join " + schemaName + ".PARTY_PROXY PP on (PR.PARTY_PROXY_ID = PP.PARTY_PROXY_ID)\n";
        sQuery += "where I.IP_DTL_LEGAL_STATUS_CODE = '" + status.toUpperCase() + "'\n";
        sQuery += "and I.DATE_PAID_UNTIL > (sysdate + 180)\n";
        sQuery += "and PP.IPA_CUST_IDENTIFIER = '" + customerID.toUpperCase() + "'\n";
        sQuery += "and PR.PARTY_ROLE_CODE in (" + roleCode + ")\n";
        sQuery += "and not exists (\n";
        sQuery += "    select * \n";
        sQuery += "    from IPRIGHT.IP_SVC_DTL S\n";
        sQuery += "    where S.APPL_NUMBER = I.APPL_NUMBER\n";
        sQuery += "    and S.IP_SVC_TYPE_CODE not in ('APPLICATION', 'SUPPORTING_INFO')\n";
        sQuery += "    ) \n";
        sQuery += "and not exists (\n";
        sQuery += "    select *\n";
        sQuery += "    from " + schemaName + ".APPL_DTL_DESIGN E\n";
        sQuery += "    where I.IP_DTL_ID = E.IP_DTL_ID\n";
        sQuery += "    and E.MULTIPLE_DESIGN_IND = 'Y'\n";
        sQuery += "   )\n";

        sQuery += "order by SYS.DBMS_RANDOM.VALUE\n";

        runQuery(sQuery);
        return this;
    }

    /**
     * @return RIODesignsData instance
     */
    public IPRDBManager getRegisteredIPRightNotOwner() {

        String sQuery = "/*auto test data */\n";

        sQuery += "select D.APPL_NUMBER as IP_RIGHT\n";
        sQuery += "from " + schemaName + ".IP_DTL D, " + schemaName + ".PARTYROLE_IPDTL_ASSOC PR, " + schemaName
                + ".PARTY_PROXY PP\n";
        sQuery += "where D.IP_DTL_ID = PR.IP_DTL_ID\n";
        sQuery += "and PR.PARTY_PROXY_ID = PP.PARTY_PROXY_ID\n";
        sQuery += "and D.IP_DTL_LEGAL_STATUS_CODE = 'REGISTERED'\n";
        sQuery += "and D.APPL_NUMBER like '201%'\n";
        sQuery += "and sysdate - D.DATE_UPDATED > 2/24 -- at least2 hours old\n";
        sQuery += "and D.DATE_PAID_UNTIL > sysdate +  (2 * 365)\n";
        sQuery += "and not exists (\n";
        sQuery += "    select * \n";
        sQuery += "    from " + schemaName + ".PARTY_PROXY PX\n";
        sQuery += "    where PX.PARTY_PROXY_ID = PR.PARTY_PROXY_ID\n";
        sQuery += "    and PX.IPA_CUST_IDENTIFIER = '" + customerID + "'\n";
        sQuery += "  )\n";
        sQuery += "and PP.IPA_CUST_IDENTIFIER is not null /*dodgy CDH data */\n";
        sQuery += "and PP.IPA_CUST_IDENTIFIER <> ' ' /*dodgy CDH data */\n";
        sQuery += "and not exists (\n";
        sQuery += "   select C.IP_SVC_TYPE_CODE\n";
        sQuery += "   from " + schemaName + ".IP_SVC_DTL C\n";
        sQuery += "   where D.APPL_NUMBER = C.APPL_NUMBER\n";
        sQuery += "   and C.IP_SVC_TYPE_CODE not in ( 'APPLICATION', 'SUPPORTING_INFO')\n";
        sQuery += "  )\n";

        sQuery += "order by SYS.DBMS_RANDOM.VALUE\n";

        runQuery(sQuery);

        return this;
    }

    /**
     * @param ipRight...
     * @return RIODesignsData instance
     */
    public IPRDBManager getCustomerIdForIPRight(String ipRight) {
        String sQuery = "/*auto test data */\n";

        sQuery += "select distinct PP.IPA_CUST_IDENTIFIER as CUSTOMER_ID\n";
        sQuery += "from " + schemaName + ".IP_SVC_DTL A, " + schemaName + ".PARTYROLE_IPDTL_ASSOC R, " + schemaName
                + ".PARTY_PROXY PP\n";
        sQuery += "where A.IP_DTL_ID = R.IP_DTL_ID\n";
        sQuery += "and R.PARTY_PROXY_ID = PP.PARTY_PROXY_ID\n";
        sQuery += "and PP.IPA_CUST_IDENTIFIER is not null\n";
        sQuery += "and A.APPL_NUMBER = '" + ipRight + "'\n";

        sQuery += "order by SYS.DBMS_RANDOM.VALUE";

        runQuery(sQuery);

        return this;
    }

    /**
     * @param ipRight...
     * @return RIODesignsData instance
     */
    public IPRDBManager getCustomerDocumentsID(String ipRight,
                                               String CodeType) {
        String sQuery = "/*auto test data */\n";

        sQuery += "select dd.doc_object_identifier\n";
        sQuery += "from " + schemaName + ".DOC_DTL dd\n";
        sQuery += "where dd.doc_dtl_id in\n";
        sQuery += "   (select d.doc_dtl_id \n";
        sQuery += "   from " + schemaName + ".IPDTL_DOCDTL_ASSOC d, " + schemaName + ".ip_dtl i\n";
        sQuery += "   where d.ip_dtl_id = i.ip_dtl_id\n";
        sQuery += "   and i.ip_right_identifier = '" + ipRight + "'\n";
        sQuery += "   and dd.doc_type_code = '" + CodeType + "')\n";

        runQuery(sQuery);

        return this;
    }

    /**
     * @param status...
     * @param customer...
     * @return RIODesignsData instance
     */
    public IPRDBManager getExcluded(String status,
                                    String customer) {
        customerID = customer;
        return getExcluded(status);
    }

    /**
     * @param status...
     * @return RIODesignsData instance
     */
    public IPRDBManager getExcluded(String status) {
        String sQuery = "/*auto test data */\n";

        sQuery += "select D.APPL_NUMBER\n";
        sQuery += "from IPRIGHT.IP_DTL D\n";
        sQuery += "		where sysdate - D.DATE_UPDATED > 2/24 --2 hours old\n";
        sQuery += "		and sysdate - D.DATE_UPDATED < 60\n";
        sQuery += "		and D.IP_DTL_LEGAL_STATUS_CODE = '" + status.toUpperCase() + "'\n";
        sQuery += "		and D.IP_DTL_ID in (\n";
        sQuery += "		  select B.IP_DTL_ID from IPRIGHT.PARTYROLE_IPDTL_ASSOC B\n";
        sQuery += "		  where B.PARTY_ROLE_CODE in ('APPLICANT', 'AGENT')\n";
        sQuery += "		  and B.PARTY_PROXY_ID in (\n";
        sQuery += "		    select pp.party_proxy_id\n";
        sQuery += "		    from ipright.party_proxy pp\n";
        sQuery += "		    where pp.ipa_cust_identifier = '" + customerID.toUpperCase() + "'\n";
        sQuery += "		    ))\n";
        sQuery += "order by SYS.DBMS_RANDOM.VALUE";

        runQuery(sQuery);
        return this;
    }

    /**
     * @param status...
     * @param customer...
     * @return RIODesignsData instance
     */
    public IPRDBManager getIPRight_NotParty(String status,
                                            String customer) {
        String sQuery = "/*auto test data */\n";

        sQuery += "select distinct D.APPL_NUMBER as IP_RIGHT\n";
        sQuery += "from " + schemaName + ".IP_DTL D\n";
        sQuery += "join " + schemaName + ".PARTYROLE_IPDTL_ASSOC PR on (D.IP_DTL_ID = PR.IP_DTL_ID)\n";
        sQuery += "join " + schemaName + ".PARTY_PROXY PP on (PR.PARTY_PROXY_ID = PP.PARTY_PROXY_ID)\n";
        sQuery += "join " + schemaName + ".IP_SVC_DTL A on (A.IP_DTL_ID = D.IP_DTL_ID)\n";
        sQuery += "where  D.IP_DTL_LEGAL_STATUS_CODE = '" + status.toUpperCase() + "'\n";
        sQuery += "and D.APPL_NUMBER like '201%'\n";
        sQuery += "and A.CLIENT_REF_TEXT like 'DN_2017%'\n";
        sQuery += "and sysdate - D.DATE_UPDATED > 2/24 -- at least2 hours old  \n";
        sQuery += "and PP.IPA_CUST_IDENTIFIER is not null /*dodgy CDH data */\n";
        sQuery += "and PP.IPA_CUST_IDENTIFIER <> ' ' /*dodgy CDH data */\n";
        sQuery += "and not exists (\n";
        sQuery += "    select *\n";
        sQuery += "   from " + schemaName + ".PARTY_PROXY PX\n";
        sQuery += "   where PX.PARTY_PROXY_ID = PR.PARTY_PROXY_ID\n";
        sQuery += "    and PX.IPA_CUST_IDENTIFIER = '" + customerID + "'\n";
        sQuery += "   )\n";
        sQuery += "and not exists (\n";
        sQuery += "  select C.IP_SVC_TYPE_CODE\n";
        sQuery += "   from " + schemaName + ".IP_SVC_DTL C\n";
        sQuery += "   where D.APPL_NUMBER = C.APPL_NUMBER\n";
        sQuery += "   and C.IP_SVC_TYPE_CODE not in ( 'APPLICATION', 'SUPPORTING_INFO', 'EXAMINATION')\n";
        sQuery += "  )\n";
        sQuery += "and not exists (\n";
        sQuery += "    select *\n";
        sQuery += "    from " + schemaName + ".APPL_DTL_DESIGN E\n";
        sQuery += "    where D.IP_DTL_ID = E.IP_DTL_ID\n";
        sQuery += "    and E.MULTIPLE_DESIGN_IND = 'Y'\n";
        sQuery += "   )\n";

        sQuery += "order by SYS.DBMS_RANDOM.VALUE\n";

        runQuery(sQuery);

        return this;
    }

    /**
     * @param status...
     * @param customer...
     * @return RIODesignsData instance
     */
    public IPRDBManager getIPRight_NotParty_DB_Change(String status,
                                                      String customer) {
        String sQuery = "/*auto test data */\n";

        sQuery += "select distinct D.APPL_NUMBER as IP_RIGHT\n";
        sQuery += "from " + schemaName + ".IP_DTL D\n";
        sQuery += "join " + schemaName + ".PARTYROLE_IPDTL_ASSOC PR on (D.IP_DTL_ID = PR.IP_DTL_ID)\n";
        sQuery += "join " + schemaName + ".PARTY_PROXY PP on (PR.PARTY_PROXY_ID = PP.PARTY_PROXY_ID)\n";
        sQuery += "join " + schemaName + ".IP_SVC_DTL A on (A.IP_DTL_ID = D.IP_DTL_ID)\n";
        sQuery += "where  D.IP_DTL_STATUS_CODE = '" + status.toUpperCase() + "'\n";
        sQuery += "and D.APPL_NUMBER like '2017%'\n";
        sQuery += "and A.CLIENT_REF_TEXT like 'DN_2017%'\n";
        sQuery += "and sysdate - D.DATE_UPDATED > 2/24 -- at least2 hours old  \n";
        sQuery += "and PP.IPA_CUST_IDENTIFIER is not null /*dodgy CDH data */\n";
        sQuery += "and PP.IPA_CUST_IDENTIFIER <> ' ' /*dodgy CDH data */\n";
        sQuery += "and not exists (\n";
        sQuery += "    select *\n";
        sQuery += "   from " + schemaName + ".PARTY_PROXY PX\n";
        sQuery += "   where PX.PARTY_PROXY_ID = PR.PARTY_PROXY_ID\n";
        sQuery += "    and PX.IPA_CUST_IDENTIFIER = '" + customerID + "'\n";
        sQuery += "   )\n";
        sQuery += "and not exists (\n";
        sQuery += "  select C.IP_SVC_TYPE_CODE\n";
        sQuery += "   from " + schemaName + ".IP_SVC_DTL C\n";
        sQuery += "   where D.APPL_NUMBER = C.APPL_NUMBER\n";
        sQuery += "   and C.IP_SVC_TYPE_CODE not in ( 'APPLICATION', 'SUPPORTING_INFO', 'EXAMINATION')\n";
        sQuery += "  )\n";
        sQuery += "and not exists (\n";
        sQuery += "    select *\n";
        sQuery += "    from " + schemaName + ".APPL_DTL_DESIGN E\n";
        sQuery += "    where D.IP_DTL_ID = E.IP_DTL_ID\n";
        sQuery += "    and E.MULTIPLE_DESIGN_IND = 'Y'\n";
        sQuery += "   )\n";

        sQuery += "order by SYS.DBMS_RANDOM.VALUE\n";

        runQuery(sQuery);

        return this;
    }

    /**
     * queries new app with nominated client reference and status of received.
     * 
     * @param clientRef..
     * @return RIODesignsData instance
     */
    public IPRDBManager getIPRightForNewApp(String clientRef) {
        return getIPRightWithClientRefandStatus(clientRef, "RECEIVED");
    }

    /**
     * queries IPRight with nominated client reference in the nominated status
     * 
     * @param clientRef
     *            ...
     * @param status
     *            ...
     * 
     * @return RIODesignsData instance
     */
    public IPRDBManager getIPRightWithClientRefandStatus(String clientRef,
                                                         String status) {
        String sQuery = "/*auto test data */\n";
        sQuery += "select A.APPL_NUMBER as IP_RIGHT\n";
        sQuery += "from " + schemaName + ".IP_SVC_DTL A\n";
        sQuery += "join " + schemaName + ".IP_DTL I on (A.IP_DTL_ID = I.IP_DTL_ID)\n";
        sQuery += "where A.CLIENT_REF_TEXT like '" + clientRef + "%'\n";
        sQuery += "and A.IP_SVC_TYPE_CODE ='APPLICATION'\n";
        sQuery += "and A.DATE_CREATED > (sysdate - 10)\n";
        sQuery += "and I.Ip_Dtl_legal_Status_Code = '" + status + "'\n";
        sQuery += "order by A.DATE_UPDATED desc\n";
        runQuery(sQuery);

        return this;
    }

    /**
     * @return query result set
     */
    public Map<String, String> getValidIPRightWithAdverseFormalities() {
        String sQuery = "/*auto test data */\n";
        sQuery += "select A.APPL_NUMBER, A.WORK_CASE_IDENTIFIER\n";
        sQuery += "from IPRIGHT.IP_SVC_DTL A, IPRIGHT.ASSESSMENT B, IPRIGHT.IP_DTL D\n";
        sQuery += "where B.IP_SVC_DTL_ID = A.IP_SVC_DTL_ID\n";
        sQuery += "and A.IP_DTL_ID = D.IP_DTL_ID\n";
        sQuery += "and A.DATE_CREATED > (sysdate - 10)\n";
        sQuery += "and sysdate - A.DATE_UPDATED > 1/24 --2 hours old\n";
        sQuery += "and A.CLIENT_REF_TEXT like 'DN_2%'\n";
        sQuery += "and D.IP_DTL_LEGAL_STATUS_CODE = 'FILED'\n";
        sQuery += "and B.ASSESSMENT_TYPE_CODE = 'FORMALITIES'\n";
        sQuery += "and B.ASSESSMENT_OUTCOME_TYPE_CODE = 'ADVERSE'\n";
        sQuery += "and A.APPL_NUMBER not in (\n";
        sQuery += "    select AX.APPL_NUMBER\n";
        sQuery += "    from IPRIGHT.IP_SVC_DTL AX,IPRIGHT.ASSESSMENT BX\n";
        sQuery += "    where BX.IP_SVC_DTL_ID = AX.IP_SVC_DTL_ID\n";
        sQuery += "    and BX.ASSESSMENT_TYPE_CODE = 'FORMALITIES'\n";
        sQuery += "    and BX.ASSESSMENT_OUTCOME_TYPE_CODE = 'CLEAR'\n";
        sQuery += ")\n";
        sQuery += "order by A.APPL_NUMBER asc\n";
        runQuery(sQuery);

        HashMap<String, String> results = new HashMap<>();
        for (Map<String, Object> row : data) {
            String ipRight = row.get("APPL_NUMBER").toString();
            if ((new ATMOSSDBManager().verifyIpRightInAtmoss(ipRight))) {
                results.put("IP_RIGHT", ipRight);
                results.put("WORK_CASE_ID", row.get("WORK_CASE_IDENTIFIER").toString());
                break;
            }
        }
        return results;
    }

    /**
     * @return query result set
     */

    public Map<String, String> getValidFiledIPRightforExcluded() {

        String sQuery = "/*auto test data */\n";
        sQuery += "select distinct A.APPL_NUMBER, D.IP_DTL_LEGAL_STATUS_CODE\n";
        sQuery += "from IPRIGHT.IP_SVC_DTL A\n";
        sQuery += "join IPRIGHT.IP_DTL D on(A.IP_DTL_ID = D.IP_DTL_ID)\n";
        sQuery += "where D.IP_DTL_LEGAL_STATUS_CODE = 'FILED'\n";
        sQuery += "and A.DATE_CREATED > (sysdate - 3)\n";
        sQuery += "order by SYS.DBMS_RANDOM.VALUE\n";
        runQuery(sQuery);

        HashMap<String, String> results = new HashMap<>();
        for (Map<String, Object> row : data) {
            String ipRight = row.get("APPL_NUMBER").toString();
            if ((new ATMOSSDBManager().verifyIpRightInAtmoss(ipRight))) {
                results.put("IP_RIGHT", ipRight);
                break;
            }
        }
        return results;
    }

    /**
     * @return query result set
     */
    public Map<String, String> getValidIPRightWithFurhterFormalities() {
        String sQuery = "/*auto test data */\n";
        sQuery += "select A.APPL_NUMBER, A.WORK_CASE_IDENTIFIER\n";
        sQuery += "from IPRIGHT.IP_SVC_DTL A, IPRIGHT.ASSESSMENT B, IPRIGHT.IP_DTL D\n";
        sQuery += "where B.IP_SVC_DTL_ID = A.IP_SVC_DTL_ID\n";
        sQuery += "and A.IP_DTL_ID = D.IP_DTL_ID\n";
        sQuery += "and A.DATE_CREATED > (sysdate - 5)\n";
        sQuery += "and sysdate - A.DATE_UPDATED > 1/24 --2 hours old\n";
        sQuery += "and A.CLIENT_REF_TEXT like 'DN_Furt%'\n";
        sQuery += "and D.IP_DTL_LEGAL_STATUS_CODE = 'FILED'\n";
        sQuery += "and B.ASSESSMENT_TYPE_CODE = 'FORMALITIES'\n";
        sQuery += "and B.ASSESSMENT_OUTCOME_TYPE_CODE = 'ADVERSE'\n";
        sQuery += "and A.APPL_NUMBER not in (\n";
        sQuery += "    select AX.APPL_NUMBER\n";
        sQuery += "    from IPRIGHT.IP_SVC_DTL AX,IPRIGHT.ASSESSMENT BX\n";
        sQuery += "    where BX.IP_SVC_DTL_ID = AX.IP_SVC_DTL_ID\n";
        sQuery += "    and BX.ASSESSMENT_TYPE_CODE = 'FORMALITIES'\n";
        sQuery += "    and BX.ASSESSMENT_OUTCOME_TYPE_CODE = 'CLEAR'\n";
        sQuery += ")\n";
        sQuery += "order by A.APPL_NUMBER asc\n";
        runQuery(sQuery);
        HashMap<String, String> results = new HashMap<>();

        for (Map<String, Object> row : data) {
            String ipRight = row.get("APPL_NUMBER").toString();
            if ((new ATMOSSDBManager().verifyIpRightInAtmoss(ipRight))) {
                results.put("IP_RIGHT", ipRight);
                results.put("WORK_CASE_ID", row.get("WORK_CASE_IDENTIFIER").toString());
                break;
            }
        }
        return results;
    }

    /**
     * @return query result set
     */
    public Map<String, String> getValidIPRightWithEOTFormalities() {
        String sQuery = "/*auto test data */\n";
        sQuery += "select distinct A.APPL_NUMBER, A.WORK_CASE_IDENTIFIER\n";
        sQuery += "from IPRIGHT.IP_SVC_DTL A, IPRIGHT.ASSESSMENT B, IPRIGHT.IP_DTL D\n";
        sQuery += "where B.IP_SVC_DTL_ID = A.IP_SVC_DTL_ID\n";
        sQuery += "and A.IP_DTL_ID = D.IP_DTL_ID\n";
        sQuery += "and A.DATE_CREATED > (sysdate - 5)\n";
        sQuery += "and sysdate - A.DATE_UPDATED > 1/24 --1 hours old\n";
        sQuery += "and A.CLIENT_REF_TEXT like 'DN_EOT_201%'\n";
        sQuery += "and D.IP_DTL_LEGAL_STATUS_CODE = 'FILED'\n";
        sQuery += "and A.WORK_CASE_IDENTIFIER like 'APP%'\n";
        sQuery += "order by A.APPL_NUMBER asc\n";
        runQuery(sQuery);
        HashMap<String, String> results = new HashMap<>();

        for (Map<String, Object> row : data) {
            String ipRight = row.get("APPL_NUMBER").toString();
            {
                results.put("IP_RIGHT", ipRight);
                results.put("WORK_CASE_ID", row.get("WORK_CASE_IDENTIFIER").toString());
                break;
            }
        }
        return results;
    }

    /**
     * @return query result set
     */
    public Map<String, String> getValidIPRightWithDAAFormalities() {
        String sQuery = "/*auto test data */\n";
        sQuery += "select distinct A.APPL_NUMBER, A.WORK_CASE_IDENTIFIER\n";
        sQuery += "from IPRIGHT.IP_SVC_DTL A, IPRIGHT.ASSESSMENT B, IPRIGHT.IP_DTL D\n";
        sQuery += "where B.IP_SVC_DTL_ID = A.IP_SVC_DTL_ID\n";
        sQuery += "and A.IP_DTL_ID = D.IP_DTL_ID\n";
        sQuery += "and A.DATE_CREATED > (sysdate - 5)\n";
        sQuery += "and sysdate - A.DATE_UPDATED > 1/24 --1 hours old\n";
        sQuery += "and A.CLIENT_REF_TEXT like 'DN_DACA_201%'\n";
        sQuery += "and D.IP_DTL_LEGAL_STATUS_CODE = 'FILED'\n";
        sQuery += "and A.WORK_CASE_IDENTIFIER like 'APP%'\n";
        sQuery += "order by A.APPL_NUMBER asc\n";
        runQuery(sQuery);
        HashMap<String, String> results = new HashMap<>();

        for (Map<String, Object> row : data) {
            String ipRight = row.get("APPL_NUMBER").toString();
            {
                results.put("IP_RIGHT", ipRight);
                results.put("WORK_CASE_ID", row.get("WORK_CASE_IDENTIFIER").toString());
                break;
            }
        }
        return results;
    }

    /**
     * @return query result set
     */
    public Map<String, String> getValidIPRightWithDAAARFormalities() {
        String sQuery = "/*auto test data */\n";
        sQuery += "select distinct A.APPL_NUMBER, A.WORK_CASE_IDENTIFIER\n";
        sQuery += "from IPRIGHT.IP_SVC_DTL A, IPRIGHT.ASSESSMENT B, IPRIGHT.IP_DTL D\n";
        sQuery += "where B.IP_SVC_DTL_ID = A.IP_SVC_DTL_ID\n";
        sQuery += "and A.IP_DTL_ID = D.IP_DTL_ID\n";
        sQuery += "and A.DATE_CREATED > (sysdate - 5)\n";
        sQuery += "and sysdate - A.DATE_UPDATED > 1/24 --1 hours old\n";
        sQuery += "and A.CLIENT_REF_TEXT like 'DN_DAAR_201%'\n";
        sQuery += "and D.IP_DTL_LEGAL_STATUS_CODE = 'FILED'\n";
        sQuery += "and A.WORK_CASE_IDENTIFIER like 'APP%'\n";
        sQuery += "order by A.APPL_NUMBER asc\n";
        runQuery(sQuery);
        HashMap<String, String> results = new HashMap<>();

        for (Map<String, Object> row : data) {
            String ipRight = row.get("APPL_NUMBER").toString();
            {
                results.put("IP_RIGHT", ipRight);
                results.put("WORK_CASE_ID", row.get("WORK_CASE_IDENTIFIER").toString());
                break;
            }
        }
        return results;
    }

    /**
     * @return query result set
     */
    public Map<String, String> getValidIPRightWithMIPFormalities() {
        String sQuery = "/*auto test data */\n";
        sQuery += "select distinct A.APPL_NUMBER, A.WORK_CASE_IDENTIFIER\n";
        sQuery += "from IPRIGHT.IP_SVC_DTL A, IPRIGHT.ASSESSMENT B, IPRIGHT.IP_DTL D\n";
        sQuery += "where B.IP_SVC_DTL_ID = A.IP_SVC_DTL_ID\n";
        sQuery += "and A.IP_DTL_ID = D.IP_DTL_ID\n";
        sQuery += "and A.DATE_CREATED > (sysdate - 5)\n";
        sQuery += "and sysdate - A.DATE_UPDATED > 1/24 --1 hours old\n";
        sQuery += "and A.CLIENT_REF_TEXT like 'DN_MIP_201%'\n";
        sQuery += "and D.IP_DTL_LEGAL_STATUS_CODE = 'FILED'\n";
        sQuery += "and A.WORK_CASE_IDENTIFIER like 'APP%'\n";
        sQuery += "order by A.APPL_NUMBER asc\n";
        runQuery(sQuery);
        HashMap<String, String> results = new HashMap<>();

        for (Map<String, Object> row : data) {
            String ipRight = row.get("APPL_NUMBER").toString();
            {
                results.put("IP_RIGHT", ipRight);
                results.put("WORK_CASE_ID", row.get("WORK_CASE_IDENTIFIER").toString());
                break;
            }
        }
        return results;
    }

    /**
     * @return query result set
     */
    public Map<String, String> getIPRightStatusAndInforceDateForRenewal() {
        String sQuery = "/*auto test data */\n";
        sQuery += "select distinct S.APPL_NUMBER, D.IP_DTL_STATUS_CODE, D.DATE_PAID_UNTIL\n";
        sQuery += "from IPRIGHT.IP_SVC_DTL S\n";
        sQuery += "join IPRIGHT.IP_DTL D on(S.IP_DTL_ID = D.IP_DTL_ID)\n";
        sQuery += "where D.IP_DTL_STATUS_CODE in ('REGISTERED', 'CERTIFIED')\n";
        sQuery += "and substr(S.WORK_CASE_IDENTIFIER,1,3) = 'REM'\n";
        sQuery += "and D.DATE_PAID_UNTIL < D.DATE_IP_RIGHT_EXPIRY_DUE\n";
        sQuery += "and D.DATE_PAID_UNTIL > sysdate\n";
        sQuery += "order by SYS.DBMS_RANDOM.VALUE\n";

        runQuery(sQuery);
        HashMap<String, String> results = new HashMap<>();

        for (Map<String, Object> row : data) {
            results.put("IP_RIGHT", row.get("APPL_NUMBER").toString());
            results.put("STATUS", row.get("IP_DTL_STATUS_CODE").toString());
            results.put("IN_FORCE_DATE", row.get("DATE_PAID_UNTIL").toString());
        }
        return results;
    }
}
