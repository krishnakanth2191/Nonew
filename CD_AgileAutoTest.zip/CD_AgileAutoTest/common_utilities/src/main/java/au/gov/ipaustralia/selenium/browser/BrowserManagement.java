package au.gov.ipaustralia.selenium.browser;

import java.util.function.Consumer;
import java.util.function.Function;

import org.openqa.selenium.WebDriver;

import com.jcabi.aspects.LogExceptions;
import com.jcabi.aspects.Loggable;

import au.gov.ipaustralia.selenium.environment.EnvironmentVariables;

@Loggable(prepend = true, value = Loggable.DEBUG)
public class BrowserManagement {

	private BrowserManagement() {
		throw new IllegalStateException("BrowserManagement class");
	}

	/**
	 * Creates a new browser instance without performing the login.
	 *
	 * @param actions
	 *            the actions to be performed in the context of the driver
	 * @return the value produced by the action
	 */
	@LogExceptions
	public static <T> T browserAndReturn(final Function<WebDriver, T> actions) {
		final String browserType = EnvironmentVariables.getBrowserType();
		final int timeOut = EnvironmentVariables.getGlobalTimeout();

		final WebDriver driver = Browser.invokeBrowser(browserType, timeOut);

		try {
			final T result = actions.apply(driver);
			return result;
		} finally {
			ThreadSafeWebDriverStorage.quitWebDriver(driver);
		}
	}

	/**
	 * Creates a new browser instance without performing the login. The response
	 * of the actions is not returned.
	 *
	 * @param actions
	 *            the actions to be performed in the context of the driver
	 */
	@LogExceptions
	public static void browser(final Consumer<WebDriver> actions) {
		final String browserType = EnvironmentVariables.getBrowserType();
		final int timeOut = EnvironmentVariables.getGlobalTimeout();

		final WebDriver driver = Browser.invokeBrowser(browserType, timeOut);

		try {
			actions.accept(driver);
		} finally {
			ThreadSafeWebDriverStorage.quitWebDriver(driver);
		}
	}

}
