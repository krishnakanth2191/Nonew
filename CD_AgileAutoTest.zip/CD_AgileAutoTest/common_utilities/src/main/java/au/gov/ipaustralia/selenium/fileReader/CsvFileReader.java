package au.gov.ipaustralia.selenium.fileReader;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import com.jcabi.aspects.Loggable;
import com.opencsv.CSVReader;

@Loggable(prepend = true)
public class CsvFileReader {

    private ArrayList<HashMap<String, String>> dataRows = new ArrayList<>();

    public CsvFileReader(String fileName) throws IOException {
        addDataLocation(fileName);
    }

    protected void addDataLocation(String fileLocation) throws IOException {
        try (FileReader fileReader = new FileReader(fileLocation)) {

            try (CSVReader cs = new CSVReader(fileReader)) {
                final String[] headings = cs.readNext();

                int rowNumber = 0;
                String[] nextLine;

                while ((nextLine = cs.readNext()) != null) {
                    if (dataRows.size() <= rowNumber) {
                        dataRows.add(rowNumber, new HashMap<String, String>());
                    }

                    for (int i = 0; i < nextLine.length; i++) {
                        dataRows.get(rowNumber).put(headings[i], nextLine[i]);
                    }
                    dataRows.get(rowNumber).put("rownumber", Integer.toString(rowNumber));
                    rowNumber++;
                }
            }
        }
    }

    public Object[][] getAllDataRows() {
        Object[][] returnObject = new Object[this.dataRows.size()][1];
        for (int itemIndex = 0; itemIndex < this.dataRows.size(); itemIndex++) {
            returnObject[itemIndex][0] = this.dataRows.get(itemIndex);
        }
        return returnObject;
    }

}
