package au.gov.ipaustralia.testng.helpers;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.jcabi.aspects.Loggable;

/**
 * defines abstracts for a few things that all pages should have<br>
 * No real logic pragmatic collection of attributes and methods which are
 * convenient to use across all pages
 *
 * 
 * @author Anthony Hallett
 *
 */
@Loggable(prepend = true)
public class ScreenCapture extends BasePage {

	private static final Logger LOGGER = Logger.getLogger(ScreenCapture.class);
	
	static String timeStamp_1 = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
	static String dest_1 = "test-output"+ File.separator +"ScreenShot"+ File.separator +"ScreenShot"+ File.separator + timeStamp_1 + ".png";

	
	/**
	 * This method will take screenshot get attached to the Log reports.
	 * 
	 * @param Webdriver,
	 *            Description of Case Step, FileNamme to be saved
	 * @return 
	 */
	public static String capture(WebDriver driver) {
		TakesScreenshot screen = (TakesScreenshot)driver;
		File src = screen.getScreenshotAs(OutputType.FILE);
		File target = new File(dest_1);
		try {
			FileUtils.copyFile(src, target);

		} catch (IOException e) {
			LOGGER.info("IO Exception", e);

		}
	
	return dest_1;
	}
}
