package au.gov.ipaustralia.automation.selenium.helpers.db;

import org.apache.log4j.Logger;

/**
 * Interactions with the ATMOSS database
 * 
 * @author cpahan
 *
 */
public class ATMOSSDBManager extends DatabaseManager {
	
	private static final  String FROM_FALCON_TM_TRADEMARKS = "from falcon.TM_TRADE_MARKS tm\n";
	private static final Logger LOGGER = Logger.getLogger(ATMOSSDBManager.class);

	public ATMOSSDBManager() {
		super("DB_Atmoss");
	}

	/**
	 * Finds valid design iprights with the given status
	 * 
	 * @param status
	 *            one of Filed, Registered, Certified, Published; Lapsed
	 * @return ATMOSSData instance
	 */

	private static final  String MESSAGE_DISPLAY = "/*auto test data */\n";

	/**
	 * @param status,
	 *            L, LF == Filed, // R, RR, RU == Registered, // U == Published,
	 *            // N == Lapsed, // RX == Certified
	 * @return
	 * 
	 */

	public ATMOSSDBManager getIPRight(String status) {

		String statusCodes = "";
		if ("FILED".equalsIgnoreCase(status)) {
			statusCodes = "'L','LF'";

		} else if ("REGISTERED".equalsIgnoreCase(status)) {
			statusCodes = "'R', 'RR', 'RU'";
		} else if ("PUBLISHED".equalsIgnoreCase(status)) {
			statusCodes = "'U'";

		} else if ("LAPSED".equalsIgnoreCase(status)) {
			statusCodes = "'N'";

		} else if ("CERTIFIED".equalsIgnoreCase(status)) {
			statusCodes = "'RX'";

		} else {
			throw new DatabaseManagerException("Status '" + status + "' is not recognised.");
		}

		String sQuery = MESSAGE_DISPLAY;

		sQuery += "SELECT application_id as IP_RIGHT FROM adds.adds_designs a\n";
		sQuery += "WHERE a.status_code_id in (" + statusCodes + ")\n";
		sQuery += "AND a.new_act_ind IN ('Y', 'M')\n";
		sQuery += "AND (a.agent_id is not null\n";
		sQuery += "    OR a.service_address is not null)\n";
		sQuery += "AND a.primary_class is not null\n";
		sQuery += "AND a.first_multiple_application_id is null\n";
		sQuery += "AND NOT EXISTS ";
		sQuery += "  (SELECT * FROM adds.adds_olm z\n";
		sQuery += "   WHERE z.code_type = 'MOR'\n";
		sQuery += "   AND z.code_id = 'N'\n";
		sQuery += "   AND z.application_id = a.application_id";
		sQuery += "   ) /* no mortgages */\n";
		sQuery += "ORDER BY sys.dbms_random.value\n";

		runQuery(sQuery);

		return this;
	}

	/**
	 * Finds valid trademark numbers
	 * 
	 * @param status
	 *            pending or registered
	 * @return ATMOSSData instance
	 */
	public ATMOSSDBManager getPendingTradeMarkID(String status) {

		String statusCodes;
		if ("PENDING".equalsIgnoreCase(status)) {
			statusCodes = "6";
		} else if ("REGISTERED".equalsIgnoreCase(status)) {
			statusCodes = "31, 35";
		} else {
			throw new DatabaseManagerException("Status '" + status + "' is not recognised.");
		}

		String sQuery = MESSAGE_DISPLAY;

		sQuery += "select tm.tm_number\n";
		sQuery += FROM_FALCON_TM_TRADEMARKS;
		sQuery += "where tm.lodgement_date is not null\n";
		sQuery += "and tm.status in  (" + statusCodes + ")\n";
		sQuery += "order by sys.dbms_random.value\n";

		runQuery(sQuery);

		return this;
	}

	/**
	 * verifies that the given ipright exists in the dB this is a way to 'vet'
	 * data which is in IPRDS but may not exist in ATMOSS due to bugs / timing
	 * 
	 * @param ipRight
	 *            ..
	 * @return true if ipright is in ATMOSS dB
	 */
	public boolean verifyIpRightInAtmoss(String ipRight) {
		boolean found = false;
		String sQuery = MESSAGE_DISPLAY;

		sQuery += "SELECT application_id as IP_RIGHT FROM adds.adds_designs a\n";
		sQuery += "WHERE a.application_id  = '" + ipRight + "'\n";

		try {
			runQuery(sQuery);
			if (this.data.size() > 0) {
				found = true;
			}
		} catch (DatabaseManagerException e) {
		    LOGGER.info("DataBaseManagerException", e);
			found = false;
		}

		return found;

	}

	/**
	 * Finds valid renewable trademark numbers
	 * 
	 * @return ATMOSSData instance
	 */
	public ATMOSSDBManager getTradeMarkRenewalNumber() {
		String sQuery = MESSAGE_DISPLAY;

		sQuery += "SELECT tm.tm_number\n";
		sQuery += FROM_FALCON_TM_TRADEMARKS;
		sQuery += "WHERE tm.lodgement_date is not null\n";
		sQuery += "AND tm.status IN (31,35)\n";
		sQuery += "AND tm.renewal_due IS NOT NULL\n";
		sQuery += "AND tm.renewal_due > add_months(sysdate, -6)\n";
		sQuery += "AND tm.ir_number = 0\n";
		sQuery += "ORDER BY dbms_random.value\n";

		runQuery(sQuery);

		return this;
	}

	/**
	 * Finds valid renewable Design numbers
	 * 
	 * @return ATMOSSData instance
	 */
	public ATMOSSDBManager getDesignRenewalNumber() {
		String sQuery = MESSAGE_DISPLAY;

		sQuery += "SELECT APPLICATION_ID\n";
		sQuery += "from adds.ADDS_DESIGNS t\n";
		sQuery += "WHERE t.new_act_ind in ('Y', 'M')\n";
		sQuery += "AND t.status_code_id = 'RX'\n";
		sQuery += "AND t.in_force_until_date < t.max_registration_period\n";
		sQuery += "AND t.in_force_until_date < sysdate\n";
		sQuery += "AND t.in_force_until_date > (sysdate - 60)\n";
		sQuery += "ORDER BY dbms_random.value\n";

		runQuery(sQuery);

		return this;
	}
	
	/**
	 * Finds valid Pre-Registered Designs numbers
	 * 
	 * @return ATMOSSData instance
	 */
	public ATMOSSDBManager getDesignsFormalitiesNoticeNumber() {
		String sQuery = MESSAGE_DISPLAY;

		sQuery += "SELECT APPLICATION_ID\n";
		sQuery += "from adds.ADDS_DESIGNS t\n";
		sQuery += "WHERE t.new_act_ind in ('Y', 'M')\n";
		sQuery += "AND t.status_code_id IN ('R', 'FR', 'G', 'RR', 'RU', 'RX', 'P')\n";
		sQuery += "AND T.REGISTRATION_DATE IS NOT NULL\n";
		sQuery += "AND t.in_force_until_date >= sysdate\n";
		sQuery += "AND t.renewed_to_1st_period_date is NULL\n";
		sQuery += "ORDER BY dbms_random.value\n";
		
		runQuery(sQuery);

		return this;
	}


	/**
	 * Finds unregistered trademark numbers
	 * 
	 * @return ATMOSSData instance
	 */
	public ATMOSSDBManager getUnRegisteredTradeMarkID() {

		String statusCodes = "20, 21, 22, 24";

		String sQuery = "/*auto test data */\n";

		sQuery += "select tm.tm_number\n";
		sQuery += FROM_FALCON_TM_TRADEMARKS;
		sQuery += "where tm.lodgement_date < '10/Oct/2016'\n";
		sQuery += "AND tm.acceptance_due >= ADD_MONTHS(sysdate, -6)\n";
		sQuery += "AND tm.IR_NUMBER in (0)\n";
		sQuery += "AND tm.registered_from is null\n";
		sQuery += "AND tm.sealing_due >= sysdate\n";
		sQuery += "and tm.status in  (" + statusCodes + ")\n";
		sQuery += "order by sys.dbms_random.value\n";

		runQuery(sQuery);

		return this;
	}
}
