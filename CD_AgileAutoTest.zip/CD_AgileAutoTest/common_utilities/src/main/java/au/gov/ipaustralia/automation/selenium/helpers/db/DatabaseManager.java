package au.gov.ipaustralia.automation.selenium.helpers.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.log4j.Logger;

import au.gov.ipaustralia.selenium.environment.EnvironmentVariables;

/**
 * Provides connectivity, runs queries and manages results for databases
 * 
 * @author cpahan
 *
 */
public class DatabaseManager {

    private static final Logger LOGGER = Logger.getLogger(DatabaseManager.class);
    private static final String S_ORACLE_BASE = "jdbc:oracle:thin:";

    private String sOracleURI = "";
    private Connection connection = null;
    private ResultSet results = null;
    private Statement statement = null;
    /**
     * query result set
     */
    protected List<Map<String, Object>> data = null;

    /**
     * Constructor uses configuration utilities to build dB connection string and then get the connection
     * 
     * @param targetApplication
     *            ..
     */
    public DatabaseManager(String targetApplication) {
        String userName = EnvironmentVariables.getConfiguredItem(targetApplication, "database-user");
        String passWord = EnvironmentVariables.getConfiguredItem(targetApplication, "database-password");
        String hostName = EnvironmentVariables.getConfiguredItem(targetApplication, "database-host");
        String portNum = EnvironmentVariables.getConfiguredItem(targetApplication, "database-port");
        String sidNum = EnvironmentVariables.getConfiguredItem(targetApplication, "database-sid");
        sOracleURI = String.format("%s%s/%s@%s:%s:%s", S_ORACLE_BASE, userName, passWord, hostName, portNum, sidNum);

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            connection = DriverManager.getConnection(sOracleURI);
        }
        catch (SQLException ex) {
            String msgeOut = String.format("Db connection failed with %s. :: Connection string is [%s]",
                                           ex.getMessage(),
                                           sOracleURI);
            throw new DatabaseManagerException(msgeOut, ex);
        }
        catch (ClassNotFoundException e) {
            LOGGER.info("class not found", e);
        }
    }

    /**
     * executes a 'select' query <br>
     * populates the <code>data</code> field<br>
     * cleans up by closing the dB connection<br>
     * 
     * @param sql
     *            ..query string
     * @return DatabaseManager instance
     */
    public DatabaseManager runQuery(String sql) {

        try {
            ResultSetMetaData resultsMeta;
            Vector<Map<String, Object>> returnedRows = new Vector<Map<String, Object>>();
            statement = connection.createStatement();
            results = statement.executeQuery(sql);
            resultsMeta = results.getMetaData();
            int columnCount = resultsMeta.getColumnCount();
            if (resultsMeta.getColumnCount() == 0) {
                String msge = String.format("Query returned an empty result set. :: Query string is [%s]", sql);
                throw new DatabaseManagerException(msge);
            }
            while (results.next()) {
                HashMap<String, Object> rowMap = new HashMap<String, Object>();

                for (int i = 1; i <= columnCount; i++) {
                    String colName = resultsMeta.getColumnLabel(i);
                    Object item = results.getObject(i);
                    rowMap.put(colName, item);
                }
                returnedRows.add(rowMap);
            }
            /*
             *****************************************************
             * can add code here to filter out undesired results (known corrupt records, reserved data etc)
             * 
             ***************************************************** 
             */
            if (returnedRows.isEmpty()) {
                String msge = String.format("Query returned 0 rows. :: Query string is [%s]", sql);
                throw new DatabaseManagerException(msge);
            }
            this.data = returnedRows;
        }
        catch (SQLException e) {
            String msge = String.format("Run query failed with %s. :: Query string is [%s]", e.getMessage(), sql);
            throw new DatabaseManagerException(msge, e);
        }
        finally {
            this.closeConnection();
            try {
                if (results != null) results.close();
            }
            catch (Exception e) {
                LOGGER.info(e);
            }
            try {
                if (statement != null) statement.close();
            }
            catch (Exception e) {
                LOGGER.info(e);
            }
            try {
                if (connection != null) connection.close();
            }
            catch (Exception e) {
                LOGGER.info(e);
            }

        }
        return this;
    }

    /**
     * @return the test data key,value map
     */
    public List<Map<String, Object>> getData() {
        return data;
    }

    /**
     * @return the test data key,value map
     */
    public Object[][] getDataArray() {
        Object[][] dataArray = new Object[data.size()][1];
        int j = 0;
        for (Map<String, Object> row : this.data) {
            dataArray[j][0] = row;
            j++;
        }

        return dataArray;
    }

    /**
     * @return first row in the data map
     */
    public Map<String, Object> getFirstDataRow() {
        return data.get(0);
    }

    /**
     * @return the first item in the first row of the data map
     */
    public Object getFirstDataItem() {
        Map<String, Object> row = this.getFirstDataRow();
        return row.get(row.keySet().toArray()[0]);
    }

    /**
     * <p>
     * closes any connection used by the database object
     * </p>
     */
    public void closeConnection() {
        // close the connection if it exists
        try {
            if (this.connection != null && !this.connection.isClosed()) {

                this.connection.close();

            }
        }
        catch (Exception e) {
            LOGGER.info("Close connection", e);
        }
    }
}
