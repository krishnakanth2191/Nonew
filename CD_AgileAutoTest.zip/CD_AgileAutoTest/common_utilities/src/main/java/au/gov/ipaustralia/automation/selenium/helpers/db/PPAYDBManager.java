package au.gov.ipaustralia.automation.selenium.helpers.db;

/**
 * Interactions with the PAMS PPAY database
 * 
 * @author Jonathan Eastman
 *
 */
public class PPAYDBManager extends DatabaseManager {

    public PPAYDBManager() {
        super("DB_PPAY");

    }
    
    /**
     * Finds a valid ITP Number for payment
     * 
     * @return PPAYDBManager Instance
     */
    public PPAYDBManager getITPNumber() {

        String sQuery = "/*auto test data */\n";

        sQuery += "select ITP_NO\n";
        sQuery += "from PPAY_FINANCIAL_TRANSACTION t\n";
        sQuery += "where t.ITP_NO is not null\n";
        sQuery += "and Due_date > sysdate\n";
        sQuery += "and Due_date < add_months(sysdate, 36)\n";
        sQuery += "ORDER BY sys.dbms_random.value\n";

        runQuery(sQuery);

        return this;

    }

}
