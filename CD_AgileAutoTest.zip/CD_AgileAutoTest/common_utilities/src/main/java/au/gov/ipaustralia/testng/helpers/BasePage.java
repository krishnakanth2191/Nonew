package au.gov.ipaustralia.testng.helpers;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.jcabi.aspects.Loggable;

import au.gov.ipaustralia.selenium.environment.EnvironmentVariables;
import au.gov.ipaustralia.testng.listeners.ExtentManager;

/**
 * defines abstracts for a few things that all pages should have<br>
 * No real logic pragmatic collection of attributes and methods which are
 * convenient to use across all pages
 *
 * 
 * @author Anthony Hallett
 *
 */
@Loggable(prepend = true)
public class BasePage {

	private static final Logger LOGGER = Logger.getLogger(BasePage.class);
	/**
	 * test data key, value pair
	 */
	protected Map<String, String> data;

	/** driver for the target test browser */
	protected WebDriver driver;

	/** standard wait time for most time dependant functions */
	protected int timeout;
	String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
	String dest = "test-output"+File.separator+"ScreenShot"+ File.separator + timeStamp + ".png";

	/**
	 * Constructor
	 *
	 * 
	 * populates the environment specific timeout from Configuration
	 */
	public BasePage() {
		this.setTimeout(EnvironmentVariables.getGlobalTimeout());
	}

	// /**
	// * Constructor with driver
	// *
	// * @param driver
	// * the WebDriver
	// *
	// */
	public BasePage(final WebDriver driver) {
		this();
		this.driver = driver;
	}

	/**
	 * wraps the data <Map> getData method to provide consistent null and empty
	 * string handling
	 *
	 * @param key
	 * @return //
	 */

	protected String getDataValue(final String key) {
		if (!(this.getData() == null) && (this.getData().containsKey(key))) {
			final String value = this.getData().get(key).replaceAll("\\{blank\\}", (" "));
			return value;
		} else {
			return "";
		}
	}

	protected Object getDataValue(final Map<String, Object> source, final String key) {
		Object result = null;
		if (!(source == null) && (source.containsKey(key))) {
			result = source.get(key);
		}
		return result;
	}

	/**
	 * @return the test data key,value map
	 */

	public Map<String, String> getData() {
		return this.data;
	}

	/**
	 * test data key,value map
	 *
	 * @param data
	 *            the data map
	 * 
	 */

	public void setData(final Map<String, String> data) {
		this.data = data;
	}

	/**
	 *
	 * @return AUT timeout in seconds
	 */
	public int getTimeout() {
		return this.timeout;
	}

	/**
	 * Sets the AUT timeout value in seconds
	 *
	 * @param timeout
	 *            environment specific max wait time
	 * 
	 */
	@Loggable(prepend = true, value = Loggable.TRACE)
	public void setTimeout(final int timeout) {
		this.timeout = timeout;
	}

	/**
	 * @return the Selenium driver
	 */
	public WebDriver getDriver() {
		return this.driver;
	}

	/**
	 * sets the Selenium driver
	 * 
	 * @param driver
	 *            the WebDriver
	 * 
	 */
	public void setDriver(final WebDriver driver) {
		this.driver = driver;
	}

	/**
	 * @param pageUrl
	 *            the url string
	 * 
	 * @return true if AUT matches expected
	 */
	public boolean verifyPageUrl(final String pageUrl) {
		(new WebDriverWait(this.driver, this.timeout).ignoring(StaleElementReferenceException.class))
				.until(new ExpectedCondition<Boolean>() {
					@Override
					public Boolean apply(final WebDriver d) {
						final String actualUrl = d.getCurrentUrl();
						final Pattern p = Pattern.compile(pageUrl);
						final Matcher m = p.matcher(actualUrl);
						return m.find();
					}
				});
		return true;
	}

	/**
	 * This method will take screenshot get attached to the Log reports.
	 * 
	 * @param Webdriver,
	 *            Description of Case Step, FileNamme to be saved
	 */
	public void capture(WebDriver driver, String caseStep) {
		TakesScreenshot screen = (TakesScreenshot) driver;
		File src = screen.getScreenshotAs(OutputType.FILE);
		File target = new File(dest );
		try {
			ExtentTest test = ExtentManager.getInstance().getTest();
			FileUtils.copyFile(src, target);
//			test.log(Status.INFO, caseStep,
//					MediaEntityBuilder.createScreenCaptureFromPath("ScreenShot" + File.separator + fileName).build());
			test.log(Status.INFO, caseStep,
					MediaEntityBuilder.createScreenCaptureFromPath("ScreenShot"+ File.separator + timeStamp + ".png").build());
		} catch (IOException e) {
			LOGGER.info("IO Exception", e);

		}
	}
}
