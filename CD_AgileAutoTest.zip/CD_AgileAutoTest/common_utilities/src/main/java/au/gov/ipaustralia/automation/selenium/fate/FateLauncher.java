package au.gov.ipaustralia.automation.selenium.fate;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.eviware.soapui.SoapUI;
import com.smartbear.ready.cmd.runner.pro.SoapUIProTestCaseRunner;

public class FateLauncher {

    private static final Logger LOGGER = Logger.getLogger(FateLauncher.class);

    private static final String LOG4J_CONFIG =
            "<?xml version=\"1.0\" encoding=\"UTF-8\"?><!DOCTYPE log4j:configuration SYSTEM \"log4j.dtd\"><log4j:configuration xmlns:log4j=\"http://jakarta.apache.org/log4j/\" debug=\"false\">"
                    + " <appender name=\"console\" class=\"org.apache.log4j.ConsoleAppender\">"
                    + "   <layout class=\"org.apache.log4j.PatternLayout\">"
                    + "      <param name=\"ConversionPattern\" value=\"%d{yyyy-MM-dd HH:mm:ss} %-5p %c{1}:%L - %m%n\" />"
                    + "   </layout>"
                    + " </appender>"
                    + " <category name=\"hermes.impl.ConfigDAOImpl\" additivity=\"false\"><priority value=\"FATAL\" /></category>"
                    + " <category name=\"org.springframework.jdbc\" additivity=\"false\"><priority value=\"FATAL\" /></category>"
                    + " <category name=\"org.apache.commons.beanutils.converters\" additivity=\"false\"><priority value=\"FATAL\" /></category>"
                    + " <category name=\"liquibase\" additivity=\"false\"><priority value=\"FATAL\" /></category>"
                    + " <category name=\"org.hibernate\" additivity=\"false\"><priority value=\"FATAL\" /></category>"
                    + " <category name=\"com.netflix.governator\" additivity=\"false\"><priority value=\"FATAL\" /></category>"
                    + " <category name=\"com.eviware.soapui\" additivity=\"false\"><priority value=\"DEBUG\" /></category>"
                    + " <root><level value=\"INFO\"></level><appender-ref ref=\"console\" /></root>"
                    + "</log4j:configuration>";

    public static void main(final String[] args) throws Exception {

        FateLauncher.LOGGER.info("Starting SoapUI...");

        final ObjectInputStream objectInputStream = new ObjectInputStream(System.in);
        final String projectLocation = (String) objectInputStream.readObject();

        FateLauncher.LOGGER.info("Loading project [" + projectLocation + "].");

        final String testSuiteName = (String) objectInputStream.readObject();
        final String testCaseName = (String) objectInputStream.readObject();
        @SuppressWarnings("unchecked")
        final Map<String, String> properties = (Map<String, String>) objectInputStream.readObject();

        final Path logFile = Files.createTempFile("log4j", ".xml");
        FateLauncher.configureLogging(logFile);

        final Path tempFolder = Files.createTempDirectory("fate");

        try {

            final SoapUIProTestCaseRunner proTestCaseRunner = new SoapUIProTestCaseRunner();
            proTestCaseRunner.setEnableUI(false);
            proTestCaseRunner.setIgnoreErrors(false);
            proTestCaseRunner.setSaveAfterRun(false);
            proTestCaseRunner.setPrintReport(true);
            proTestCaseRunner.setOutputFolder(tempFolder.toAbsolutePath().toString());

            final String settingsFile = System.getProperty("settingsFile");
            if (StringUtils.isNotBlank(settingsFile)) {
                proTestCaseRunner.setSettingsFile(settingsFile);
            }

            proTestCaseRunner.setProjectFile(projectLocation);

            final List<String> params = new ArrayList<>();

            properties.forEach((key,
                                value) -> params.add(key + "=" + value));

            proTestCaseRunner.setProjectProperties(params.toArray(new String[params.size()]));

            proTestCaseRunner.setTestSuite(testSuiteName);

            proTestCaseRunner.setTestCase(testCaseName);

            proTestCaseRunner.setPrintReport(true);
            
            proTestCaseRunner.run();

            System.exit(0);
        }
        catch (final Exception e) {
            FateLauncher.LOGGER.error("Failed to run [" + testSuiteName + "]: [" + testCaseName + "].", e);
            System.exit(1);
        }
        finally {
            FileUtils.deleteQuietly(logFile.toFile());
            FileUtils.deleteDirectory(tempFolder.toFile());
            SoapUI.shutdown();
        }
    }

    private static void configureLogging(final Path logFile) throws IOException {
        System.setProperty("soapui.log4j.config", logFile.toString());
        FileUtils.write(logFile.toFile(), FateLauncher.LOG4J_CONFIG, Charset.defaultCharset());

        FateLauncher.LOGGER.info("Overwrote log4j config location to [" + logFile + "].");
    }

}
