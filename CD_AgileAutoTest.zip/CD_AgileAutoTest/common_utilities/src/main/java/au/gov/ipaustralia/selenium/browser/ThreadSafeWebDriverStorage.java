package au.gov.ipaustralia.selenium.browser;

import org.openqa.selenium.WebDriver;

import com.jcabi.aspects.Loggable;



@Loggable(prepend = true)
public class ThreadSafeWebDriverStorage {

	/**
	 * Thread local {@link WebDriver} instance so that we can run in
	 * multi-threaded mode.
	 */
	private static ThreadLocal<WebDriver> threadLocalDriver = new ThreadLocal<WebDriver>();

	public static WebDriver startWebDriver(String browserType, int timeout) {
		WebDriver driver = Browser.invokeBrowser(browserType, timeout);
		threadLocalDriver.set(driver);
		return driver;
	}
	
	public static void setWebDriver(WebDriver driver) {
		threadLocalDriver.set(driver);
	}
	
	public static void quitWebDriver(WebDriver driver) {
		if (driver != null) {
			WebDriver threadSafeDriver = ThreadSafeWebDriverStorage.getDriver();
			if (threadSafeDriver != driver) {
				throw new IllegalStateException("Asked to quit driver different to the thread local. Quitting: ["
						+ driver.toString() + "] ThreadSafeDriver: [" + threadSafeDriver + "]");
			}
		}
		quitWebDriver();
	}

	public static void quitWebDriver() {
		WebDriver driver = threadLocalDriver.get();
		if (driver != null) {
			driver.quit();
		}
		threadLocalDriver.set(null);
	}

	public static WebDriver getDriver() {
		return threadLocalDriver.get();
	}
}
