package au.gov.ipaustralia.testng.helpers;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

import org.testng.IAnnotationTransformer;
import org.testng.annotations.ITestAnnotation;

import au.gov.ipaustralia.selenium.environment.EnvironmentVariables;

/**
 *
 * @author bimans
 *
 */
public class IPATestNGAnnotationTransformer implements IAnnotationTransformer {
	public static final int REPETITION_COUNT = -1;
	public static final int THREAD_POOL_SIZE = -1;

	@Override
	public void transform(final ITestAnnotation annotation, final Class testClass, final Constructor testConstructor,
			final Method testMethod) {

		if (annotation.getInvocationCount() == IPATestNGAnnotationTransformer.REPETITION_COUNT) {
			annotation.setInvocationCount(EnvironmentVariables.getRepetitions());
		}

		if (annotation.getThreadPoolSize() == IPATestNGAnnotationTransformer.THREAD_POOL_SIZE) {
			annotation.setInvocationCount(EnvironmentVariables.getThreadPoolSize());
		}
	}

}
