package au.gov.ipaustralia.automation.selenium.fate;

import java.util.Collections;
import java.util.Map;

import com.google.api.client.repackaged.com.google.common.base.Objects;

/**
 * Wrapper around data provided by FATE.
 *
 * Provides consistent access to the data.
 */
public class FateData {

    private final Map<String, String> data;

    private final String xml;

    public FateData(final Map<String, String> data) {
        this(data, null);
    }

    public FateData(final Map<String, String> data, final String xml) {
        super();
        this.data = data;
        this.xml = xml;
    }

    public Map<String, String> getData() {
        return Collections.unmodifiableMap(this.data);
    }

    public String getIpRightNumber() {
        return Objects.firstNonNull(this.data.get("IPNUMBER"), this.data.get("IPRIGHTNUMBER"));
    }

    public String getBatchId() {
        return this.data.get("BATCHID");
    }
    
    public String getDatePaidUntil() {
        return this.data.get("DATEPAIDUNTIL");
    }

    public String getServiceRequestId() {
        return this.data.get("SRID");
    }

    public String getSrType() {
        return this.data.get("TYPE");
    }

    public String getSrCode() {
        return this.data.get("SRCODE");
    }

    public String getXml() {
        return this.xml;
    }

    public FateData withProperty(final String key, final String value) {
        this.data.put(key, value);
        return new FateData(this.data, this.xml);
    }

    public FateData with(final FateData other) {
        this.data.putAll(other.data);
        return new FateData(this.data, this.xml == null ? other.xml : this.xml);
    }

    @Override
    public String toString() {
        return "FateData [data=" + this.data + "]";
    }
}
