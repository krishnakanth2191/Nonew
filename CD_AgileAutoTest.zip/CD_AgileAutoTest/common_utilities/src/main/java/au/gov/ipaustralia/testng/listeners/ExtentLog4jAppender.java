package au.gov.ipaustralia.testng.listeners;

import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.Layout;
import org.apache.log4j.Level;
import org.apache.log4j.spi.LoggingEvent;

import com.aventstack.extentreports.ExtentTest;

public class ExtentLog4jAppender extends AppenderSkeleton {

	@Override
	public void close() {
		// Nothing to be done.
	}

	@Override
	public boolean requiresLayout() {
		return true;
	}

	@Override
	protected void append(LoggingEvent event) {
		final String string = this.eventToString(event);

		ExtentTest test = ExtentManager.getInstance().getTest();
		if (test == null) {
			test = ExtentManager.getInstance().getParentTest();
		}

		if (test != null) {
			final Level level = event.getLevel();
			if (Level.TRACE.equals(level)) {
				test.debug(string);
			} else if (Level.DEBUG.equals(level)) {
				test.debug(string);
			} else if (Level.INFO.equals(level)) {
				test.info(string);
			} else if (Level.WARN.equals(level)) {
				test.warning(string);
			} else if (Level.ERROR.equals(level)) {
				test.error(string);
			} else if (Level.FATAL.equals(level)) {
				test.fatal(string);
			}
		}

	}

	private String eventToString(final LoggingEvent event) {
		final StringBuilder result = new StringBuilder(this.layout.format(event));

		if (this.layout.ignoresThrowable()) {
			final String[] s = event.getThrowableStrRep();
			if (s != null) {
				for (final String value : s) {
					result.append(value).append(Layout.LINE_SEP);
				}
			}
		}
		return result.toString();
	}

}
