package au.gov.ipaustralia.automation.selenium.fate;

import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.eviware.soapui.SoapUI;
import com.opencsv.CSVReader;
import com.smartbear.ready.cmd.runner.pro.SoapUIProTestCaseRunner;

/**
 * Uses FATE to generate cases / IP rights for consumption by test cases.
 *
 * Can generate more than one IP right.
 *
 * @note FATE and ReadyAPI must be installed.
 */
public class FateDataProvider {

    private static final Logger LOGGER = Logger.getLogger(FateDataProvider.class);

    /** Location where FATE (not SoapUI / ReadyAPI) has been installed. */
    private static final String PROJECT_LOCATION = System.getProperty("fatedatagen.home");

    /** Properties and default values. */
    private static final Map<String, String> PROJECT_PROPERTIES = new HashMap<>();

    /** Name of FATE property that disables validation. */
    private static final String SKIP_VALIDATION_LOOP_PROPERTY = "SKIP_VALIDATION_LOOP";

    private static final String FAIL_ON_VALIDATION_PROPERTY = "FAIL_WHEN_VALIDATION_ERROR";

    static {
        FateDataProvider.PROJECT_PROPERTIES.put("CMIS_TARGET_HOST", "srg-training.aipo.gov.au:80");
        FateDataProvider.PROJECT_PROPERTIES.put("RIO_CONN_QUEUE_NAME", "au.gov.ipaustralia.rio.connector.request");
        FateDataProvider.PROJECT_PROPERTIES.put("HERMES_EMS_SESSION", "RIO-TRAINING-16-EMS");
        FateDataProvider.PROJECT_PROPERTIES.put("DP_URL", "gadgetx-dr-riotraining:10060");

        FateDataProvider.PROJECT_PROPERTIES.put("STS_URL",
                                                "http://support-test-openam-vip.aipo.gov.au:8080/opensso/sts/soap11");
        FateDataProvider.PROJECT_PROPERTIES.put("CMIS_TARGET_HOST", "srg-rio-training.aipo.gov.au");

        FateDataProvider.PROJECT_PROPERTIES.put("RIO_IPRDB_HOST", "rio-training-16-rio-oracle");
        FateDataProvider.PROJECT_PROPERTIES.put("RIO_IPRDB_PORT", "1524");
        FateDataProvider.PROJECT_PROPERTIES.put("RIO_IPRDB_USERNAME", "auto_test");
        FateDataProvider.PROJECT_PROPERTIES.put("RIO_IPRDB_PASSWORD", "automagic");
        FateDataProvider.PROJECT_PROPERTIES.put("RIO_IPRDB_SID", "iprds");

        FateDataProvider.PROJECT_PROPERTIES.put("DBHOST", "rio-training-16-rio-oracle");
        FateDataProvider.PROJECT_PROPERTIES.put("DBPORT", "1524");
        FateDataProvider.PROJECT_PROPERTIES.put("DBUSERNAME", "auto_test");
        FateDataProvider.PROJECT_PROPERTIES.put("DBPASSWORD", "automagic");
        FateDataProvider.PROJECT_PROPERTIES.put("DBSID", "case");

        FateDataProvider.PROJECT_PROPERTIES.put("WSS_USER_DISTINGUISHED_NAME",
                                                "id=csbcal,ou=user,o=IPA_INTERNAL,ou=services,dc=opensso,dc=java,dc=net");
        FateDataProvider.PROJECT_PROPERTIES.put("SR_CODES", "");
        FateDataProvider.PROJECT_PROPERTIES.put(FateDataProvider.SKIP_VALIDATION_LOOP_PROPERTY, "YES");
        FateDataProvider.PROJECT_PROPERTIES.put(FateDataProvider.FAIL_ON_VALIDATION_PROPERTY, "true");

        FateDataProvider.PROJECT_PROPERTIES.put("KEYSTORE", null);

        FateDataProvider.PROJECT_PROPERTIES.put("QUANTITY", "1");
        FateDataProvider.PROJECT_PROPERTIES.put("MaxDBPollingTime", "600000");

        FateDataProvider.PROJECT_PROPERTIES.put("DOCS_FOLDER_PATH",
                                                FateDataProvider.PROJECT_LOCATION + "/Document_Samples");

        FateDataProvider.PROJECT_PROPERTIES.put("DATASOURCE_FOLDER_PATH",
                                                FateDataProvider.PROJECT_LOCATION + "/DataSource");


        FateDataProvider.PROJECT_PROPERTIES.put("HermesConfigPath", FateDataProvider.PROJECT_LOCATION + "/.hermes");
        
        FateDataProvider.PROJECT_PROPERTIES.put("XML_INPUT_FOLDER_PATH", "");
    }

    private static final String LOG4J_CONFIG =
            "<?xml version=\"1.0\" encoding=\"UTF-8\"?><!DOCTYPE log4j:configuration SYSTEM \"log4j.dtd\"><log4j:configuration xmlns:log4j=\"http://jakarta.apache.org/log4j/\" debug=\"false\"></log4j:configuration>";

    /** Name of suite that will be run to generate the data. E.g. DesignsTestDataGenerator */
    private final String suiteName;

    /** Name of the case that will be run to generate the data. e.g. RandomDesignRequestsWithNewAppData_FRE */
    private final String caseName;

    /**
     * Actual properties that will be used generate the data. Normally a combination of defaults (provided by system
     * properties) and overrides.
     */
    private final Map<String, String> properties = new HashMap<>();

    public FateDataProvider(final String suiteName, final String caseName) {
        this.suiteName = suiteName;
        this.caseName = caseName;
    }

    public FateDataProvider withProperty(final String key,
                                         final String... values) {
        this.properties.put(key, StringUtils.join(values, ","));
        return this;
    }

    public FateDataProvider repeat(final int times) {
        return this.withProperty("QUANTITY", Integer.toString(times));
    }

    public FateDataProvider doNotValidate() {
        return this.withProperty(FateDataProvider.SKIP_VALIDATION_LOOP_PROPERTY, "YES");
    }

    public FateDataProvider validate() {
        return this.withProperty(FateDataProvider.SKIP_VALIDATION_LOOP_PROPERTY, "false").withProperty(FateDataProvider.FAIL_ON_VALIDATION_PROPERTY, "true");
    }

    public Iterator<Object[]> data() throws Exception {

        final Path dataFile = Files.createTempFile("data", ".csv");

        final Path excelFile = Files.createTempFile("data", ".xls");

        final Path logFile = Files.createTempFile("log4j", ".xml");
        System.setProperty("soapui.log4j.config", logFile.toString());
        FileUtils.write(logFile.toFile(), FateDataProvider.LOG4J_CONFIG, Charset.defaultCharset());

        FateDataProvider.LOGGER.info("Overwrote log4j config location to [" + logFile + "].");

        final Path tempFolder = Files.createTempDirectory("fate");

        try {
            final SoapUIProTestCaseRunner proTestCaseRunner = new SoapUIProTestCaseRunner();
            proTestCaseRunner.setEnableUI(false);
            proTestCaseRunner.setIgnoreErrors(false);
            proTestCaseRunner.setSaveAfterRun(false);
            proTestCaseRunner.setPrintReport(true);
            proTestCaseRunner.setOutputFolder(tempFolder.toAbsolutePath().toString());

            final String settingsFile = System.getProperty("settingsFile");
            if (StringUtils.isNotBlank(settingsFile)) {
                proTestCaseRunner.setSettingsFile(settingsFile);
            }

            proTestCaseRunner.setProjectFile(FateDataProvider.PROJECT_LOCATION
                    + "/src/test/resources/RIO_TestDataGenerator.xml");

            final List<String> params = new ArrayList<>();

            // Add the normal properties, using either the system property or the default
            FateDataProvider.PROJECT_PROPERTIES.forEach((key,
                                                         defaultValue) -> {
                final String value = System.getProperty(key, defaultValue);
                if (value != null) {
                    params.add(key + "=" + value);
                }
            });

            // Override with specific values.
            this.properties.forEach((key,
                                     value) -> params.add(key + "=" + value));

            params.add("OUTPUT_FINAL_FILEPATH=" + dataFile.toAbsolutePath().toString());
            params.add("OUTPUT_EXCEL_FILEPATH=" + excelFile.toAbsolutePath().toString());

            proTestCaseRunner.setProjectProperties(params.toArray(new String[params.size()]));

            proTestCaseRunner.setTestSuite(this.suiteName);

            proTestCaseRunner.setTestCase(this.caseName);

            proTestCaseRunner.run();

            final List<FateData> fateData = FateDataProvider.readGeneratedCsvOutput(dataFile);

            final Map<String, List<FateData>> ipRightUniqueData =
                    fateData.stream().collect(Collectors.groupingBy(FateData::getIpRightNumber));

            return ipRightUniqueData.entrySet().stream().map(entry -> new Object[] {
                    entry.getValue().get(0) }).iterator();
        }
        finally {
            FileUtils.deleteQuietly(dataFile.toFile());
            FileUtils.deleteQuietly(excelFile.toFile());
            FileUtils.deleteDirectory(tempFolder.toFile());
            SoapUI.shutdown();
        }
    }

    /**
     * Reads CSV content from file, packing each row into an Object[] that contains a FateData instance.
     *
     * The Object[] wrapper is used for compatibility with TestNG DataProviders.
     */
    private static List<FateData> readGeneratedCsvOutput(final Path dataFile) throws IOException {
        FateDataProvider.LOGGER.debug("Reading data from [" + dataFile + "]...");

        final List<FateData> fateData = new ArrayList<>();

        try (FileReader fileReader = new FileReader(dataFile.toFile())) {

            try (CSVReader cs = new CSVReader(fileReader)) {
                final String[] headings = cs.readNext();

                FateDataProvider.LOGGER.debug("Headings [" + StringUtils.join(headings) + "]");

                int rowNumber = 0;
                String[] nextLine;

                while ((nextLine = cs.readNext()) != null) {

                    final Map<String, String> rowData = new HashMap<>();

                    for (int i = 0; i < nextLine.length; i++) {
                        rowData.put(headings[i], nextLine[i]);
                    }

                    rowData.put("rownumber", Integer.toString(rowNumber));

                    FateDataProvider.LOGGER.debug("Row [" + rowData + "]");

                    fateData.add(new FateData(rowData, null));

                    rowNumber++;
                }
            }
        }

        FateDataProvider.LOGGER.debug("Read [" + fateData.size() + "] from [" + dataFile + "].");

        return fateData;
    }

}
