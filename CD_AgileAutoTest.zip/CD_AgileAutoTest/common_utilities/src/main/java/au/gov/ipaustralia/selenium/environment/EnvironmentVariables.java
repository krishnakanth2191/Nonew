package au.gov.ipaustralia.selenium.environment;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.DumperOptions.FlowStyle;
import org.yaml.snakeyaml.DumperOptions.ScalarStyle;
import org.yaml.snakeyaml.Yaml;

/**
 * Utilities to use the properties.yaml
 *
 * @author cpahan
 *
 */
public final class EnvironmentVariables {

	private static final Logger LOGGER = Logger.getLogger(EnvironmentVariables.class);

	private static final String DEFAULT_PROPERTY_FILE_NAME = "/properties.yaml";

	private static final int TIME_OUT = Integer.parseInt(System.getProperty("to"));

	private static final String ENVIRONMENT = System.getProperty("env");

	private static final String BROWSER_TYPE = System.getProperty("brw");

	private static final Integer THREAD_POOL_SIZE = Integer.parseInt(System.getProperty("threadPoolSize", "5"));

	private static final Integer REPETITIONS = Integer.parseInt(System.getProperty("repetitions", "10"));

	private static final String JOB_NAME = System.getenv("JOB_BASE_NAME");

	private static final String BUILD_NUMBER = System.getenv("BUILD_NUMBER");

	private static final String BUILD_TAG = System.getenv("BUILD_TAG");

	private static final Map<String, Object> CONFIGURATION;

	private EnvironmentVariables() {
		throw new IllegalStateException("EnvironmentVariables class");
	}

	static {
		final Map<String, Object> fullConfiguration = EnvironmentVariables.loadYaml();
		LOGGER.debug(fullConfiguration);
		@SuppressWarnings("unchecked")
		Map<String, Object> environmentConfiguration = (Map<String, Object>) fullConfiguration
				.get(EnvironmentVariables.ENVIRONMENT);
		if (environmentConfiguration == null) {
			environmentConfiguration = Collections.emptyMap();
		}

		CONFIGURATION = Collections.unmodifiableMap(environmentConfiguration);
	}

	@SuppressWarnings("unchecked")
	private static Map<String, Object> loadYaml() {
		final DumperOptions options = new DumperOptions();
		options.setDefaultFlowStyle(FlowStyle.BLOCK);
		options.setDefaultScalarStyle(ScalarStyle.PLAIN);
		final Yaml yaml = new Yaml(options);
		Map<String, Object> map = Collections.emptyMap();

		try {
			try (InputStream inputStream = EnvironmentVariables.class.getResourceAsStream(DEFAULT_PROPERTY_FILE_NAME)) {
				map = (Map<String, Object>) yaml.load(inputStream);
			}
		} catch (final FileNotFoundException e) {
			EnvironmentVariables.LOGGER
					.warn("File [" + DEFAULT_PROPERTY_FILE_NAME + "] not found, will read from system properties.");
		} catch (final IOException e) {
			EnvironmentVariables.LOGGER.warn("Error reading configuration from [" + DEFAULT_PROPERTY_FILE_NAME + "].",
					e);
		}
		return map;
	}

	/**
	 * If getProperty value is null, return .yaml values otherwise return VM
	 * arguments values
	 *
	 * @param applicationUnderTest
	 *            application under test
	 * @param itemKey
	 *            key word (in yaml file)
	 *
	 * @return value associated with itemKey
	 * @author bimord
	 */
	@SuppressWarnings("unchecked")
	public static String getConfiguredItem(final String applicationUnderTest, final String itemKey) {
		String item = "";
		try {
			final String propertyName = EnvironmentVariables.propertyName(applicationUnderTest, itemKey);
			item = System.getProperty(propertyName);
			if (item == null) {
				final Map<String, Object> autLevel = (Map<String, Object>) EnvironmentVariables.CONFIGURATION
						.get(applicationUnderTest);
				item = autLevel.get(itemKey).toString();
			} else {
				EnvironmentVariables.LOGGER.info(String.format("Loaded [%s] [%s] with system property [%s] - [%s].",
						applicationUnderTest, itemKey, propertyName, item));
			}

		} catch (final NullPointerException e) {
			EnvironmentVariables.LOGGER.info("Key: " + itemKey);
			EnvironmentVariables.LOGGER.info("Application under test: " + applicationUnderTest);
			EnvironmentVariables.LOGGER.info("aut level: " + EnvironmentVariables.CONFIGURATION);
			LOGGER.info("Variables not found", e);
		}
		return item;
	}

	/**
	 *
	 * @param File is given to the method with needs to exits in FileName testFolder
	 * 
	 * This method with copy give @pram resource from testdata folder to temp resource
	 * 
	 * This temp folder needs to be get deleted using file delete method
	 *        
	 * @return file path based if it exits in resource folder 
	 * 
	 */
	public static String getTestDataFolder(String fileName) {
		URL inputUrl = EnvironmentVariables.class.getResource("/testData/" + fileName);
		LOGGER.info("File Path Found" + inputUrl);

		Path tempFolder = null;

		try {
			tempFolder = Files.createTempDirectory("resources");
			File dest = new File(tempFolder.toString(), fileName);
			FileUtils.copyURLToFile(inputUrl, dest);

			LOGGER.info("Final desitanation path" + dest);
			if (dest.exists()) {
				LOGGER.info("File Exists");
			}
			return (dest.getAbsolutePath());

		} catch (IOException e) {
			LOGGER.info("File Not foundException", e);

		}
		return fileName;

	}
	
	/**
	 *
	 * @param File is given to the method with needs to exits in FileName testFolder
	 *
	 * This temp folder needs to be get deleted using file delete method
	 *        
	 * @return file path based if it exits in resource folder 
	 * 
	 */
	public static String getResourcesTestDataFolder(String fileName) {

		final String testDataFolder = "testdata-folder";

		final String testDataOverride = System.getProperty("override." + testDataFolder);

		// Allow overriding of test data from system properties
		if (StringUtils.isNotBlank(testDataOverride)) {
			return (testDataOverride + fileName);
		} else {
			return (getTestDataFolder(fileName));
		}

	}
	
	/**
	*@param File is given to the method with needs to exits in FileName testFolder
	* 
	* This will delete file that have been used in the fileName
	*
	 */
	public static void fileDelete(String finalPath) {
		Path path = Paths.get(finalPath);
		try {
			FileUtils.forceDeleteOnExit(path.toFile());
		} catch (IOException e) {
			LOGGER.info("file not deleted", e);
		}
	}

	/**
	 * @param applicationUnderTest
	 * @param itemKey
	 *            to override .yaml file
	 *
	 * @return target propertyName with override itemKey
	 * @author bimord
	 */
	private static String propertyName(final String applicationUnderTest, final String itemKey) {
		return applicationUnderTest + "_" + itemKey;
	}

	/**
	 * @return target environment name
	 */
	public static String getEnvironmentName() {
		return EnvironmentVariables.ENVIRONMENT;
	}

	/**
	 * @return maximum wait time (seconds)
	 */
	public static int getGlobalTimeout() {
		return EnvironmentVariables.TIME_OUT;
	}

	public static String getBrowserType() {
		return EnvironmentVariables.BROWSER_TYPE;
	}

	public static int getRepetitions() {
		return EnvironmentVariables.REPETITIONS;
	}

	public static int getThreadPoolSize() {
		return EnvironmentVariables.THREAD_POOL_SIZE;
	}

	public static String getJobName() {
		return JOB_NAME;
	}

	public static String getBuildNumber() {
		return BUILD_NUMBER;
	}

	public static String getBuildTag() {
		return BUILD_TAG;
	}

	/**
	 * @return flag to assert / not assert
	 */
	public static boolean runAssertions() {
		return true;
	}

}
