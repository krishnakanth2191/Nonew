package au.gov.ipaustralia.testng.listeners;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentTest;

public class ExtentTestNGITestListener implements ITestListener {

    private static ExtentManager extentManager = ExtentManager.getInstance();

    @Override
    public synchronized void onStart(final ITestContext context) {
        final ExtentTest parent = ExtentTestNGITestListener.extentManager.createTest(context.getName());
        ExtentTestNGITestListener.extentManager.setParent(parent);
    }

    @Override
    public synchronized void onFinish(final ITestContext context) {
        ExtentTestNGITestListener.extentManager.flush();
    }

    @Override
    public synchronized void onTestStart(final ITestResult result) {
        ExtentTest parentTest = ExtentTestNGITestListener.extentManager.getParentTest();

        final String name = result.getTestContext().getSuite().getName();

        if (parentTest == null || !parentTest.getModel().getName().equals(name)) {
            parentTest = ExtentTestNGITestListener.extentManager.createTest(name);
            ExtentTestNGITestListener.extentManager.setParent(parentTest);
        }

        final ExtentTest child = parentTest.createNode(result.getName(), result.getMethod().getMethodName());
        ExtentTestNGITestListener.extentManager.setTest(child);
    }

    @Override
    public synchronized void onTestSuccess(final ITestResult result) {
        ExtentTestNGITestListener.extentManager.getTest().pass("Test passed");
    }

    @Override
    public synchronized void onTestFailure(final ITestResult result) {
        if (ExtentTestNGITestListener.extentManager != null && ExtentTestNGITestListener.extentManager.getTest() != null && result != null) {
            ExtentTestNGITestListener.extentManager.getTest().fail(result.getThrowable());
        }
    }

    @Override
    public synchronized void onTestSkipped(final ITestResult result) {
        if (ExtentTestNGITestListener.extentManager != null && ExtentTestNGITestListener.extentManager.getTest() != null && result != null) {
            ExtentTestNGITestListener.extentManager.getTest().skip(result.getThrowable());
        }
    }

    @Override
    public synchronized void onTestFailedButWithinSuccessPercentage(final ITestResult result) {
    		// Do Nothing
    }

}
