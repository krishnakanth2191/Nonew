package au.gov.ipaustralia.selenium.browser;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.jcabi.aspects.LogExceptions;
import com.jcabi.aspects.Loggable;

import au.gov.ipaustralia.selenium.environment.EnvironmentVariables;
import au.gov.ipaustralia.testng.helpers.TestMethodCapture;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

@Loggable(prepend = true, value = Loggable.DEBUG)
public class Browser {

	private static final Logger LOGGER = Logger.getLogger(Browser.class);

	/** Maximum length of cookie values. */
	private static final int MAX_COOKIE_VALUE_LENGTH = 80;

	private Browser() {
		throw new IllegalStateException("Browser class");
	}

	@LogExceptions
	public static WebDriver invokeBrowser(final String browserName, final int timeout) {

		WebDriver driver = null;

		if ("Mozila".equalsIgnoreCase(browserName) || "Firefox".equalsIgnoreCase(browserName)) {
			 driver = new FirefoxDriver();
		     driver.manage().window().maximize();
		} else if ("Chrome".equalsIgnoreCase(browserName)) {
			try {
				Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe");
			} catch (final IOException e) {
				LOGGER.warn("Task Kill Not Found", e);

			}
			Browser.killOrphanServerInstances("chrome");

			driver = new ChromeDriver();
		    driver.manage().window().maximize();
		} else if ("RemoteChrome".equalsIgnoreCase(browserName)) {
			URL remoteUrl;
			try {
				remoteUrl = new URL(System.getProperty("remotewebdriver.url"));
			} catch (final MalformedURLException e) {
				throw new NullPointerException();
			}
			final DesiredCapabilities desiredCapabilities = DesiredCapabilities.chrome();

			// Set the language to en_GB, this helps date formatting (en_AU
			// can't be set this way)
			ChromeOptions options = new ChromeOptions();
			options.addArguments("lang=en_GB");
			desiredCapabilities.setCapability(ChromeOptions.CAPABILITY, options);

			String recordVideoStr = System.getProperty("recordVideo", "true");
			if (recordVideoStr != null) {
				Boolean recordVideo = Boolean.valueOf(recordVideoStr);
				desiredCapabilities.setCapability("recordVideo", recordVideo);
			}

			Browser.configureProxy(desiredCapabilities);

			Browser.addTestName(desiredCapabilities);
			Browser.addBuildTag(desiredCapabilities);
			driver = new RemoteWebDriver(remoteUrl, desiredCapabilities);
		    driver.manage().window().maximize();

		}else if ("AndriodMobileBrowser".equalsIgnoreCase(browserName)) {
            URL remoteUrl;
            try {
                remoteUrl = new URL(System.getProperty("remotewebdriver.url"));
            } catch (final MalformedURLException e) {
                throw new NullPointerException();
            }
            DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
            
            desiredCapabilities.setCapability("testobject_api_key", System.getProperty("TESTOBJECT_API_KEY"));
            desiredCapabilities.setCapability("testobject_project", System.getProperty("TESTOBJECT_PROJECT"));
            desiredCapabilities.setCapability("testobject_app_id", System.getProperty("TESTOBJECT_APP_ID"));
            desiredCapabilities.setCapability("testobject_device", System.getProperty("TESTOBJECT_DEVICE"));     

       
            driver = new AndroidDriver<MobileElement>(remoteUrl, desiredCapabilities);
            
            
		} else {
			Browser.killOrphanServerInstances("IEDriverServer");
			// Else IE will run
			System.getProperty("webdriver.ie.driver", ("user.dir") + File.separator + "IEDriverServer.exe");
			final DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
			caps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			driver = new InternetExplorerDriver(caps);
		    driver.manage().window().maximize();
		}



		ThreadSafeWebDriverStorage.setWebDriver(driver);
		return driver;
	}

	/**
	 * Adds synthetic cookies to the test session that can be used to identify
	 * test artefacts in other systems (e.g. Zalenium).
	 */
	public static void addSyntheticCookies(WebDriver driver) {
		try {
			driver.manage().addCookie(new Cookie("syntheticTestId", StringUtils
					.abbreviateMiddle(TestMethodCapture.getTestDescription(), "...", MAX_COOKIE_VALUE_LENGTH)));
			if (StringUtils.isNotBlank(EnvironmentVariables.getJobName())) {
				driver.manage().addCookie(new Cookie("syntheticTestJobName", StringUtils
						.abbreviateMiddle(EnvironmentVariables.getJobName(), "...", MAX_COOKIE_VALUE_LENGTH)));
			}
			if (StringUtils.isNotBlank(EnvironmentVariables.getBuildNumber())) {
				driver.manage().addCookie(new Cookie("syntheticTestBuildNumber", StringUtils
						.abbreviateMiddle(EnvironmentVariables.getBuildNumber(), "...", MAX_COOKIE_VALUE_LENGTH)));
			}
		} catch (Exception e) {
			LOGGER.warn("Failed to add synthetic cookies to driver session.", e);
		}
	}

	private static void configureProxy(final DesiredCapabilities desiredCapabilities) {
		final String proxyVar = System.getProperty("selenium.proxy.autoconfiguration");
		if (proxyVar != null) {
			final Proxy proxy = new Proxy();
			proxy.setProxyAutoconfigUrl(proxyVar);
			desiredCapabilities.setCapability(CapabilityType.PROXY, proxy);
			desiredCapabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		}
	}

	private static void addTestName(final DesiredCapabilities desiredCapabilities) {
		String testName = TestMethodCapture.getTestDescription();
		// Zalenium uses the test name for a file name, so it needs to be
		// shorter than 255, lets leave ourselves a little breathing room.
		testName = testName.replaceAll("[^a-zA-Z0-9-_\\.]", "_");
		testName = StringUtils.abbreviate(testName, 120);
		desiredCapabilities.setCapability("name", testName);

	}

	private static void addBuildTag(final DesiredCapabilities desiredCapabilities) {
		String jenkinsBuildTag = EnvironmentVariables.getBuildTag();
		if (jenkinsBuildTag != null) {
			desiredCapabilities.setCapability("build", jenkinsBuildTag);
		}

	}

	private static void killOrphanServerInstances(final String exeName) {
		try {
			final String taskStr = "tasklist.exe /FO csv /NH /FI \"STATUS eq running\" " + "/FI \"IMAGENAME eq "
					+ exeName + ".exe\" " + "/v";
			final Process p = Runtime.getRuntime().exec(taskStr);
			final BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String line;
			while ((line = input.readLine()) != null) {
				if (!line.equals("INFO: No tasks are running which match the specified criteria.")) {
					final String[] taskDetails = line.split(",");
					Runtime.getRuntime().exec("C:/WINDOWS/system32/taskkill.exe /PID " + taskDetails[1] + " /T /F");
				}
			}
		} catch (final IOException e) {
			LOGGER.warn("killOrphanServerInstances", e);

		}

	}
}
