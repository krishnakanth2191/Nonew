package au.gov.ipaustralia.automation.selenium.helpers.db;

/**
 * Provides an unchecked runtime wrapper for data base exceptions
 * 
 * @author cpahan
 *
 */
public class DatabaseManagerException extends RuntimeException {
	/** Serial id number */
	static final long serialVersionUID = 1;

	/**
	 * Constructor for a handled problem.<br>
	 * 
	 * @param sNewMesage text
	 */
	public DatabaseManagerException(String sNewMesage) {
		super(sNewMesage, null);
	}

	/**
	 * Constructor which adds more information to a caught exception.<br>
	 * 
	 * @param sNewMesage text
	 * @param eCaughtException caught exception
	 */
	public DatabaseManagerException(String sNewMesage, Throwable eCaughtException) {
		super(sNewMesage, eCaughtException);
	}

	/**
	 * Constructor which simply wraps the passed in Exception<br>
	 * 
	 * @param eCaughtException caught exception
	 */
	public DatabaseManagerException(Throwable eCaughtException) {
		super(eCaughtException);
	}

}
