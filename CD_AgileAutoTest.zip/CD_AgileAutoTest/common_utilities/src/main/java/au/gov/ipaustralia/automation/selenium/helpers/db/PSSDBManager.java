package au.gov.ipaustralia.automation.selenium.helpers.db;

/**
 * Interactions with the PSS  database
 * 
 * @author SThumma
 *
 */
public class PSSDBManager extends DatabaseManager {

    public PSSDBManager() {
        super("DB_Pss");

    }

    /**
     * This method is run Query to retrieve 'Application number' from 'pss.PSS_DELTA_RECORDS' table 
     * 
     * @return getPSSDeltaRecord
     *
     */
    
    public PSSDBManager getPSSDeltaRecord() {

        String sQuery = "/*auto test data */\n";

        sQuery += "select ad.australian_appl_no\n";
        sQuery += "from pss.PSS_DELTA_RUNS dr, pss.PSS_DELTA_RECORDS d, pss.pss_application_dates ad,\n";
        sQuery += "pss.pss_application_details dd\n";
        sQuery += "where dr.delta_run_id = d.delta_run_id\n";
        sQuery += "and ad.australian_appl_no = d.australian_appl_no\n";
        sQuery += "and dd.australian_appl_no = d.australian_appl_no\n";
        sQuery += "and ad.opi_date is not null\n";
        sQuery += "and d.delta_type = 'ADD'\n";
        sQuery += "and dr.start_timestamp > sysdate -1;\n";
        runQuery(sQuery);

        return this;

    }


}
