package au.gov.ipaustralia.automation.selenium.helpers.db;

/**
 * Interactions with the PAMS  database
 * 
 * @author cpahan
 *
 */
public class PAMSDBManager extends DatabaseManager {

    public PAMSDBManager() {
        super("DB_Pams");

    }

    public PAMSDBManager getPatentId() {

        String sQuery = "/*auto test data */\n";

        sQuery += "select f.au_australian_appl_number\n";
        sQuery += "from pams.pams_files f\n";
        sQuery += "where f.au_patent_status_id = 18\n";
        sQuery += "and f.au_patent_type_id = 4\n";
        sQuery += "and f.au_pct_application_no is null\n";
        sQuery += "and f.au_wipo_number is null\n";
        sQuery += "and f.au_in_force_date > sysdate\n";
        sQuery += "and f.au_secrecy_required_ind = 'N'\n";
        sQuery += "and f.au_under_opposition_ind = 'N'\n";
        sQuery += "and f.au_filing_date >= '16-Apr-2013\n'";
        sQuery += "and f.au_direction_exam_request_date is null\n";
        sQuery += "ORDER BY sys.dbms_random.value\n";

        runQuery(sQuery);

        return this;

    }

    public PAMSDBManager getPatentForRenewal() {
        String sQuery = "/*auto test data */\n";

        sQuery += "select f.au_australian_appl_number \n";
        sQuery += "from pams.pams_files f \n";
        sQuery += "where f.au_patent_status_id = 18 \n";
        sQuery += "and f.au_patent_type_id = 4 \n";
        sQuery += "and f.au_in_force_date is not null \n";
        sQuery += "and f.au_max_end_date is not null \n";
        sQuery += "and f.au_in_force_date < f.au_max_end_date \n";
        sQuery += "and f.au_pct_application_no is null \n";
        sQuery += "and f.au_wipo_number is null \n";
        sQuery += "and f.au_secrecy_required_ind ='N' \n";
        sQuery += "and f.au_under_opposition_ind = 'N' \n";
        sQuery += "and f.au_in_force_date > sysdate \n";
        sQuery += "and sysdate <= (add_months(to_date(f.au_in_force_date),6)) \n";

        runQuery(sQuery);

        return this;
    }

}
