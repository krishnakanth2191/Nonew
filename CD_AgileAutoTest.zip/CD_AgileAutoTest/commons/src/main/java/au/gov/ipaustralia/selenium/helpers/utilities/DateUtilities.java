package au.gov.ipaustralia.selenium.helpers.utilities;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * A collection of static methods to provide common date manipulation functions
 * 
 * 
 * @author cpahan
 *
 */
public class DateUtilities {

    private static String dateFORMAT = "dd/MM/yyyy";

    private static String yearFORMAT = "yyyy";

    private DateUtilities() {
        throw new IllegalStateException("DateUtilities class");
    }

    /**
     * 
     * @return today's date formatted to 'dd/MM/yyyy'
     */
    public static String today() {
        return today(dateFORMAT);
    }

    /**
     * 
     * @return year formatted to 'yyyy'
     */
    public static String year() {
        return today(yearFORMAT);
    }

    /**
     * @param formattedAs
     *            a SimpleDateFormat date pattern
     * 
     * @return string representation of today's date
     */
    public static String today(String formattedAs) {
        return formatDate(new Date(), formattedAs);
    }

    /**
     * Formats a date with error handling
     * 
     * @param date
     *            <code>Date</code> object
     * @param formatAs
     *            a SimpleDateFormat date pattern
     * @return formatted string
     */
    public static String formatDate(Date date,
                                    String formatAs) {
        String dateString = "";
        try {
            dateString = new SimpleDateFormat(formatAs).format(date);
        }
        catch (NullPointerException n) {
            String msge = "Pattern parameter formatAs is null.";
            throw new DateUtilitiesException(msge, n);
        }
        catch (IllegalArgumentException i) {
            String msge = String.format("'%s' is not a valid date pattern.", formatAs);
            throw new DateUtilitiesException(msge, i);
        }
        return dateString;
    }

    /**
     * parse a string to a <code>Date</code> object with error handling
     * 
     * @param date
     *            ...
     * @param format
     *            a SimpleDateFormat date pattern
     * 
     * @return a <code>Date</code> object
     */
    public static Date parseDate(String date,
                                 String format) {
        Date dateNew = null;
        try {
            SimpleDateFormat inFormatter = new SimpleDateFormat(format);
            dateNew = inFormatter.parse(date);
        }
        catch (ParseException e) {
            String msge = String.format("Parameter '%s' does not parse as a date.", date);
            throw new DateUtilitiesException(msge, e);
        }
        catch (NullPointerException n) {
            String msge = "Pattern parameter format is null.";
            throw new DateUtilitiesException(msge, n);
        }
        catch (IllegalArgumentException i) {
            String msge = String.format("'%s' is not a valid date pattern.", format);
            throw new DateUtilitiesException(msge, i);
        }

        return dateNew;
    }

    /**
     * adds a defined interval to a dB date and return the desired format
     * 
     * @param date
     *            string representation of a date in the standard dB pattern'yyyy-MM-dd hh:mm:ss.s'
     * @param unitsToAdd
     *            one of the <code>Calendar</code> class interval enumerations (for example Calendar.DAY_OF_MONTH)
     * @param numberOfUnits
     *            use '-' to subtract
     * @param formattedAs
     *            the return date string format pattern
     * 
     * @return string representation of a date
     *
     */
    public static String addIntervalToDbDate(String date,
                                             int unitsToAdd,
                                             int numberOfUnits,
                                             String formattedAs) {
        return addIntervalToDate(date, "yyyy-MM-dd hh:mm:ss.s", unitsToAdd, numberOfUnits, formattedAs);
    }

    /**
     * adds a defined interval to a dB date and returns the standard format 'dd/MM/yyyy'
     * 
     * @param date
     *            string representation of a date in the standard dB pattern'yyyy-MM-dd hh:mm:ss.s'
     * @param unitsToAdd
     *            one of the <code>Calendar</code> class interval enumerations (for example Calendar.MONTH)
     * @param numberOfUnits
     *            use '-' to subtract
     * 
     * @return date formatted to 'dd/MM/yyyy'
     */
    public static String addIntervalToDbDate(String date,
                                             int unitsToAdd,
                                             int numberOfUnits) {
        return addIntervalToDate(date, "dd/MM/yyyy hh:mm:ss.s", unitsToAdd, numberOfUnits, dateFORMAT);
    }

    /**
     * adds a defined interval to a dB date and returns the standard format 'dd/MM/yyyy'
     * 
     * @param date
     *            string representation of a date in the standard dB pattern'yyyy-MM-dd hh:mm:ss'
     * @param unitsToAdd
     *            one of the <code>Calendar</code> class interval enumerations (for example Calendar.MONTH)
     * @param numberOfUnits
     *            use '-' to subtract
     * 
     * @return date formatted to 'dd/MM/yyyy'
     */
    public static String addIntervalToFateDate(String date,
                                               int unitsToAdd,
                                               int numberOfUnits) {
        return addIntervalToDate(date, "yyyy-MM-dd hh:mm:ss", unitsToAdd, numberOfUnits, dateFORMAT);
    }

    /**
     * adds a defined interval to a date and return the desired format
     * 
     * @param date
     *            string representation of a date
     * @param dateFormat
     *            the pattern to use to parse the date string
     * @param unitsToAdd
     *            one of the <code>Calendar</code> class interval enumerations (for example Calendar.YEAR)
     * @param numberOfUnits
     *            use '-' to subtract
     * @param formattedAs
     *            the return date string format pattern
     * 
     * @return string representation of a date
     */
    public static String addIntervalToDate(String date,
                                           String dateFormat,
                                           int unitsToAdd,
                                           int numberOfUnits,
                                           String formattedAs) {
        Date beforeAdd = parseDate(date, dateFormat);
        return addIntervalToDate(beforeAdd, unitsToAdd, numberOfUnits, formattedAs);
    }

    /**
     * adds a defined interval to a <code>Date</code> object and returns the desired format
     * 
     * @param date
     *            <code>Date</code> object
     * @param unitsToAdd
     *            one of the <code>Calendar</code> class interval enumerations (for example Calendar.YEAR)
     * @param numberOfUnits
     *            use '-' to subtract
     * @param formattedAs
     *            the return date string format pattern
     * 
     * @return string representation of a date
     */
    public static String addIntervalToDate(Date date,
                                           int unitsToAdd,
                                           int numberOfUnits,
                                           String formattedAs) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(unitsToAdd, numberOfUnits);
        Date aFterAdd = cal.getTime();

        return formatDate(aFterAdd, formattedAs);
    }

}

/**
 * Provides an unchecked runtime wrapper for any exceptions triggered in DateUtilities
 * 
 * @author Anthony Hallett
 *
 */
class DateUtilitiesException extends RuntimeException {

    /** Serial id number */
    private static final long serialVersionUID = 1L;

    /**
     * 
     * @param message
     *            new exception message
     */
    public DateUtilitiesException(String message) {
        super(message);
    }

    /**
     * Constructor which wraps a caught exception.<br>
     * 
     * @param cause
     *            caught exception
     */
    public DateUtilitiesException(Throwable cause) {
        super(cause);
    }

    /**
     * Constructor which adds more information and wraps a caught exception.<br>
     * 
     * @param message
     *            text
     * @param cause
     *            caught exception
     */
    public DateUtilitiesException(String message, Throwable cause) {
        super(message, cause);
    }
}
