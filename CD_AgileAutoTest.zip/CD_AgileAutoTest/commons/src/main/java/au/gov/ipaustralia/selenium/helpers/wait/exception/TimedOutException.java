package au.gov.ipaustralia.selenium.helpers.wait.exception;

/**
 * Provides an unchecked runtime wrapper for timeout fails
 * 
 * @author Anthony Hallett
 *
 */
public class TimedOutException extends RuntimeException {

	/** Serial id number */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 * @param message
	 *            new exception message
	 */
	public TimedOutException(String message) {
		super(message);
	}

	/**
	 * Constructor which wraps a caught exception.<br>
	 * 
	 * @param cause
	 *            caught exception
	 */
	public TimedOutException(Throwable cause) {
		super(cause);
	}

	/**
	 * Constructor which adds more information and wraps a caught exception.<br>
	 * 
	 * @param message
	 *            text
	 * @param cause
	 *            caught exception
	 */
	public TimedOutException(String message, Throwable cause) {
		super(message, cause);
	}
}
