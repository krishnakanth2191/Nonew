package au.gov.ipaustralia.selenium.helpers.wait.exception;

/**
 * Provides an unchecked runtime wrapper for unknown option fails
 * 
 * @author Anthony Hallett
 *
 */
public class UnknownOptionException extends RuntimeException {
	/** Serial id number */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 * @param message
	 *            new exception message
	 */
	public UnknownOptionException(String message) {
		super(message);
	}
	
	/**
	 * Constructor which wraps a caught exception.<br>
	 * 
	 * @param cause
	 *            caught exception
	 */
	public UnknownOptionException(Throwable cause) {
		super(cause);
	}
	
	/**
	 * Constructor which adds more information and wraps a caught exception.<br>
	 * 
	 * @param message
	 *            text
	 * @param cause
	 *            caught exception
	 */
	public UnknownOptionException(String message, Throwable cause) {
		super(message, cause);
	}
}
