package au.gov.ipaustralia.selenium.helpers.wait;

import java.util.List;
import java.util.Vector;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Wait tool class. Provides Wait methods for an elements, and AJAX elements to
 * load. It uses WebDriverWait (explicit wait) for waiting an element or
 * javaScript.
 * 
 * To use implicitlyWait() and WebDriverWait() in the same test, we would have
 * to nullify implicitlyWait() before calling WebDriverWait(), and reset after
 * it. This class takes care of it.
 * 
 * 
 * Generally relying on implicitlyWait slows things down so use WaitTool�s
 * explicit wait methods as much as possible. Also, consider
 * (DEFAULT_WAIT_4_PAGE = 0) for not using implicitlyWait for a certain test.
 * 
 */
public class WaitTool {

	private static final Logger LOGGER = Logger.getLogger(WaitTool.class);

	/** Default wait time for an element. 7 seconds. */
	public static final int DEFAULT_WAIT_4_ELEMENT = 7;
	/**
	 * Default wait time for a page to be displayed. 12 seconds. The average
	 * webpage load time is 6 seconds in 2012. Based on your tests, please set
	 * this value. "0" will nullify implicitlyWait and speed up a test.
	 */
	public static final int DEFAULT_WAIT_4_PAGE = 12;

	private WaitTool() {
		throw new IllegalStateException("WaitTool class");
	}

	/**
	 * Wait for the element to be present in the DOM, and displayed on the page.
	 * And returns the first WebElement using the given method.
	 * 
	 * @param WebDriver
	 *            The driver object to be used
	 * @param By
	 *            selector to find the element
	 * @param int
	 *            The time in seconds to wait until returning a failure
	 *
	 * @return WebElement the first WebElement using the given method, or null
	 *         (if the timeout is reached)
	 */
	public static WebElement waitForElement(WebDriver driver, final By by, int timeOutInSeconds) {
		WebElement element;
		try {
			// To use WebDriverWait(), we would have to nullify
			// implicitlyWait().
			// Because implicitlyWait time also set "driver.findElement()" wait
			// time.
			// info from:
			// https://groups.google.com/forum/?fromgroups=#!topic/selenium-users/6VO_7IXylgY
			driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS); // nullify
																			// implicitlyWait()

			WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);
			element = wait.until(ExpectedConditions.visibilityOfElementLocated(by));

			driver.manage().timeouts().implicitlyWait(DEFAULT_WAIT_4_PAGE, TimeUnit.SECONDS); // reset
																								// implicitlyWait
			return element; // return the element
		} catch (Exception e) {
			LOGGER.info("Element Not Found after Timeout", e);
		}
		return null;
	}

	/**
	 * Wait until the page is completely loaded
	 */
	public static void waitForLoad(WebDriver driver, int timeout) {
		ExpectedCondition<Boolean> pageLoadCondition = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver wd) {
				// this will tel if page is loaded
				return "complete".equals(((JavascriptExecutor) wd).executeScript("return document.readyState"));
			}
		};

		// wait for page complete
		waitFor(driver, timeout).until(pageLoadCondition);
	}

	/**
	 * Wait for the element to be present in the DOM, regardless of being
	 * displayed or not. And returns the first WebElement using the given
	 * method.
	 *
	 * @param WebDriver
	 *            The driver object to be used
	 * @param By
	 *            selector to find the element
	 * @param int
	 *            The time in seconds to wait until returning a failure
	 * 
	 * @return WebElement the first WebElement using the given method, or null
	 *         (if the timeout is reached)
	 */
	public static WebElement waitForElementPresent(WebDriver driver, final By by, int timeOutInSeconds) {
		WebElement element;
		try {
			driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS); // nullify
																			// implicitlyWait()

			WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);
			element = wait.until(ExpectedConditions.presenceOfElementLocated(by));

			driver.manage().timeouts().implicitlyWait(DEFAULT_WAIT_4_PAGE, TimeUnit.SECONDS); // reset
																								// implicitlyWait
			return element; // return the element
		} catch (Exception e) {
		    LOGGER.info("Element Not Found", e);
		}
		return null;
	}

	/**
	 * Wait for the List<WebElement> to be present in the DOM, regardless of
	 * being displayed or not. Returns all elements within the current page DOM.
	 * 
	 * @param WebDriver
	 *            The driver object to be used
	 * @param By
	 *            selector to find the element
	 * @param int
	 *            The time in seconds to wait until returning a failure
	 *
	 * @return List<WebElement> all elements within the current page DOM, or
	 *         null (if the timeout is reached)
	 */
	public static List<WebElement> waitForListElementsPresent(WebDriver driver, final By by, int timeOutInSeconds) {
		List<WebElement> elements = null;
		try {
			driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS); // nullify
																			// implicitlyWait()

			WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);
			wait.until((new ExpectedCondition<Boolean>() {
				@Override
				public Boolean apply(WebDriver driverObject) {
					return areElementsPresent(driverObject, by);
				}
			}));

			elements = driver.findElements(by);
			driver.manage().timeouts().implicitlyWait(DEFAULT_WAIT_4_PAGE, TimeUnit.SECONDS); // reset
																								// implicitlyWait
			return elements; // return the element
		} catch (Exception e) {
		    LOGGER.info("Element Not Present", e);
		}
		return elements;

	}

	/**
	 * Wait for an element to appear on the refreshed web-page. And returns the
	 * first WebElement using the given method.
	 *
	 * This method is to deal with dynamic pages.
	 * 
	 * Some sites I (Mark) have tested have required a page refresh to add
	 * additional elements to the DOM. Generally you (Chon) wouldn't need to do
	 * this in a typical AJAX scenario.
	 * 
	 * @param WebDriver
	 *            The driver object to use to perform this element search
	 * @param locator
	 *            selector to find the element
	 * @param int
	 *            The time in seconds to wait until returning a failure
	 * 
	 * @return WebElement the first WebElement using the given method, or
	 *         null(if the timeout is reached)
	 * 
	 * @author Mark Collin
	 */
	public static WebElement waitForElementRefresh(WebDriver driver, final By by, int timeOutInSeconds) {
		WebElement element;
		try {
			driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS); // nullify
																			// implicitlyWait()
			new WebDriverWait(driver, timeOutInSeconds) {
			}.until(new ExpectedCondition<Boolean>() {

				@Override
				public Boolean apply(WebDriver driverObject) {
					driverObject.navigate().refresh(); // refresh the page
														// ****************
					return isElementPresentAndDisplay(driverObject, by);
				}
			});
			element = driver.findElement(by);
			driver.manage().timeouts().implicitlyWait(DEFAULT_WAIT_4_PAGE, TimeUnit.SECONDS); // reset
																								// implicitlyWait
			return element; // return the element
		} catch (Exception e) {
		    LOGGER.info("Element Not Refreshed", e);
		}
		return null;
	}

	/**
	 * Wait for the Text to be present in the given element, regardless of being
	 * displayed or not.
	 *
	 * @param WebDriver
	 *            The driver object to be used to wait and find the element
	 * @param locator
	 *            selector of the given element, which should contain the text
	 * @param String
	 *            The text we are looking
	 * @param int
	 *            The time in seconds to wait until returning a failure
	 * 
	 * @return boolean
	 */
	public static boolean waitForTextPresent(WebDriver driver, final By by, final String text, int timeOutInSeconds) {
		boolean isPresent = false;
		try {
			driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS); // nullify
																			// implicitlyWait()
			new WebDriverWait(driver, timeOutInSeconds) {
			}.until(new ExpectedCondition<Boolean>() {

				@Override
				public Boolean apply(WebDriver driverObject) {
					return isTextPresent(driverObject, by, text); // is the Text
																	// in the
																	// DOM
				}
			});
			isPresent = isTextPresent(driver, by, text);
			driver.manage().timeouts().implicitlyWait(DEFAULT_WAIT_4_PAGE, TimeUnit.SECONDS); // reset
																								// implicitlyWait
			return isPresent;
		} catch (Exception e) {
		    LOGGER.info("Element Text Not Found", e);
		}
		return false;
	}

	/**
	 * Waits for the Condition of JavaScript.
	 *
	 *
	 * @param WebDriver
	 *            The driver object to be used to wait and find the element
	 * @param String
	 *            The javaScript condition we are waiting. e.g. "return
	 *            (xmlhttp.readyState >= 2 && xmlhttp.status == 200)"
	 * @param int
	 *            The time in seconds to wait until returning a failure
	 * 
	 * @return boolean true or false(condition fail, or if the timeout is
	 *         reached)
	 **/
	public static boolean waitForJavaScriptCondition(WebDriver driver, final String javaScript, int timeOutInSeconds) {
		boolean jscondition = false;
		try {
			driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS); // nullify
																			// implicitlyWait()
			new WebDriverWait(driver, timeOutInSeconds) {
			}.until(new ExpectedCondition<Boolean>() {

				@Override
				public Boolean apply(WebDriver driverObject) {
					return (Boolean) ((JavascriptExecutor) driverObject).executeScript(javaScript);
				}
			});
			jscondition = (Boolean) ((JavascriptExecutor) driver).executeScript(javaScript);
			driver.manage().timeouts().implicitlyWait(DEFAULT_WAIT_4_PAGE, TimeUnit.SECONDS); // reset
																								// implicitlyWait
			return jscondition;
		} catch (Exception e) {
		    LOGGER.info("Element waitForJavaScriptCondition not Found", e);
		}
		return false;
	}

	/**
	 * Waits for the completion of Ajax jQuery processing by checking "return
	 * jQuery.active == 0" condition.
	 *
	 * @param WebDriver
	 *            - The driver object to be used to wait and find the element
	 * @param int
	 *            - The time in seconds to wait until returning a failure
	 * 
	 * @return boolean true or false(condition fail, or if the timeout is
	 *         reached)
	 */
	public static boolean waitForJQueryProcessing(WebDriver driver, int timeOutInSeconds) {
		boolean jQcondition = false;
		try {
			driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS); // nullify
																			// implicitlyWait()
			new WebDriverWait(driver, timeOutInSeconds) {
			}.until(new ExpectedCondition<Boolean>() {

				@Override
				public Boolean apply(WebDriver driverObject) {
					return (Boolean) ((JavascriptExecutor) driverObject).executeScript("return jQuery.active == 0");
				}
			});
			jQcondition = (Boolean) ((JavascriptExecutor) driver).executeScript("return jQuery.active == 0");
			driver.manage().timeouts().implicitlyWait(DEFAULT_WAIT_4_PAGE, TimeUnit.SECONDS); // reset
																								// implicitlyWait
			return jQcondition;
		} catch (Exception e) {
		    LOGGER.info("Element JQueryProcessing Not Found", e);
		}
		return jQcondition;
	}

	/**
	 * Coming to implicit wait, If you have set it once then you would have to
	 * explicitly set it to zero to nullify it -
	 */
	public static void nullifyImplicitWait(WebDriver driver) {
		driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS); // nullify
																		// implicitlyWait()
	}

	/**
	 * Set driver implicitlyWait() time.
	 */
	public static void setImplicitWait(WebDriver driver, int waitTimeInSeconds) {
		driver.manage().timeouts().implicitlyWait(waitTimeInSeconds, TimeUnit.SECONDS);
	}

	/**
	 * Reset ImplicitWait. To reset ImplicitWait time you would have to
	 * explicitly set it to zero to nullify it before setting it with a new time
	 * value.
	 */
	public static void resetImplicitWait(WebDriver driver) {
		driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS); // nullify
																		// implicitlyWait()
		driver.manage().timeouts().implicitlyWait(DEFAULT_WAIT_4_PAGE, TimeUnit.SECONDS); // reset
																							// implicitlyWait
	}

	/**
	 * Reset ImplicitWait.
	 * 
	 * @param int
	 *            - a new wait time in seconds
	 */
	public static void resetImplicitWait(WebDriver driver, int newWaittimeInSeconds) {
		driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS); // nullify
																		// implicitlyWait()
		driver.manage().timeouts().implicitlyWait(newWaittimeInSeconds, TimeUnit.SECONDS); // reset
																							// implicitlyWait
	}

	/**
	 * Checks if the text is present in the element.
	 * 
	 * @param driver
	 *            - The driver object to use to perform this element search
	 * @param by
	 *            - selector to find the element that should contain text
	 * @param text
	 *            - The Text element you are looking for
	 * @return true or false
	 */
	private static boolean isTextPresent(WebDriver driver, By by, String text) {
		try {
			return driver.findElement(by).getText().contains(text);
		} catch (NullPointerException e) {
		    LOGGER.info("Text Not Present", e);
			return false;
		}
	}

	/**
	 * Checks if the List<WebElement> are in the DOM, regardless of being
	 * displayed or not.
	 * 
	 * @param driver
	 *            - The driver object to use to perform this element search
	 * @param by
	 *            - selector to find the element
	 * @return boolean
	 */
	private static boolean areElementsPresent(WebDriver driver, By by) {
		try {
			driver.findElements(by);
			return true;
		} catch (NoSuchElementException e) {
		    LOGGER.info("Element not Present", e);
			return false;
		}
	}

	/**
	 * Checks if the elment is in the DOM and displayed.
	 * 
	 * @param driver
	 *            - The driver object to use to perform this element search
	 * @param by
	 *            - selector to find the element
	 * @return boolean
	 */
	private static boolean isElementPresentAndDisplay(WebDriver driver, By by) {
		try {
			return driver.findElement(by).isDisplayed();
		} catch (NoSuchElementException e) {
		    LOGGER.info("ElementPresent is not Displayed", e);
			return false;
		}
	}

	/**
	 * * Convenience method wrapping Thread sleep
	 * 
	 * @param milliseconds
	 *            - the length of the required sleep in milliseconds
	 * 
	 */
	public static void sleep(final long milliseconds) {
		try {
			Thread.sleep(milliseconds);
		} catch (final InterruptedException e) {

			LOGGER.info("InterruptedException", e);
			Thread.currentThread().interrupt();
		}
	}

	/**
	 * Constructs a new WebDriverWait, using the page default driver and
	 * timeout.
	 * 
	 * @return the new WebDriverWait
	 */
	public static WebDriverWait waitFor(WebDriver driver, int timeout) {
		return new WebDriverWait(driver, timeout);
	}

	/**
	 * Waits until the specified element is clickable. Will wait for the page
	 * default timeout, using the page default driver.
	 *
	 * @param webElement
	 *            the element that is expected to become clickable.
	 * @return the clickable element.
	 */

	public static WebElement waitUntilClickable(WebDriver driver, int timeout, final WebElement webElement) {
		return waitFor(driver, timeout).ignoring(StaleElementReferenceException.class)
				.until(ExpectedConditions.elementToBeClickable(webElement));
	}

	public static WebElement waitUntilPresenceOfElementLocated(WebDriver driver, int timeout, String xPath) {

		return waitFor(driver, timeout).ignoring(StaleElementReferenceException.class)
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xPath)));
	}

	/**
	 * Waits until the specified element is visible. Will wait for the page
	 * default timeout, using the page default driver.
	 *
	 * @param webElement
	 *            the element that is expected to become visible.
	 * @return the visible element.
	 */

	public static WebElement waitUntilVisible(WebDriver driver, int timeout, final WebElement webElement) {
		return waitFor(driver, timeout).ignoring(StaleElementReferenceException.class)
				.until(ExpectedConditions.visibilityOf(webElement));
	}
	
    /**
     * Waits until the specified element is invisible. Will wait for the page
     * default timeout, using the page default driver.
     *
     * @param webElement
     *            the element that is expected to become invisible.
     * @return the invisible element.
     */

    public static boolean waitUntilInvisible(WebDriver driver, int timeout, final Vector<WebElement> webElement) {
        return waitFor(driver, timeout).ignoring(StaleElementReferenceException.class)
                .until(ExpectedConditions.invisibilityOfAllElements(webElement));
    }

}
/*
 * References: 1. Mark Collin's post on:
 * https://groups.google.com/forum/?fromgroups#!topic/webdriver/V9KqskkHmIs%5B1-
 * 25%5D Mark's code inspires me to write this class. Thank you! Mark. 2. Andre,
 * and Tarun Kumar's post on:
 * https://groups.google.com/forum/?fromgroups=#!topic/selenium-users/
 * 6VO_7IXylgY 3. Explicit and Implicit Waits:
 * http://seleniumhq.org/docs/04_webdriver_advanced.html
 * 
 * Note: 1. Instead of creating new WebDriverWait() instance every time in each
 * methods, I tried to reuse a single WebDriverWait() instance, but I found and
 * tested that creating 100 WebDriverWait() instances takes less than one
 * millisecond. So, it seems not necessary.
 */
