package au.gov.ipaustralia.selenium.helpers.clickMethods;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import au.gov.ipaustralia.selenium.helpers.wait.WaitTool;

/**
 * 
 * 
 * @author Suresh Thumma
 *
 */

public class ClickActions {

    /** driver for the target test browser */
    protected static WebDriver driver;

    /** standard wait time for most time dependant functions */
    protected static int timeout;

    private static final Logger LOGGER = Logger.getLogger(ClickActions.class);

    /**
     * @return this instance (can chain method calls) Inconsistency sometimes clicking an WebElement not performing the
     *         required action
     */

    private ClickActions() {
        throw new IllegalStateException("ClickActions class");
    }

    public static ClickActions clickUntilFound(WebElement element) {
        WaitTool.waitUntilClickable(driver, timeout, element);
        for (int i = 0; i < 10; i++) {
            try {
                element.click();
                break;
            }
            catch (Exception e) {
                LOGGER.info("Element not found yet", e);

            }
        }
        return null;
    }

    public static ClickActions click(WebElement element) {
        try {
            (new WebDriverWait(driver, timeout)).ignoring(StaleElementReferenceException.class);
            while (element.isEnabled()) {
                element.click();
            }
        }
        catch (Exception e) {
            LOGGER.info("Application not stable nothing to see here", e);
        }
        return null;
    }

    /**
     * @return this instance (can chain method calls)
     */
    public static ClickActions clickCheckBox(WebElement element) {
        WaitTool.waitUntilClickable(driver, timeout, element);
        try {
            while (!element.isSelected()) {
                element.click();
                WaitTool.sleep(2000);
            }
        }
        catch (Exception e) {
            LOGGER.info("Check box not Clicked", e);

        }
        return null;
    }

    // BaseFrame

    /**
     * @return this instance (can chain method calls)
     */
    public static ClickActions clickTab(WebElement webElement) {

        JavascriptExecutor executor = (JavascriptExecutor) driver;
        executor.executeScript("arguments[0].click();", webElement);

        return null;
    }

    /**
     * @return this instance (can chain method calls)
     */
    public static ClickActions doubleClick(WebElement webElement) {

        new Actions(driver).doubleClick(webElement).build().perform();

        return null;
    }

    /**
     * @param text
     *            ...
     * @return this instance (can chain method calls)
     */
    public static ClickActions selectListType(WebElement webElement,
                                              String text) {
        WaitTool.waitUntilVisible(driver, timeout, webElement);
        new Select(webElement).selectByVisibleText(text);
        return null;
    }

    /**
     * includes wait until spinner is not displayed
     * 
     * @param waitTime
     *            maximum time to wait
     * @return this instance (can chain method calls)
     */
    public static ClickActions clickSubmitButton() {
        final String submitXPath = "//button[contains(@title, 'Complete this')]";

        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(By.xpath(submitXPath)));
        WebElement btn = driver.findElement(By.xpath(submitXPath));
        click(btn);
        try {
            (new WebDriverWait(driver,
                    1)).until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("ul[role = 'progressbar']")));
        }
        catch (TimeoutException e) {
            LOGGER.info("ignore if not found .. means we're in a super fast env :-)", e);
        }

        return null;
    }

    public static void clickButton(String xPathToLookFor,
                                   WebElement webElement) {
        WaitTool.waitForLoad(driver, timeout);
        WaitTool.waitUntilClickable(driver, timeout, webElement);
        boolean present = false;
        do {
            try {
                Actions actions = new Actions(driver);
                actions.moveToElement(webElement).click().perform();
                WaitTool.waitForLoad(driver, timeout);
                present = driver.findElements(By.xpath(xPathToLookFor)).size() != 0;
            }
            catch (StaleElementReferenceException serException) {
                LOGGER.info("Stale element refrence", serException);
                present = driver.findElements(By.xpath(xPathToLookFor)).size() != 0;

            }
            catch (NoSuchElementException nseException) {
                LOGGER.info("No Such Element", nseException);
                break;
            }
        }
        while (present);
    }

    public static void clickAddButton(String xPathToLookFor,
                                      WebElement webElement) {
        WaitTool.waitForLoad(driver, timeout);
        WaitTool.waitUntilClickable(driver, timeout, webElement);
        boolean present = false;
        do {
            try {
                Actions actions = new Actions(driver);
                actions.moveToElement(webElement).click().perform();
                WaitTool.waitForLoad(driver, timeout);
                present = driver.findElements(By.xpath(xPathToLookFor)).size() != 0;
            }
            catch (StaleElementReferenceException serException) {
                LOGGER.info("Stale element refrence Exception", serException);
            }
            catch (NoSuchElementException nseException) {
                LOGGER.info("No Such Element", nseException);
                break;
            }
        }
        while (!present);
    }

}
