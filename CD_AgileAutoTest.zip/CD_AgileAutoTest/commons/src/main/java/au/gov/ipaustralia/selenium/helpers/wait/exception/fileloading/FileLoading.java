package au.gov.ipaustralia.selenium.helpers.wait.exception.fileloading;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;

import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.jcabi.aspects.Loggable;

import au.gov.ipaustralia.selenium.helpers.wait.WaitTool;
import au.gov.ipaustralia.selenium.helpers.wait.exception.windowsSwitch.SwitchWindows;

/**
 * defines abstracts for a few things that all pages should have<br>
 * No real logic pragmatic collection of attributes and methods which are convenient to use across all pages
 *
 * 
 * @author Anthony Hallett
 *
 */
@Loggable(prepend = true)
public class FileLoading {

    private static final Logger LOGGER = Logger.getLogger(FileLoading.class);
    /** driver for the target test browser */
    protected static WebDriver driver;

    /** standard wait time for most time dependant functions */
    protected static int timeout;

    public static void upLoadFile(final String file) {
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.alertIsPresent());

        // switch to the file upload window
        final Alert alert = driver.switchTo().alert();

        // enter the filename
        alert.sendKeys(file);

        // hit enter
        Robot robo;
        try {
            robo = new Robot();
            robo.setAutoDelay(125);
            robo.keyPress(KeyEvent.VK_ENTER);
            robo.keyRelease(KeyEvent.VK_ENTER);
            robo.delay(500);
        }
        catch (final AWTException e) {
            LOGGER.info("KeyBoard Enter not typed", e);
            return;
        }

        driver.switchTo().activeElement();
    }

    /**
     * Windows upload file alert
     *
     * @param file
     *            the full path of the file to upload
     */
    protected void upLoadFile(final WebElement fileInput,
                              final String file) {
        // enter the filename
        fileInput.sendKeys(file);
    }

    public void openViewIpRightCorroPage(String ipRight,
                                         String corroType) {
        String filePath = System.getProperty("user.dir") + File.separator + "test-output";
        String file = filePath + File.separator + ipRight + "_" + corroType;

        SwitchWindows.waitForWindow(driver);
        SwitchWindows.switchToTopLevelWindow(driver);
        saveFile(file);

    }

    /**
     * Windows save file to disk, works just like manual process using robo function
     *
     * @param file
     *            the full path of the file to download
     */
    public void saveFile(String filePath) {

        Robot robo;
        try {
            robo = new Robot();
            robo.setAutoDelay(125);
            robo.keyPress(KeyEvent.VK_CONTROL);
            robo.keyPress(KeyEvent.VK_S);
            robo.keyRelease(KeyEvent.VK_CONTROL);
            robo.keyRelease(KeyEvent.VK_S);
            robo.delay(500);
        }
        catch (AWTException e) {
            LOGGER.info("KeyBoard Ctrl+S not typed", e);

        }

        // hit enter

        try {
            robo = new Robot();
            robo.keyPress(KeyEvent.VK_SHIFT);
            robo.keyPress(KeyEvent.VK_BACK_SPACE);
            robo.keyRelease(KeyEvent.VK_BACK_SPACE);
            robo.keyRelease(KeyEvent.VK_SHIFT);
            robo.setAutoDelay(125);

            StringSelection selection = new StringSelection(filePath);
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            clipboard.setContents(selection, selection);

            robo.keyPress(KeyEvent.VK_CONTROL);
            robo.keyPress(KeyEvent.VK_V);
            robo.keyRelease(KeyEvent.VK_V);
            robo.keyRelease(KeyEvent.VK_CONTROL);
            robo.delay(1000);
            robo.keyPress(KeyEvent.VK_ENTER);
            robo.keyRelease(KeyEvent.VK_ENTER);
            robo.delay(5000);
            WaitTool.sleep(1000);
        }
        catch (final AWTException e) {
            LOGGER.info("KeyBoard Enter not typed", e);
            return;
        }

        driver.switchTo().activeElement();

    }

}
