package au.gov.ipaustralia.selenium.helpers.utilities;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * A collection of static methods to provide common regular expression functions
 * 
 * 
 * @author Anthony Hallett
 *
 */
public class RegExpUtilities {
	
	public static final String DATE_REGEXP =  "\\d{1,2}\\/\\d{2}\\/\\d{4}"; 
	public static final String DATE_REGEXP_2DIGITYEAR =  "\\d{1,2}\\/\\d{2}\\/\\d{2}"; 
	
	/**
	 * Wrapper with error handling
	 * 
	 * @param pattern
	 *            the regular expression
	 * @param flags
	 *            the required <code>Pattern</code> match flag bit mask
	 * @param target
	 *            the string to match
	 * 
	 * @return a <code>Matcher</code> object
	 */
	public static Matcher getMatcher(String pattern, int flags, String target) {
		Pattern patternNew = null;
		try {
			patternNew = Pattern.compile(pattern, flags);
		} catch (PatternSyntaxException e) {
			String msge = String.format("Pattern '%s'  is not a valid regular expression", pattern);
			throw new RegExpUtilitiesException(msge, e);
		} catch (IllegalArgumentException i) {
			String msge = String.format("flag: '%s'  does not correspond to the defined match flag bit values", flags);
			throw new RegExpUtilitiesException(msge, i);
		}

		return patternNew.matcher(pattern);

	}

	/**
	 * Wrapper with error handling for a CASE_INSENSITIVE match
	 * 
	 * @param pattern
	 *            the regular expression
	 * @param target
	 *            the string to match
	 * 
	 * @return a <code>Matcher</code> object
	 */
	public static Matcher getMatcher(String pattern, String target) {
		return getMatcher(pattern, Pattern.CASE_INSENSITIVE, target);
	}

	/**
	 * Wrapper with error handling for a CASE_INSENSITIVE match
	 * 
	 * @param pattern
	 *            the regular expression
	 * @param target
	 *            the string to match
	 * @return true if a least 1 match is found
	 */
	public static boolean matchesAnyCase(String pattern, String target) {
		Matcher matcher = getMatcher(pattern, target);
		return matcher.find();
	}

	/**
	 * Wrapper with error handling for a match to a standard date format of
	 * dd/MM/yyyy
	 * 
	 * @param target
	 *            the string to match
	 * @return true if a least 1 match is found
	 */
	public static boolean matchesStandardDate(String target) {
		return matchesAnyCase(DATE_REGEXP, target);
	}

}

/**
 * Provides an unchecked runtime wrapper for any exceptions triggered in
 * RegExpUtilities
 * 
 * @author Anthony Hallett
 *
 */
class RegExpUtilitiesException extends RuntimeException {

	/** Serial id number */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 * @param message
	 *            new exception message
	 */
	public RegExpUtilitiesException(String message) {
		super(message);
	}

	/**
	 * Constructor which wraps a caught exception.<br>
	 * 
	 * @param cause
	 *            caught exception
	 */
	public RegExpUtilitiesException(Throwable cause) {
		super(cause);
	}

	/**
	 * Constructor which adds more information and wraps a caught exception.<br>
	 * 
	 * @param message
	 *            text
	 * @param cause
	 *            caught exception
	 */
	public RegExpUtilitiesException(String message, Throwable cause) {
		super(message, cause);
	}
}