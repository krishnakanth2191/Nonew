package au.gov.ipaustralia.selenium.helpers.wait.exception.windowsSwitch;

import java.util.Iterator;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.WebDriver;

import com.jcabi.aspects.Loggable;

import au.gov.ipaustralia.selenium.helpers.wait.WaitTool;

/**
 * defines abstracts for a few things that all pages should have<br>
 * No real logic pragmatic collection of attributes and methods which are
 * convenient to use across all pages
 *
 * 
 * @author Anthony Hallett
 *
 */
@Loggable(prepend = true)
public class SwitchWindows {

	private static final Logger LOGGER = Logger.getLogger(SwitchWindows.class);

	/** driver for the target test browser */
	protected WebDriver driver;

	/** standard wait time for most time dependant functions */
	protected int timeout;

	/** this window's hwnd REM Windows OS only */
	protected String windowHandle;

	/**
	 * Constructor with driver
	 *
	 * 
	 * populates the current context Window hwnd from the driver
	 *
	 * consumes NoSuchWindowException if driver has no window context
	 *
	 * @param driver
	 *            the WebDriver
	 * 
	 */
	public SwitchWindows(final WebDriver driver) {

		this.driver = driver;

		try {
			this.windowHandle = driver.getWindowHandle();

		} catch (final NoSuchWindowException e) {
			LOGGER.info("No Window Found", e);

		}
	}

	public static void waitForWindow(WebDriver driver) {
		// wait until number of window handles become 2 or until 6 seconds are
		// completed.
		int timecount = 1;
		do {
			driver.getWindowHandles();
			LOGGER.info("# Window Handles->" + driver.getWindowHandles().size());
			WaitTool.sleep(200);
			timecount++;
			if (timecount > 30) {
				break;
			}
		} while (driver.getWindowHandles().size() != 2);

	}

	public static void switchToModalDialog(WebDriver driver, String parent) {
		// Switch to Modal dialog
		if (driver.getWindowHandles().size() == 2) {
			for (String window : driver.getWindowHandles()) {
				if (!window.equals(parent)) {
					driver.switchTo().window(window);
					break;
				}
			}
		}
	}

	public static void switchToTopLevelWindow(WebDriver driver) {
		String subWindowHandler = null;

		Set<String> handles = driver.getWindowHandles();
		Iterator<String> iterator = handles.iterator();
		while (iterator.hasNext()) {
			subWindowHandler = iterator.next();
		}
		driver.switchTo().window(subWindowHandler);

	}

}
