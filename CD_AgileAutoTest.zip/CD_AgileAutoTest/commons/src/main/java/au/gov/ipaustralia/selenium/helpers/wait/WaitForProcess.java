package au.gov.ipaustralia.selenium.helpers.wait;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;

import au.gov.ipaustralia.selenium.helpers.wait.exception.TimedOutException;



public class WaitForProcess {
	
    private static final Logger LOGGER = Logger.getLogger(WaitForProcess.class);
	/** driver for the target test browser */
	protected WebDriver driver;

	/** standard wait time for most time dependant functions */
	protected int timeout;
	
	/**
     * Waits while the PEGA 'busy' gif is displaying
     * 
     * @param waitSeconds
     *            the maximum time to wait (roughly)
     */
    protected void waitWhileBusy(int waitSeconds) {
        boolean showing = true;
        int noOfTries = waitSeconds * 2;
        for (int i = 0; i < noOfTries; i++) {
            WaitTool.sleep(500);
            try {
                if (driver.findElement(By.cssSelector("ul[role = 'progressbar']")).isDisplayed()) {
                    continue;
                }
            }
            catch (NoSuchElementException e) {
                LOGGER.info("No Such Element Present", e);
                showing = false;
                break;
            }
            catch (StaleElementReferenceException|JavascriptException s) {
                LOGGER.info("Stale Element or Java Exception", s);
                continue;
            }
       
        }
        if (showing) {
            throw new TimedOutException("Gif is still showing after " + timeout + " seconds");
        }
    }
	
}
