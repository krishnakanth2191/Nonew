package au.gov.ipaustralia.selenium.helpers.Attribute;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;



public class Attributes {
	

	/** driver for the target test browser */
	protected WebDriver driver;

	/** standard wait time for most time dependant functions */
	protected int timeout;
	
	/**
	 * Returns the id of the given webElement
	 * 
	 * @param webElement
	 * @return
	 */
	public String getId(WebElement webElement) {
		return webElement.getAttribute("id");
	}

	/**
	 * Returns the text value of the given webElement
	 * 
	 * @param webElement
	 * @return
	 */
	public String getText(WebElement webElement) {
		return webElement.getText();
	}
}
