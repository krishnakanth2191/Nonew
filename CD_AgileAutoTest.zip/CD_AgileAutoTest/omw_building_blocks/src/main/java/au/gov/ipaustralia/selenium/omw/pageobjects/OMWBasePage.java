package au.gov.ipaustralia.selenium.omw.pageobjects;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import au.gov.ipaustralia.automation.selenium.helpers.db.ATMOSSDBManager;

import au.gov.ipaustralia.automation.selenium.helpers.db.IPRDBManager;
import au.gov.ipaustralia.selenium.environment.EnvironmentVariables;
import au.gov.ipaustralia.selenium.helpers.wait.WaitTool;
import au.gov.ipaustralia.testng.helpers.BasePage;


/**
 * @author cpahan
 *
 */
public abstract class OMWBasePage extends BasePage {

    private static final Logger LOGGER = Logger.getLogger(OMWBasePage.class);
    private String homeUrl;

    @FindBy(id = "loading.srs")
    @CacheLookup
    private WebElement loadingGif;

    public OMWBasePage() {
        super();
        setHomeUrl(EnvironmentVariables.getConfiguredItem("OMW", "home_url"));
    }

    public OMWBasePage(WebDriver driver) {
        super(driver);
        setHomeUrl(EnvironmentVariables.getConfiguredItem("OMW", "home_url"));
    }

    /**
     * Navigate back to the OMW home page from anywhere in the app
     * 
     */

    public void openHomePage() {
        driver.get(homeUrl);
    }

   
 
    protected WebElement flash(WebElement element) {

        for (int i = 0; i < 3; i++) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].style.border='1px solid darkblue'", element);
            try {
                Thread.sleep(100);
            }
            catch (InterruptedException e) {
                LOGGER.log(Level.WARN, "Interrupted!", e);            
                Thread.currentThread().interrupt();

            }
            ((JavascriptExecutor) driver).executeScript("arguments[0].style.border='none'", element);
        }
        return element;
    }

    /**
     * Wrokaround for bug in Selenium built in drag & drop
     * 
     * @param source
     *            the WebElement to drag
     * @param offsetSource
     *            Point(x,y) worked out from the browser style offsets (or a good guess)
     * @param target
     *            the WebElement to drop on
     * @param offsetTarget
     *            Point(x,y) worked out from the browser style offsets (or a good guess)
     */
    protected void dragAndDrop(WebElement source,
                               WebElement target) {
        try {
            flash(target).click();
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", source);
            Robot robot = new Robot();
            robot.setAutoDelay(1000);

            robot.mouseMove(500, 500);

            Point sourceLocation = source.getLocation();
            int sourceX = sourceLocation.getX() + (source.getSize().width / 2);
            /*
             * Next line is a workaround to get the correct Y position for the 'Unallocated documents' on the Batch
             * Classification screen because of how images are displayed. May need to move this method to
             * BatchClassification page if this method is used elsewhere, and keep a more generic form here Works with
             * or without bottom menu bar displaying.
             */
            int sourceY = sourceLocation.getY() + (source.getSize().height) + 30;

            flash(source).click();

            robot.mouseMove(sourceX, sourceY);
            robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
            // move away from start position .. Selenium bug workaround
            robot.mouseMove(sourceLocation.getX() + 200, sourceLocation.getY() + 200);

            Point targetLocation = target.getLocation();
            int x = targetLocation.getX() + (target.getSize().width / 2);
            int y = targetLocation.getY() + (target.getSize().height / 2);
            robot.mouseMove(x, y);
            robot.delay(1000);
            robot.mouseRelease(InputEvent.BUTTON1_MASK);
            robot.delay(1000);
        }
        catch (AWTException e) {
            LOGGER.info("AWTException", e);
        }

    }

    protected String getIPRightNumberATMOSS(String key)  {
        String ipRightId = "";
        if (getData().containsKey(key)) {
            ipRightId = getData().get(key);
            Pattern px = Pattern.compile("\\{(.*)\\}");
            Matcher m = px.matcher(ipRightId);
            if (m.find()) {
                ipRightId = (new ATMOSSDBManager()).getIPRight(m.group(1)).getFirstDataItem().toString();
            }
        }
        return ipRightId;
    }

    protected String getIPRightNumberExcluded(String key)  {
        String ipRightId = "";
        if (getData().containsKey(key)) {
            ipRightId = getData().get(key);
            Pattern px = Pattern.compile("\\{(.*)\\}");
            Matcher m = px.matcher(ipRightId);
            if (m.find()) {
                ipRightId = (new IPRDBManager()).getExcluded(m.group(1)).getFirstDataItem().toString();
            }
        }
        return ipRightId;
    }

    /**
     * Waits for any loading gifs to disappear
     * 
     */
    protected void waitWhileOMWBusy() {
        waitWhileOMWBusy(timeout);

    }

    protected void waitWhileOMWBusy(int waitSeconds) {
        WaitTool.sleep(1000);
        int noOfTries = waitSeconds * 4;

        for (int i = 0; i < noOfTries; i++) {
            try {
                List<WebElement> listLoad = driver.findElements(By.xpath("//img[contains(@src, 'loader.gif')]"));
                if (listLoad.isEmpty()) {
                    break;
                }
                boolean displayed = false;
                for (WebElement _element : listLoad) {
                    if (_element.isDisplayed()) {
                        displayed = true;
                        break;
                    }
                }
                if (displayed) {
                    WaitTool.sleep(250);
                    continue;
                }
                else {
                    break;
                }
            }
            catch (NoSuchElementException e) {
                break;
            }
            catch (StaleElementReferenceException s) {
                continue;
            }
        }
    }

    /**
     * VerifyTables that the page loaded completely.
     * 
     * @param pageLoadedText
     *            expected text
     * @return true if page has loaded
     */
    public boolean verifyPageLoaded(final String pageLoadedText) {
        (new WebDriverWait(driver, timeout)).until(new ExpectedCondition<Boolean>() {
            @Override
            public Boolean apply(WebDriver d) {
                return d.getPageSource().contains(pageLoadedText);
            }
        });
        return true;
    }

    /**
     * VerifyTables that current page URL matches the expected URL.
     *
     * @return true if page url verified
     */
    public boolean verifyPageUrl(final String pageUrl) {
        (new WebDriverWait(driver, timeout)).until(new ExpectedCondition<Boolean>() {
            @Override
            public Boolean apply(WebDriver d) {
                return d.getCurrentUrl().contains(pageUrl);
            }
        });
        return true;
    }

    /**
     * @return the test data key,value map
     */
    @Override
    public Map<String, String> getData() {
        return data;
    }

    /**
     * test data key,value map
     * 
     * @param data
     *            test data map
     */
    @Override
    public void setData(Map<String, String> data) {
        this.data = data;
    }

    /**
     * 
     * @return AUT timeout in seconds
     */
    @Override
    public int getTimeout() {
        return timeout;
    }

    /**
     * Sets the AUT timeout value
     * 
     * @param timeout
     *            seconds
     */
    @Override
    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }

    /**
     * @return the OMW home page url
     */
    public String getHomeUrl() {
        return homeUrl;
    }

    /**
     * Sets the OMW home page url for the target environment
     * 
     * @param homeUrl
     *            url string
     */

    public void setHomeUrl(String homeUrl) {
    	
        this.homeUrl = homeUrl;
    }

}
