package au.gov.ipaustralia.selenium.omw.pageobjects;

import static org.assertj.core.api.Assertions.assertThat;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import au.gov.ipaustralia.selenium.helpers.wait.WaitTool;

public class BatchProcesswithSRs extends OMWBasePage {

    private static final String PAGE_LOADED_TEXT = "Batch";
    private static final String PAGE_URL = "/workbench-ui/secure/path/batch.xhtml?taskId=";
    @FindBy(id = "sroptions-form:complete-button")
    private WebElement complete;

    @FindBy(id = "completion-popup_container")
    private WebElement completePopup;

    @FindBy(id = "completion-result-form:completion-result-popup_container")
    private WebElement returnPopup;

    @FindBy(id = "complete-button")
    private WebElement popupComplete;

    // @FindBy(name = "completion-result-form:j_idt1244")
    // @FindBy(xpath = "//input[contains(@value, 'Return to task list')]")
    @FindBy(css = "input[value = 'Return to task list']")
    private WebElement popupReturnToTaskList;

    @FindBy(id = "batch-form:batchPanelBatchIdValue")
    private WebElement srBatchID;

    @FindBy(id = "sr-form:serviceRequestTable:0:serviceRequestTableOpenSRLink")
    private WebElement srRequestIDRow1;

    @FindBy(id = "sr-form:serviceRequestTable:0:serviceRequestTableBLCodeValue")
    private WebElement businessLineRow1;

    @FindBy(id = "sr-form:serviceRequestTable:0:serviceRequestTableSRCodeValue")
    private WebElement srCodeRow1;

    @FindBy(id = "sr-form:serviceRequestTable:0:sr-components-table:0:sr-components-table-ip-right-id-link")
    private WebElement ipRightNumberRow1;

    @FindBy(
            id = "sr-form:serviceRequestTable:0:sr-components-table:0:sr-components-table-fee-table:0:fee-table-fee-code-link")
    private WebElement feeCodeRow1;

    @FindBy(
            id = "sr-form:serviceRequestTable:0:sr-components-table:0:sr-components-table-fee-table:0:fee-table-fee-amt-value")
    private WebElement feeAmountRow1;

    public BatchProcesswithSRs() {
    }

    public BatchProcesswithSRs(WebDriver driver) {
        this();
        this.driver = driver;
        assertThat(verifyPageLoaded()).as("Batch Process with SR page is loaded").isTrue();
        assertThat(verifyPageUrl()).as("Batch Process with SR page URL is verified").isTrue();
    }

    public BatchProcesswithSRs clickCompleteButton() {
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(complete));
        complete.click();
        return this;
    }

    public BatchProcesswithSRs clickPopupCompleteButton() {
        flash(popupComplete).click();
        return this;
    }

    public BatchProcesswithSRs clickPopupReturnToTaskList() {
        flash(popupReturnToTaskList).click();
        waitWhileOMWBusy();
        WaitTool.sleep(5000);
        return this;
    }

    public BatchProcesswithSRs waitForCompletePopup() {
        waitWhileOMWBusy();
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.textToBePresentInElement(completePopup,
                                                                                               "Complete Classification"));
        return this;
    }

    public BatchProcesswithSRs waitForReturnPopup() {
        waitWhileOMWBusy();
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.textToBePresentInElement(returnPopup, "Results"));
        return this;
    }

    /**
     * VerifyTables that the page loaded completely.
     *
     * @return boolean
     */
    public boolean verifyPageLoaded() {
        return verifyPageLoaded(PAGE_LOADED_TEXT);
    }

    /**
     * VerifyTables that current page URL matches the expected URL.
     *
     * @return boolean
     */
    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

    /**
     * VerifyTables that the actual Business Line matches the expected Business Line in Row 1.
     *
     * @return boolean
     */
    public boolean verifyBusinessLineRow1(String businessLine) {
        String businessLineNew = businessLine;

        boolean result = false;
        if (businessLineRow1.getText().equals(businessLineNew)) {
            result = true;
        }

        return result;
    }

    /**
     * VerifyTables that the actual SR Code matches the expected SR Code in Row 1.
     *
     * @return boolean
     */
    public boolean verifySRCodeRow1(String srCode) {
        String srCodeNew = srCode;

        boolean result = false;
        if (srCodeRow1.getText().equals(srCodeNew)) {
            result = true;
        }

        return result;
    }

    /**
     * VerifyTables that the actual Fee Code matches the expected Fee Code in Row 1.
     *
     * @return boolean
     */
    public boolean verifyFeeCodeRow1(String feeCode) {
        String feeCodeNew = feeCode;

        boolean result = false;
        if (feeCodeRow1.getText().equals(feeCodeNew)) {
            result = true;
        }

        return result;
    }

    /**
     * VerifyTables that the actual Fee Amount matches the expected Fee Amount in Row 1.
     *
     * @return boolean
     */
    public boolean verifyFeeAmountRow1(String feeAmount) {
        String feeAmountNew = feeAmount;

        boolean result = false;
        if (feeAmountRow1.getText().equals(feeAmountNew)) {
            result = true;
        }

        return result;
    }

    public boolean verifyBatchID(String newBatchID) {

        boolean result = false;
        if (srBatchID.getText().equals(newBatchID)) {
            result = true;
        }

        return result;
    }

}
