package au.gov.ipaustralia.selenium.omw.pageobjects;

import static org.assertj.core.api.Assertions.assertThat;
import org.apache.log4j.Logger;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import au.gov.ipaustralia.selenium.environment.EnvironmentVariables;



public class HomeTask extends OMWBasePage {
	
	private static final Logger LOGGER = Logger.getLogger(HomeTask.class);



    /* Used in Test Case */
    @FindBy(css = "a[href='index.xhtml'")
    @CacheLookup
    private WebElement homeIconLink;

    @FindBy(css = "a[href='createbatch.xhtml']")
    @CacheLookup
    private WebElement createBatch;

    @FindBy(css = "#task a.image-link")
    @CacheLookup
    private WebElement task;
    
    @FindBy(id = "batchIdIdntifier")
	@CacheLookup
	private WebElement batchId;
    
    @FindBy(id = "tableform:tasktable:task-table-batch-id-filter-fld")
    private WebElement batchIdTextBox;
    
    @FindBy(id = "task-list-task-stats-form:task-stats-panel-clear-filters-link")
	@CacheLookup
	private WebElement clearFilters;
    
    @FindBy(id = "taskListTableRow1Identifier")
	@CacheLookup
	private WebElement taskListTableRow1;
    
    @FindBy(css = "img[id = 'task-table-assign-to-me-img']")
	private WebElement assignToMeRow1;
    
    @FindBy(id = "tableform:tasktable:tb")
    private WebElement taskResultRow;

    private static final String PAGE_LOADED_TEXT = "Build date:";

    private static final String PAGE_URL = EnvironmentVariables.getConfiguredItem("OMW", "home_url");


    public HomeTask(WebDriver driver) {
        super(driver);
        driver.get(getHomeUrl());
        openHomePage();
        assertThat(verifyPageLoaded()).as("Home page is loaded").isTrue();
        assertThat(verifyPageUrl()).as("Home page URL is verified").isTrue();
       }
    
  /**
	 * This method is to identify Batch id header field. Enter batch id into batch id header field. Press keyboard tab
	 *
	 * @return the OMW_TaskList class instance.
	 */
	public HomeTask filterByBatchIdAndOpenBatch(String id) {
		
		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(batchIdTextBox));
		LOGGER.info("Batch ID no: " +id);
		batchIdTextBox.clear();
		batchIdTextBox.sendKeys(id);
		batchIdTextBox.sendKeys(Keys.TAB);
		
		LOGGER.info(" Searched for Batch ID ");
		
		if(taskResultRow.isDisplayed())
			LOGGER.info("Search Results Displayed. ");
		else {
			LOGGER.error("Search Results Displayed. ");
			assertThat(taskResultRow.isDisplayed()).isTrue();
		}
		
		return this;
	}
	
	/**
	 * This method is to Clicking on Assign to me and start work
	 *
	 * @return the OMW_TaskList class instance.
	 */
	public HomeTask clickAssignToMe() {
		// Clicking on Assign to me and start work
		
		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(assignToMeRow1));
		assignToMeRow1.click();
		LOGGER.info(" Clicked on Assign to me and start work ");
		
		return this;
	}
    
    
   
    
    /**
     * VerifyTables that the page loaded completely.
     *
     * @return boolean.
     */
    public boolean verifyPageLoaded() {
        return verifyPageLoaded(PAGE_LOADED_TEXT);
    }

    /**
     * VerifyTables that current page URL matches the expected URL.
     *
     * @return boolean True (Verified URL), False (unverified URL)..
     */
    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }
}
