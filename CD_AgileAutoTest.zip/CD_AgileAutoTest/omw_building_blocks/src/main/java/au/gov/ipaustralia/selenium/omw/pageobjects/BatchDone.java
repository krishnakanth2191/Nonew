package au.gov.ipaustralia.selenium.omw.pageobjects;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BatchDone extends OMWBasePage {

    private static final String PAGE_LOADED_TEXT = "Recording Batch Data Completed";
    private static final String PAGE_URL = "/workbench-ui/secure/path/recordbatchdata.xhtml?taskId=";

    @FindBy(id = "completed-popup-form:completed-panel")
    @CacheLookup
    private WebElement completedData;

    @FindBy(name = "completed-popup-form:completed-popup-done-button")
    @CacheLookup
    private WebElement done;

    public BatchDone(WebDriver driver) {
        super();
        this.driver = driver;
        assertThat(verifyPageLoaded()).as("Batch Done page is loaded").isTrue();
        assertThat(verifyPageUrl()).as("Batch Done page URL is verified").isTrue();
    }

    /**
     * Click on Done Button.
     *
     * @return the OMW_BatchDone class instance.
     */
    public BatchDone clickDoneButton() {
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(done));
        done.click();
        return this;
    }

    public String extractNewBatchID() {
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(completedData));
        String source = completedData.getText();
        String pattern = "The Batch has been created with identifier (.*) and the data";

        Pattern px = Pattern.compile(pattern);
        Matcher m = px.matcher(source);
        if (m.find()) {
            return m.group(1);
        }
        else {
            return "";
        }
    }

    /**
     * VerifyTables that the page loaded completely.
     *
     * @return boolean
     */
    public boolean verifyPageLoaded() {
        return verifyPageLoaded(PAGE_LOADED_TEXT);

    }

    /**
     * VerifyTables that current page URL matches the expected URL.
     *
     * @return boolean
     */
    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);

    }

}
