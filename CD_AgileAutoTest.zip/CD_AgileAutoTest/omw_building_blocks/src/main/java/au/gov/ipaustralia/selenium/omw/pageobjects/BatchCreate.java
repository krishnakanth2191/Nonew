package au.gov.ipaustralia.selenium.omw.pageobjects;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import au.gov.ipaustralia.selenium.environment.EnvironmentVariables;


public class BatchCreate extends OMWBasePage {

    private static final String PAGE_LOADED_TEXT = "Record Batch Data";
    private static final Logger LOGGER = Logger.getLogger(BatchCreate.class);
    private static final String PAGE_URL = "/workbench-ui/secure/path/recordbatchdata.xhtml";

    @FindBy(id = "batchinfo-form:channeled-field")
    @CacheLookup
    private WebElement channel;

    @FindBy(id = "batchinfo-form:custref-field")
    @CacheLookup
    private WebElement customerReference;

    @FindBy(xpath = ".//*[@id='batchinfo-form:batchinfo-panel-comments-panel']/textarea")
    @CacheLookup
    private WebElement comments;

    @FindBy(css = "span.rf-fu-btn-add > span")
    private WebElement addFile;

    @FindBy(css = "span.rf-fu-btn-upl > span")
    private WebElement uploadFile;

    @FindBy(id = "batchinfo-form:customerIdName-fld")
    private WebElement customerType;
    // Customer details
    @FindBy(id = "batchinfo-form:customerId-fld")
    @CacheLookup
    private WebElement ipaCustomerId;

    @FindBy(id = "batchinfo-form:searchparty-button")
    @CacheLookup
    private WebElement searchCustomers;

    @FindBy(id = "batchinfo-form:innercustomer-panel-selected-party-panel-change-link")
    @CacheLookup
    private WebElement changeCustomer;

    // Payment details
    @FindBy(id = "batchinfo-form:paymenttype-field")
    @CacheLookup
    private WebElement paymentType;

    @FindBy(id = "batchinfo-form:paymentamt-field")
    @CacheLookup
    private WebElement amount;

    @FindBy(id = "batchinfo-form:eftpayer-field")
    @CacheLookup
    private WebElement payerName;

    @FindBy(id = "batchinfo-form:eftreference-field")
    @CacheLookup
    private WebElement eftReference;

    // allocate Funds
    @FindBy(xpath = "//label[contains(text(), 'Designs')]/following-sibling::input[@class= 'alloc-code-input']")
    @CacheLookup
    private WebElement designsFunds;

    @FindBy(xpath = "//label[contains(text(), 'Designs')]/following-sibling::input[@type = 'checkbox']")
    // @CacheLookup
    private WebElement designsDocumentsOnly;

    @FindBy(xpath = "//label[contains(text(), 'Trade Marks')]/following-sibling::input[@class= 'alloc-code-input']")
    @CacheLookup
    private WebElement tradeMarksFunds;

    @FindBy(xpath = "//label[contains(text(), 'Trade Marks')]/following-sibling::input[@type = 'checkbox']")
    // @CacheLookup
    private WebElement tradeMarksDocumentsOnly;

    // Navigate Buttons
    @FindBy(id = "batchinfo-form:createreceipt-button")
    @CacheLookup
    private WebElement createReceiptAndContinue;

    @FindBy(id = "batchinfo-form:cancelbatch-button")
    @CacheLookup
    private WebElement cancelBatch;

    public BatchCreate(WebDriver driver) {
        super(driver);
        assertThat(verifyPageLoaded()).as("Batch Create page is loaded").isTrue();
        assertThat(verifyPageUrl()).as("Batch Create page URL is verified").isTrue();
    }

    /**
     * Add a document from the File Upload dialog and upload it keys; FILE_PATh and FILE_NAMES (a ';' delineated list of
     * files to upload
     * 
     * 
     * @return {@link BatchCreate}
     */
    public BatchCreate addAndUploadFiles() {
        String path = "";
        String[] fileNames;
        int firstUploadIndex = 0;

        if (getData().containsKey("FILE_PATH")) {
            path = getData().get("FILE_PATH");
        }
        

        if (!getDataValue("IMAGE_FILE_NAMES").trim().equals("")) {
            fileNames = getData().get("IMAGE_FILE_NAMES").split(";");
            firstUploadIndex = fileNames.length - 1;
            addAndUploadFiles(path, fileNames, 0);

        }

        if (!getDataValue("OTHER_FILE_NAMES").trim().equals("")) {
            fileNames = getData().get("OTHER_FILE_NAMES").split(";");
            addAndUploadFiles(path, fileNames, firstUploadIndex);
        }
        return this;

    }

    public BatchCreate addAndUploadFiles(String filePath,
                                         String[] fileNames) {
        return addAndUploadFiles(filePath, fileNames, 0);
    }

    public BatchCreate addAndUploadFiles(String filePath,
                                         String[] fileNames,
                                         int noOfExistingFiles) {
        int index = fileNames.length - 1 + noOfExistingFiles;
        LOGGER.info(filePath);
        for (int i = 0; i < fileNames.length; i++) {
            (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(addFile));
            addFile.click();

        }
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(uploadFile));
        uploadFile.click();

        String lastUuploadedId = "batchinfo-form:batchdocuments-table:" + index;
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(driver.findElement(By.id(lastUuploadedId))));

        return this;
    }

    /**
     * Click on Cancel Batch Button.
     *
     * @return the OMW_CreateBatch class instance.
     */
    public BatchCreate clickCancelBatchButton() {
        cancelBatch.click();
        return this;
    }

    /**
     * Click on Create Receipt And Continue Button.
     *
     * @return the OMW_CreateBatch class instance.
     */
    public BatchCreate clickCreateReceiptAndContinueButton() {
        createReceiptAndContinue.click();
        waitWhileOMWBusy();
        return this;
    }

    /**
     * Click on Search Customers Button.
     *
     * @return the OMW_CreateBatch class instance.
     */
    public BatchCreate clickSearchCustomersButton() {
        searchCustomers.click();
        return this;
    }

    /**
     * Fill every fields in the page.
     *
     * @return the OMW_CreateBatch class instance.
     */
    public BatchCreate fill() {

        setChannelDropDownListField();
        setCustomerReferenceTextField();
        setCommentsTextareaField();

        addAndUploadFiles();

        selectCustomerType("IPA Customer ID");
        setCustomerIdTextField();
        clickSearchCustomersButton();
        waitForChangeCustomerLink();

        setPaymentTypeDropDownListField();
        setAmountTextField();
        setPayerNameTextField();
        setEftReferenceTextField();

        setDesignsAllocateFunds();

        return this;
    }

    public BatchCreate fillTradeMark(String customerBatchRef,
                                     String paymentAmount) {
        setChannelDropDownListField("PAPER");
        setCustomerReferenceTextField(customerBatchRef);

        


        selectCustomerType("IPA Customer ID");
        String custID = EnvironmentVariables.getConfiguredItem("OMW", "customer-id");
        setCustomerIdTextField(custID);
        clickSearchCustomersButton();
        waitForChangeCustomerLink();

        setPaymentTypeDropDownListField("Electronic Funds Transfer");
        setAmountTextField(paymentAmount);
        setPayerNameTextField("AutoTest");
        setEftReferenceTextField("AutoTest");

        setTradeMarkAllocateFunds(paymentAmount);

        return this;

    }

    public BatchCreate selectCustomerType(String visibleText) {
        (new Select(customerType)).selectByVisibleText(visibleText);
        return this;
    }

    /**
     * Set default value to Amount Text field. key AMOUNT
     *
     * @return the OMW_CreateBatch class instance.
     */
    public BatchCreate setAmountTextField() {
        if (getData().containsKey("AMOUNT")) {
            return setAmountTextField(getData().get("AMOUNT"));
        }
        else {
            return this;
        }
    }

    /**
     * Set value to Amount Text field.
     * 
     * @param amountValue
     *            ...
     *
     * @return the {@link BatchCreate} class instance.
     */
    public BatchCreate setAmountTextField(String amountValue) {
        amount.sendKeys(amountValue);
        return this;
    }

    /**
     * Set default value to Channel Drop Down List field. key CHANNEL
     *
     * @return the OMW_CreateBatch class instance.
     */
    public BatchCreate setChannelDropDownListField() {
        if (getData().containsKey("CHANNEL")) {
            return setChannelDropDownListField(getData().get("CHANNEL"));
        }
        else {
            return setChannelDropDownListField("PAPER");
        }
    }

    /**
     * Set value to Channel Drop Down List field.
     * 
     * @param channelValue
     *            ...
     *
     * @return the OMW_CreateBatch class instance.
     */
    public BatchCreate setChannelDropDownListField(String channelValue) {
        new Select(channel).selectByVisibleText(channelValue);
        return this;
    }

    /**
     * Set default value to Comments Textarea field. key COMMENTS
     *
     * @return the OMW_CreateBatch class instance.
     */
    public BatchCreate setCommentsTextareaField() {
        if (getData().containsKey("COMMENTS")) {
            return setCommentsTextareaField(getData().get("COMMENTS"));
        }
        else {
            return this;
        }

    }

    /**
     * Set value to Comments Textarea field.
     * 
     * @param commentsValue
     *            ...
     *
     * @return the OMW_CreateBatch class instance.
     */
    public BatchCreate setCommentsTextareaField(String commentsValue) {
        comments.sendKeys(commentsValue);
        return this;
    }

    /**
     * Set default value to Customer Reference Text field. key CUSTOMER_REFERENCE
     *
     * @return the OMW_CreateBatch class instance.
     */
    public BatchCreate setCustomerReferenceTextField() {
        if (getData().containsKey("CUSTOMER_REFERENCE")) {
            return setCustomerReferenceTextField(getData().get("CUSTOMER_REFERENCE"));
        }
        else {
            return this;
        }
    }

    /**
     * Set value to Customer Reference Text field.
     *
     * @param customerReferenceValue
     *            ...
     *
     * @return the {@link BatchCreate} class instance.
     */
    public BatchCreate setCustomerReferenceTextField(String customerReferenceValue) {
        customerReference.sendKeys(customerReferenceValue);
        return this;
    }

    /**
     * Set Designs allocate funds text field to DESIGNS_FUNDS test data otherwise checks the 'Documnets Only' checkbox
     *
     * @return the OMW_CreateBatch class instance.
     */
    public BatchCreate setDesignsAllocateFunds() {
        if (getData().containsKey("DESIGNS_FUNDS")) {
            return setDesignsAllocateAmmount(getData().get("DESIGNS_FUNDS"));
        }
        else {
            return setDesignsDocumentsOnlyCheckbox();
        }
    }

    /**
     * Set Designs allocate funds text field
     *
     * @param designsValue
     *            ...
     *
     * @return the OMW_CreateBatch class instance.
     */
    public BatchCreate setDesignsAllocateAmmount(String designsValue) {
        designsFunds.sendKeys(designsValue);
        return this;
    }

    /**
     * Set Designs Documents Only Checkbox field.
     *
     * @return the OMW_CreateBatch class instance.
     */
    public BatchCreate setDesignsDocumentsOnlyCheckbox() {
        WebDriverWait waitFor = new WebDriverWait(driver, timeout);
        waitFor.pollingEvery(1, TimeUnit.SECONDS).ignoring(StaleElementReferenceException.class);
        waitFor.until(ExpectedConditions.elementToBeClickable(designsDocumentsOnly));
        if (!designsDocumentsOnly.isSelected()) {
            designsDocumentsOnly.click();
        }
        return this;
    }

    /**
     * Set default value to Eft Reference Text field. key EFT_REFERENCE
     *
     * @return the OMW_CreateBatch class instance.
     */
    public BatchCreate setEftReferenceTextField() {
        if (getData().containsKey("EFT_REFERENCE")) {
            return setEftReferenceTextField(getData().get("EFT_REFERENCE"));
        }
        else {
            return this;
        }
    }

    /**
     * Set value to Eft Reference Text field.
     * 
     * @param eftReferenceValue
     *            ...
     *
     * @return the OMW_CreateBatch class instance.
     */
    public BatchCreate setEftReferenceTextField(String eftReferenceValue) {
        eftReference.sendKeys(eftReferenceValue);
        return this;
    }

    /**
     * Set default value to Ipa Customer Id Text field. key CUSTOMER_ID
     *
     * @return the OMW_CreateBatch class instance.
     */
    public BatchCreate setCustomerIdTextField() {
        if (getData().containsKey("CUSTOMER_ID")) {
            String custId = getData().get("CUSTOMER_ID");
            Pattern px = Pattern.compile("\\{(.*)\\}");
            Matcher m = px.matcher(custId);
            if (m.find()) {
                custId = EnvironmentVariables.getConfiguredItem("OMW", m.group(1));
            }
            return setCustomerIdTextField(custId);

        }
        else {
            return this;
        }
    }

    /**
     * Set value to Ipa Customer Id Text field.
     * 
     * @param ipaCustomerIdValue
     *            ...
     *
     * @return the OMW_CreateBatch class instance.
     */
    public BatchCreate setCustomerIdTextField(String ipaCustomerIdValue) {
        (new WebDriverWait(driver, timeout)).until(new ExpectedCondition<Boolean>() {
            @Override
            public Boolean apply(WebDriver d) {
                return ipaCustomerId.isEnabled();
            }
        });

        ipaCustomerId.sendKeys(ipaCustomerIdValue);
        return this;
    }

    /**
     * Set default value to Payer Name Text field. key PAYER_NAME
     *
     * @return the OMW_CreateBatch class instance.
     */
    public BatchCreate setPayerNameTextField() {
        if (getData().containsKey("PAYER_NAME")) {
            return setPayerNameTextField(getData().get("PAYER_NAME"));
        }
        else {
            return this;
        }
    }

    /**
     * Set value to Payer Name Text field.
     * 
     * @param payerNameValue
     *            ...
     *
     * @return the OMW_CreateBatch class instance.
     */
    public BatchCreate setPayerNameTextField(String payerNameValue) {
        payerName.sendKeys(payerNameValue);
        return this;
    }

    /**
     * Set default value to Payment Type Drop Down List field. key PAYMENT_TYPE
     *
     * @return the OMW_CreateBatch class instance.
     */
    public BatchCreate setPaymentTypeDropDownListField() {
        if (getData().containsKey("PAYMENT_TYPE")) {
            return setPaymentTypeDropDownListField(getData().get("PAYMENT_TYPE"));
        }
        else {
            return this;
        }
    }

    /**
     * Set value to Payment Type Drop Down List field.
     * 
     * @param paymentTypeValue
     *            ...
     *
     * @return the OMW_CreateBatch class instance.
     */
    public BatchCreate setPaymentTypeDropDownListField(String paymentTypeValue) {
        new Select(paymentType).selectByVisibleText(paymentTypeValue);
        waitWhileOMWBusy();
        return this;
    }

    /**
     * Set default value to Trade Marks Text field. key TRADE_MARK_FUNDS else sets the 'Documents Only' checkbox
     *
     * @return the OMW_CreateBatch class instance.
     */
    public BatchCreate setTradeMarkAllocateFunds() {
        if (getData().containsKey("TRADE_MARK_FUNDS")) {
            return setTradeMarkAllocateFunds(getData().get("TRADE_MARK_FUNDS"));
        }
        else {
            return setTradeMarksDocumentsOnlyCheckboxField();
        }
    }

    /**
     * Set Trade Marks alocate funds field.
     * 
     * @param tradeMarksValue
     *            ...
     *
     * @return the OMW_CreateBatch class instance.
     */
    public BatchCreate setTradeMarkAllocateFunds(String tradeMarksValue) {
        (new WebDriverWait(driver, timeout)).until(new ExpectedCondition<Boolean>() {
            @Override
            public Boolean apply(WebDriver d) {
                return tradeMarksFunds.isEnabled();
            }
        });
        tradeMarksFunds.sendKeys(tradeMarksValue);
        return this;
    }

    /**
     * Set Trade Marks Checkbox field.
     *
     * @return the OMW_CreateBatch class instance.
     */
    public BatchCreate setTradeMarksDocumentsOnlyCheckboxField() {
        WebDriverWait elemetWait = new WebDriverWait(driver, timeout);
        elemetWait.pollingEvery(1, TimeUnit.SECONDS).ignoring(StaleElementReferenceException.class);
        elemetWait.until(ExpectedConditions.elementToBeClickable(tradeMarksDocumentsOnly));
        if (!tradeMarksDocumentsOnly.isSelected()) {
            tradeMarksDocumentsOnly.click();
        }
        return this;
    }

    /**
     * VerifyTables that the page loaded completely.
     *
     * @return the OMW_CreateBatch class instance.
     */
    public boolean verifyPageLoaded() {
        return verifyPageLoaded(PAGE_LOADED_TEXT);

    }

    /**
     * VerifyTables that current page URL matches the expected URL.
     *
     * @return boolean
     */
     public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);

    }

    /**
     * Waits for the Change Customer link top display after a search
     *
     * @return boolean
     */

    public BatchCreate waitForChangeCustomerLink() {
        (new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(changeCustomer));
        return this;

    }

}
