package au.gov.ipaustralia.selenium.omw.pageobjects;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import au.gov.ipaustralia.selenium.helpers.wait.WaitTool;

public class TaskList extends OMWBasePage {

	private static final Logger LOGGER = Logger.getLogger(TaskList.class);
	private static String pageLoadedText = "Task List";

	private static String pageUrl = "/workbench-ui/secure/path/tasks.xhtml";

	private static String batchIdIdntifier = "tableform:tasktable:task-table-batch-id-filter-fld";

	private static String taskListTableRow1Identifier = "tableform:tasktable:0";

	@FindBy(id = "tableform:tasktable:j_idt104")
	@CacheLookup
	private WebElement assignInHeader;

	@FindBy(xpath = "//*[@title= 'Assign to me and start work']")
	private WebElement assignToMeRow1;

	@FindBy(css = "tr#tableform:tasktable:1 td a")
	@CacheLookup
	private WebElement assignToMeRow2;

	@FindBy(id = "task-list-task-stats-form:task-stats-panel-clear-filters-link")
	@CacheLookup
	private WebElement clearFilters;

	@FindBy(css = "a[href='/workbench-ui/secure/createbatch.xhtml']")
	@CacheLookup
	private WebElement createBatch;

	@FindBy(id = "batchIdIdntifier")
	@CacheLookup
	private WebElement batchId;

	@FindBy(id = "tableform:tasktable:j_idt")
	@CacheLookup
	private WebElement taskType;

	@FindBy(id = "tableform:tasktable:j_idt")
	@CacheLookup
	private WebElement status;

	@FindBy(id = "tableform:tasktable:j_idt")
	@CacheLookup
	private WebElement assignee;

	@FindBy(id = "tableform:tasktable:j_idt")
	@CacheLookup
	private WebElement receivedDate;

	@FindBy(id = "tableform:tasktable:j_idt")
	@CacheLookup
	private WebElement channel;

	@FindBy(id = "taskListTableRow1Identifier")
	@CacheLookup
	private WebElement taskListTableRow1;

	@FindBy(id = "tableform:tasktable:1")
	@CacheLookup
	private WebElement taskListTableRow2;

	public TaskList(WebDriver driver) {
		super(driver);
	}

	/**
	 * Click on Clear Filters Link.
	 *
	 * @return the OMW_TaskList class instance.
	 */
	public TaskList clickClearFiltersLink() {
		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(batchId));
		batchId.clear();
		batchId.sendKeys("Syncronising..");
		(new WebDriverWait(driver, timeout * 2)).until(ExpectedConditions.elementToBeClickable(clearFilters));
		clearFilters.click();
		waitWhileOMWBusy();

		// ugly hack to sync clear filter ....
		WebDriverWait waitFor = new WebDriverWait(driver, timeout * 2);
		waitFor.pollingEvery(5, TimeUnit.SECONDS);
		waitFor.ignoring(org.openqa.selenium.StaleElementReferenceException.class);
		waitFor.until(new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver d) {
				batchId = d.findElement(By.id(batchIdIdntifier));
				return batchId.getAttribute("value").equals("");
			}
		});
		// push freshest to driver
		batchId = driver.findElement(By.id(batchIdIdntifier));
		return this;
	}

	/**
	 * Click on Create Batch Link.
	 *
	 * @return the OMW_TaskList class instance.
	 */
	public TaskList clickCreateBatchLink() {
		createBatch.click();
		return this;
	}

	/**
	 * Set value to Batch Id Text field and TABs to the next field to trigger
	 * filtering.
	 * 
	 * @param batchIdValue
	 *            ...
	 *
	 * @return the OMW_TaskList class instance.
	 */
	public TaskList setBatchIdTextField(String batchIdValue) {
		(new WebDriverWait(driver, timeout * 2)).until(ExpectedConditions.elementToBeClickable(batchId));
		batchId.sendKeys(batchIdValue + Keys.TAB);
		waitWhileOMWBusy();
		return this;
	}

	/**
	 * Set value to task type Drop Down List field.
	 * 
	 * @param taskTypeValue
	 *            ...
	 *
	 * @return the OMW_TaskList class instance.
	 */
	public TaskList setTaskTypeDropDownListField(String taskTypeValue) {
		new Select(taskType).selectByVisibleText(taskTypeValue);
		return this;
	}

	public TaskList filterByBatchIdAndOpenBatch(String id) {
		final String finalId = id;

		clickClearFiltersLink();

		setBatchIdTextField(id);

		WebDriverWait waitFor = new WebDriverWait(driver, timeout * 4);
		waitFor.pollingEvery(5, TimeUnit.SECONDS);
		waitFor.ignoring(StaleElementReferenceException.class);
		waitFor.until(new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver d) {
				d.navigate().refresh();
				try {
					new WebDriverWait(driver, 10)
							.until(ExpectedConditions.elementToBeClickable(By.id(taskListTableRow1Identifier)));
				} catch (Exception e) {
					LOGGER.info(" Element not clickable", e);
				}

				taskListTableRow1 = d.findElement(By.id(taskListTableRow1Identifier));

				return taskListTableRow1.getText().contains(finalId);
			}
		});
		// push freshest to driver
		taskListTableRow1 = driver.findElement(By.id(taskListTableRow1Identifier));

		taskListTableRow1.click();
		WaitTool.sleep(500);

		for (int i = 1; i < 10; i++) {
			Boolean statusAssign = driver.findElements(By.xpath("//*[@title= 'Assign to me and start work']"))
					.size() > 0;
			if (statusAssign) {
				assignToMeRow1.click();
				WaitTool.sleep(5000); // Inconsistency in page loading
			} else {
				WaitTool.sleep(1000); // too quick for next step to get executed
										// just putting sleep no harm to this
				break;
			}
		}

		return this;
	}

	/**
	 * VerifyTables that the page loaded completely.
	 *
	 * @return boolean.
	 */
	public boolean verifyPageLoaded() {
		return verifyPageLoaded(pageLoadedText);
	}

	/**
	 * VerifyTables that current page URL matches the expected URL.
	 *
	 * @return boolean True (Verified URL), False (unverified URL)..
	 */
	public boolean verifyPageUrl() {
		return verifyPageUrl(pageUrl);
	}

}
