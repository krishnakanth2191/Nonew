package au.gov.ipaustralia.selenium.omw.pageobjects;

import static org.assertj.core.api.Assertions.assertThat;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



/**
 * Models the Record Batch Data page
 * 
 * @author Suman Kuchipudi - 15/11/2017
 *
 */



public class RecordBatchData extends OMWBasePage {

	private static final Logger LOGGER = Logger.getLogger(RecordBatchData.class);
	private static final String PAGE_URL = "/workbench-ui/secure/path/recordbatchdata.xhtml";
	private static final String PAGE_LOADED_TEXT = "Record Batch Data";
	private static final String VALUE_ATTRIBUTE = "value";

	

	@FindBy(id = "receivedfrom-field")
	private WebElement emailReceivedFrom;

	@FindBy(xpath = "//*[@id='batchdocuments-table:0:j_idt55']/a")
	private WebElement coverSheetPDF;

	@FindBy(id = "batchdocuments-table:1:j_idt55")
	private WebElement attachedIPRightsForm;

	@FindBy(id = "credit-panel-als-panel-payment-amt-fld")
	private WebElement amountPaid;

	@FindBy(id = "credit-panel-als-panel-card-holder-fld")
	private WebElement cardHolder;

	@FindBy(id = "credit-panel-als-panel-card-type-fld")
	private WebElement cardType;

	@FindBy(id = "cancelbatch-button")
	private WebElement cancelBatchButton;

	@FindBy(id = "cancel-batch-popup-form:cancelbatch-popup_container")
	private WebElement cancelBatchPopup;

	@FindBy(id = "cancel-batch-popup-form:cancel-batch-reason-field")
	private WebElement reasonTypeList;

	@FindBy(id = "cancel-batch-popup-form:cancelBatchPopupReasonTextFld")
	private WebElement reasonDescription;

	@FindBy(id = "cancel-batch-popup-form:cancelBatchPopupCancelAction")
	private WebElement cancelBatchButtonPopup;
	
	@FindBy(name = "j_idt53")
	private WebElement commentsTextBox;

	
	// Defining an explicit constructor
		public RecordBatchData(WebDriver driver) {
			super(driver);
		}
		
	/**
	 * This method is to verify that the Received From email address is correct.
	 *
	 * @return verifyReceivedFrom
	 */
	public RecordBatchData verifyReceivedFrom(String email) {
		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(attachedIPRightsForm));
		LOGGER.info(" Verifying Received From ");
		String checkEmail = emailReceivedFrom.getAttribute(VALUE_ATTRIBUTE);
		assertThat(checkEmail.equals(email)).isTrue();
		LOGGER.info(" Received From:  " + checkEmail);
		return this;
	}

	/**
	 * This method is to verify that the attachment 'IP Rights Form' in
	 * application is listed in Batch Documents table.
	 *
	 * @return verifyBatchDocumentAttachment
	 */
	public RecordBatchData verifyBatchDocumentAttachment() {

		LOGGER.info(" Verifying Batch Documents contains IP Rights Form ");
		
		assertThat(attachedIPRightsForm.isDisplayed()).isTrue();
		LOGGER.info(" Verified IP Rights Form is attached.  ");
		return this;
	}

	/**
	 * This method is to verify Credit Card Payment Information.
	 *
	 * @return verifyCreditCardPaymentInformation
	 */
	public RecordBatchData verifyCreditCardPaymentInformation(String amount, String holder, String type) {

		LOGGER.info(" Verifying Credit Card Payment Information ");

		// verifying amount paid
		assertThat((amountPaid.getAttribute(VALUE_ATTRIBUTE)).contains(amount)).isTrue();
		LOGGER.info(" Paid Amount:  " + amount);

		// verifying card holder
		assertThat((cardHolder.getAttribute(VALUE_ATTRIBUTE)).equals(holder)).isTrue();
		LOGGER.info(" Card Holder:  " + holder);

		// verifying card number
		assertThat((cardType.getAttribute(VALUE_ATTRIBUTE)).equals(type)).isTrue();
		LOGGER.info(" Card Type:  " + type);

		return this;
	}

	/**
	 * This method is to click on 'Cancel Batch' button.
	 *
	 * @return clickCancelBatchButton
	 */
	public RecordBatchData clickCancelBatchButton() {

		LOGGER.info(" Clicking on Cancel Branch Button ");
		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(cancelBatchButton));
		cancelBatchButton.click();
		

		return this;
	}

	/**
	 * This method is to input text into 'Reason Description' field.
	 *
	 * @return enterReasonDescription
	 */
	public RecordBatchData enterReasonDescription() {
		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(reasonDescription));
		LOGGER.info(" Entering reason text into 'Reason Description' field ");
		flash(reasonDescription).sendKeys("Automation Testing");
		return this;
	}

	/**
	 * This method is to click on 'Cancel Batch' button in cancel batch popup.
	 *
	 * @return clickCancelBatchPopup
	 */
	public RecordBatchData clickCancelBatchPopup() {
		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(cancelBatchButtonPopup));
		LOGGER.info(" Clicking on Cancel Branch Button ");
		flash(cancelBatchButtonPopup).click();
		return this;
	}

	/**
	 * This method is to verify the details in application match details in
	 * coversheet PDF .
	 *
	 * @return verifyBatchDocumentCoversheet
	 */
	public RecordBatchData verifyBatchDocumentCoversheet() {
		
		LOGGER.info(" Verifying Batch Documents contains coverheet.pdf ");
		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(coverSheetPDF));
		assertThat(coverSheetPDF.isDisplayed()).isTrue();
		
					// Storing parent window handle information	
					String parentHandle = driver.getWindowHandle();
					String pdfURL = "";
					
					coverSheetPDF.click();
					LOGGER.info("Before Window Handle ---------");
					// switch focus of WebDriver to the next found window handle (that's your newly opened window)
					for (String winHandle : driver.getWindowHandles()) {
						if(!winHandle.equals(parentHandle)){
							driver.switchTo().window(winHandle);
							driver.manage().window().maximize();
							LOGGER.info("Switched Driver Focus to Next window");
							pdfURL = driver.getCurrentUrl();
							LOGGER.error("CoverSheet PDF url: " +pdfURL);
							}
						}
					
					
					// Take screenshot of PDF file
					capture(driver, "OMWCoversheetPDF");
					
					// close newly opened window when done with it		
					driver.close(); 
					
					// Switching driver focus to parent window
					driver.switchTo().window(parentHandle); 
					LOGGER.info("Switched Driver Focus to Parent window");
					
					LOGGER.info("After Window Handle---------");
		
		return this;
	}


	
	/**
	 * VerifyTables that the page loaded completely.
	 *
	 * @return boolean True (Page Loaded), False (Page Not LoadedL).
	 */
	public boolean verifyPageLoaded() {
		return verifyPageLoaded(PAGE_LOADED_TEXT);

	}
	

	/**
	 * Verify that current page URL matches the expected URL.
	 *
	 * @return boolean True (Verified URL), False (unverified URL).
	 */
	public boolean verifyPageUrl() {
		return verifyPageUrl(PAGE_URL);
	}
}
