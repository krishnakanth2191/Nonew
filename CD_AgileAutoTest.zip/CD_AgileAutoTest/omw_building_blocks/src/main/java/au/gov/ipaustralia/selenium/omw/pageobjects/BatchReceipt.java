package au.gov.ipaustralia.selenium.omw.pageobjects;

import static org.assertj.core.api.Assertions.assertThat;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class BatchReceipt extends OMWBasePage {
    private static final String PAGE_LOADED_TEXT = "Send this receipt to the customer";
    private static final String PAGE_URL = "/workbench-ui/secure/path/recordbatchdata.xhtml?taskId=";

    @FindBy(id = "receipt-popup-form:createbatch-button")
    @CacheLookup
    private WebElement processBatch;

    public BatchReceipt(WebDriver driver) {
        super();
        this.driver = driver;
        assertThat(verifyPageLoaded()).as("Batch Receipt page is loaded").isTrue();
        assertThat(verifyPageUrl()).as("Batch Receipt page URL is verified").isTrue();
    }

    /**
     * Click on Process Batch Button.
     *
     * @return the OMW_BatchReceipt class instance.
     */
    public BatchReceipt clickProcessBatchButton() {
        processBatch.click();
        waitWhileOMWBusy();
        return this;
    }

    /**
     * VerifyTables that the page loaded completely.
     *
     * @return boolean
     */
    public boolean verifyPageLoaded() {
        return verifyPageLoaded(PAGE_LOADED_TEXT);
    }

    /**
     * VerifyTables that current page URL matches the expected URL.
     *
     * @return boolean
     */
    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

}
