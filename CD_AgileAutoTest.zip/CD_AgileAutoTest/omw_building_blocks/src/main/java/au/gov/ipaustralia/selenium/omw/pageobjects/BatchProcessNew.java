package au.gov.ipaustralia.selenium.omw.pageobjects;

import static org.assertj.core.api.Assertions.assertThat;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class BatchProcessNew extends OMWBasePage {

    private static final String PAGE_LOADED_TEXT = "No Service Requests exist for this batch";
    private static final String PAGE_URL = "/workbench-ui/secure/path/batch.xhtml?taskId=";

    // @FindBy(css = "a[href^='batchclassify.xhtml?taskId=']")
    @FindBy(id = "batchPanelOpenClassificationScreenLink")
    @CacheLookup
    private WebElement openClassificationScreen;

    public BatchProcessNew() {
    }

    public BatchProcessNew(WebDriver driver) {
        this();
        this.driver = driver;
        assertThat(verifyPageLoaded()).as("Batch Process New page is loaded").isTrue();
        assertThat(verifyPageUrl()).as("Batch Process New page URL is verified").isTrue();
    }

    /**
     * Click on Open Classification Screen Link.
     *
     * @return the OMW_NewBatch class instance.
     */
    public BatchProcessNew clickOpenClassificationScreenLink() {
        // direct navigation to the screen as the blank window in the AUT processs
        // does not allow the selenium driver to find the window
        // rem to use the driver.navigate().back() to return to this page
        String href = openClassificationScreen.getAttribute("href");
        driver.get(href);
        return this;
    }

    /**
     * VerifyTables that the page loaded completely.
     *
     * @return boolean
     */
    public boolean verifyPageLoaded() {
        return verifyPageLoaded(PAGE_LOADED_TEXT);
    }

    /**
     * VerifyTables that current page URL matches the expected URL.
     *
     * @return boolean
     */
    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }

}
