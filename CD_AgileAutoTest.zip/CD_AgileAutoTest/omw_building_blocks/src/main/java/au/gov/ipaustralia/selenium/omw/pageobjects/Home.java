package au.gov.ipaustralia.selenium.omw.pageobjects;

import static org.assertj.core.api.Assertions.assertThat;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

import au.gov.ipaustralia.selenium.environment.EnvironmentVariables;

public class Home extends OMWBasePage {

    /* Used in Test Case */
    @FindBy(css = "a[href='index.xhtml'")
    @CacheLookup
    private WebElement homeIconLink;

    @FindBy(css = "a[href='createbatch.xhtml']")
    @CacheLookup
    private WebElement createBatch;

    @FindBy(css = "#task a.image-link")
    @CacheLookup
    private WebElement task;

    private static final String PAGE_LOADED_TEXT = "Build date:";

    private static final String PAGE_URL = EnvironmentVariables.getConfiguredItem("OMW", "home_url");

    public Home() {
    }

    public Home(WebDriver driver) {
        super(driver);
        driver.get(getHomeUrl());
        openHomePage();
        assertThat(verifyPageLoaded()).as("Home page is loaded").isTrue();
        assertThat(verifyPageUrl()).as("Home page URL is verified").isTrue();
    }

    /**
     * Click on Create Batch Link.
     *
     * @return the OMW_Home class instance.
     */
    public Home clickCreateBatchLink() {
        createBatch.click();
        return this;
    }

    /**
     * Click on Task Link.
     *
     * @return the OMW_Home class instance.
     */
    public Home clickTaskLink() {
        task.click();
        return this;
    }

    /**
     * VerifyTables that the page loaded completely.
     *
     * @return boolean.
     */
    public boolean verifyPageLoaded() {
        return verifyPageLoaded(PAGE_LOADED_TEXT);
    }

    /**
     * VerifyTables that current page URL matches the expected URL.
     *
     * @return boolean.
     */
    public boolean verifyPageUrl() {
        return verifyPageUrl(PAGE_URL);
    }
}
