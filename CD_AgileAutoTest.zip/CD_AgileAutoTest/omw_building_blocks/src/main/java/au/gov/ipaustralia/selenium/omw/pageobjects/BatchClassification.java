package au.gov.ipaustralia.selenium.omw.pageobjects;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.UnknownFormatFlagsException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import au.gov.ipaustralia.selenium.helpers.wait.WaitTool;

public class BatchClassification extends OMWBasePage {

	private static final String PAGE_LOADED_TEXT = "Batch Classification";
	private static final String PAGE_URL = "/workbench-ui/secure/batch/batchclassify.xhtml?taskId=";
	private static final String IMAGE_TEXT = "IMAGE_FILE_NAMES";

	@FindBy(id = "batchdocs-form:j_idt43:0:batchdocuments-image-output")
	private WebElement unallocatedDocuments1;

	@FindBy(css = "div[title ='Drop pages here for document type Other']")
	private WebElement newServiceRequestDocuments;

	@FindBy(id = "servicerequests-form:batch-classify-multidocs")
	private WebElement newServiceRequestRepresenattaions;

	@FindBy(id = "s2id_servicerequests-form:businessline-fld")
	private WebElement businessLine;

	@FindBy(id = "servicerequests-form:batch-classify-businessline-fld")
	private WebElement businessLineDropDown;

	@FindBy(id = "servicerequests-form:batch-classify-classescount-fld")
	private WebElement tmClassesCount;

	@FindBy(id = "s2id_servicerequests-form:sr-fld")
	private WebElement serviceRequestParent;

	@FindBy(id = "servicerequests-form:batch-classify-sr-fld")
	private WebElement serviceRequestDropDown;

	@FindBy(css = "input[id^='s2id_autogen'][id$ = '_search']")
	private WebElement serviceRequest;

	@FindBy(how = How.LINK_TEXT, using = "Other")
	private WebElement other;

	@FindBy(how = How.LINK_TEXT, using = "Tm Representation")
	private WebElement representation;

	@FindBy(name = "servicerequests-form:batch-classify-additionalrequesttype-radio")
	private List<WebElement> additionalRequestTypeRadioGroup;

	@FindBy(id = "servicerequests-form:ipright-fld1")
	@CacheLookup
	private WebElement ipRight;

	@FindBy(id = "servicerequests-form:batch-classify-custref-fld")
	private WebElement customerRef;

	@FindBy(id = "servicerequests-form:batch-classify-savedocmetadata-button")
	private WebElement createServiceRequest;

	@FindBy(id = "servicerequests-form:j_idt88")
	@CacheLookup
	private WebElement multiRightsButton;

	@FindBy(id = "servicerequests-form:formPopup:j_idt156")
	@CacheLookup
	private WebElement addAnotherRow;

	@FindBy(id = "servicerequests-form:formPopup:j_idt157")
	@CacheLookup
	private WebElement saveClose;

	@FindBy(id = "servicerequests-form:formPopup:j_idt158")
	@CacheLookup
	private WebElement cancel;

	@FindBy(name = "servicerequests-form:formPopup:j_idt149:0:j_idt150")
	private WebElement ipRightNumber1;

	@FindBy(name = "servicerequests-form:formPopup:j_idt149:1:j_idt150")
	private WebElement ipRightNumber2;

	@FindBy(name = "servicerequests-form:formPopup:j_idt149:2:j_idt150")
	private WebElement ipRightNumber3;

	@FindBy(name = "servicerequests-form:formPopup:j_idt149:3:j_idt150")
	private WebElement ipRightNumber4;

	@FindBy(id = "servicerequests-form:batch-classify-srdata-wrapper-new-application-link-selection")
	private WebElement selectLinkedApps;

	@FindBy(id = "servicerequests-form:numDesigns-fld")
	@CacheLookup
	private WebElement numberOfMultiple;

	@FindBy(name = "servicerequests-form:batch-classify-srdata-wrapper-new-application-linked-ip-right-number-fld")
	@CacheLookup
	private WebElement linkedRequestId;

	@FindBy(name = "servicerequests-form:j_idt102")
	private WebElement linkRequestDropDown;

	public BatchClassification(WebDriver driver) {
		super();
		this.driver = driver;
		assertThat(verifyPageLoaded()).as("Batch Classification page is loaded").isTrue();
		assertThat(verifyPageUrl()).as("Batch Classification page URL is verified").isTrue();
	}

	public BatchClassification cleckMultiRightsButton() {
		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.elementToBeClickable(multiRightsButton));
		multiRightsButton.click();
		waitWhileOMWBusy();
		return this;
	}

	/**
	 * Moves documents from the 'Unallocated Documents' panel to the 'Other'
	 * tab; it needs a starting index for where the unallocated 'other' document
	 * displays in the 'unallocated douments' panel on the screen. The first
	 * position is index zero. Documents are displayed in the panel in the same
	 * order that they are added when creating the batch, with the receipt
	 * first.
	 * 
	 * @param numberOfOther
	 *            The number of 'other' documents to be moved
	 * @return
	 */
	public BatchClassification dragDocumentstoOther(int numberOfOther, int startIndex) {

		for (int i = startIndex; i < startIndex + numberOfOther; i++) {
			WebElement unallocated = driver
					.findElement(By.cssSelector("[id$='" + i + ":batchdocuments-image-output']"));
			dragAndDrop(unallocated, newServiceRequestDocuments);
		}

		return this;
	}

	public BatchClassification dragDocumentstoOther() {

		int startIndex = 1;
		int number = 0;
		if (getData().containsKey("NUMBER_OF_PROCESSED_OTHER")) {
			number = Integer.parseInt(getData().get("NUMBER_OF_PROCESSED_OTHER"));
		}
		if (getData().containsKey(IMAGE_TEXT)) {
			startIndex += getData().get(IMAGE_TEXT).split(";").length;
		}

		dragDocumentstoOther(number, startIndex);

		return this;
	}

	/**
	 * This method assumes there is one, and only one, doc before the images
	 * (the receipt). Images will be moved starting from the second doc
	 * displayed in the 'Unallocated documents' panel (ie index = 1).
	 * 
	 * @param numberOfReps
	 *            number of Images that are moved
	 * @return
	 */
	public BatchClassification dragRepsToImages(int numberOfReps) {
		for (int i = 1; i <= numberOfReps; i++) {

			WebElement unallocated = driver
					.findElement(By.cssSelector("[id$='" + i + ":batchdocuments-image-output']"));
			dragAndDrop(unallocated, newServiceRequestRepresenattaions);
		}
		return this;
	}

	/**
	 * This method assumes there is one, and only one, doc before the images
	 * (generally the receipt). Images will be moved starting from the second
	 * doc displayed in the 'Unallocated documents' panel (ie index = 1).
	 * 
	 * @return
	 */
	public BatchClassification dragRepsToImages() {
		int number = 0;
		if (getData().containsKey(IMAGE_TEXT)) {
			number = getData().get(IMAGE_TEXT).split(";").length;
		}

		dragRepsToImages(number);
		return this;
	}

	/**
	 * Set default value to Business Line Text field. key BUSINESS_LINE
	 *
	 * @return the OMW_BatchClassification class instance.
	 */
	public BatchClassification setBusinessLine() {
		if (getData().containsKey("BUSINESS_LINE")) {
			return setBusinessLine(getData().get("BUSINESS_LINE"));
		} else {
			return this;
		}
	}

	public BatchClassification setBusinessLine(String line) {
		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.visibilityOf(businessLineDropDown));
		flash(businessLineDropDown);
		businessLineDropDown.sendKeys(line);
		return this;
	}

	/**
	 * Set default value to Business Line Text field. key SERVICE_REQUEST
	 *
	 * @return the OMW_BatchClassification class instance.
	 */
	public BatchClassification setServiceRequest() {
		if (getData().containsKey("SERVICE_REQUEST")) {
			return setServiceRequest(getData().get("SERVICE_REQUEST"));
		} else {
			return this;
		}
	}

	public BatchClassification setServiceRequest(String request) {

		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.visibilityOf(serviceRequestDropDown));
		(new Select(serviceRequestDropDown)).selectByValue(request);
		return this;
	}

	public BatchClassification setTmClassesCount() {
		if (getData().containsKey("TM_CLASSES_COUNT")) {
			return setCustomerRef(getData().get("TM_CLASSES_COUNT"));
		} else {
			return this;
		}
	}

	public BatchClassification setTmClassesCount(String classesCount) {
		tmClassesCount.click();
		tmClassesCount.sendKeys(classesCount);
		return this;
	}

	public BatchClassification setRepresentationArea() {
		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.visibilityOf(representation));
		representation.click();
		WaitTool.sleep(200);
		return this;
	}

	public BatchClassification setOtherArea() {
		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.visibilityOf(other));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", other);
		return this;
	}

	public BatchClassification selectAdditionalRequestTypeRadio(String value) {
		for (WebElement _radio : additionalRequestTypeRadioGroup) {
			if (_radio.getAttribute("value").equals(value) && !_radio.isSelected()) {

				_radio.click();

			}
		}
		return this;
	}

	/**
	 * Set default name for the register type radio button to select. key
	 * REGISTER_TYPE_RADIO
	 *
	 * @return the OMW_BatchClassification class instance.
	 */
	public BatchClassification setRegsiterTypeRadioButton() {
		if (getData().containsKey("REGISTER_TYPE_RADIO")) {
			return setRegsiterTypeRadioButton(getData().get("REGISTER_TYPE_RADIO"));
		} else {
			return this;
		}
	}

	public BatchClassification setRegsiterTypeRadioButton(String label) {

		if (label.equalsIgnoreCase("register")) {
			selectAdditionalRequestTypeRadio("REG");

		} else if (label.equalsIgnoreCase("register and examine")) {
			selectAdditionalRequestTypeRadio("REG_EXAM");

		} else if (label.equalsIgnoreCase("publish")) {
			selectAdditionalRequestTypeRadio("PUB");

		} else if (label.equalsIgnoreCase("none")) {
			selectAdditionalRequestTypeRadio("NONE");

		} else {
			throw new UnknownFormatFlagsException(
					"Parameter " + label + " does not match known labels for register type radio buttons");
		}

		return this;

	}

	/**
	 * Set default text for the customer reference field. key CUSTOMER_REFERENCE
	 *
	 * @return the OMW_BatchClassification class instance.
	 */
	public BatchClassification setCustomerRef() {
		if (getData().containsKey("CUSTOMER_REFERENCE")) {
			return setCustomerRef(getData().get("CUSTOMER_REFERENCE"));
		} else {
			return this;
		}
	}

	public BatchClassification setCustomerRef(String reference) {
		customerRef.click();
		customerRef.sendKeys(reference);
		return this;
	}

	public BatchClassification setIPRight() {
		if (getData().containsKey("IP_RIGHT")) {
			return setIPRight(getData().get("IP_RIGHT"));
		} else {
			return this;
		}
	}

	public BatchClassification setIPRight(String rightID) {
		ipRight.sendKeys(rightID);
		waitWhileOMWBusy();
		return this;
	}

	public BatchClassification clickCreateServiceRequestButton() {
		createServiceRequest.click();
		waitWhileOMWBusy(120);
		return this;
	}

	public BatchClassification returnToBatchProcessing() {
		driver.navigate().back();
		return this;
	}

	/**
	 * Click on Add Another Row Button.
	 *
	 * @return the OMW_SelectMultipleRights class instance.
	 */
	public BatchClassification clickAddAnotherRowButton() {
		addAnotherRow.click();
		return this;
	}

	/**
	 * Click on Cancel Button.
	 *
	 * @return the OMW_SelectMultipleRights class instance.
	 */
	public BatchClassification clickCancelButton() {
		cancel.click();
		return this;
	}

	/**
	 * Click on Save Close Button.
	 *
	 * @return the OMW_SelectMultipleRights class instance.
	 */
	public BatchClassification clickSaveCloseButton() {
		saveClose.click();
		waitWhileOMWBusy();
		return this;
	}

	/**
	 * Set default value to Enter The Applicable Ip Right Numbers Text field.
	 *
	 * @return the OMW_SelectMultipleRights class instance.
	 */
	public BatchClassification setIpRightNumber01() {
		if (getData().containsKey("IP_RIGHT_1")) {
			return setIpRightNumber01(getIPRightNumberATMOSS("IP_RIGHT_1"));
		} else {
			return this;
		}
	}

	/**
	 * Set value to Enter The Applicable Ip Right Numbers Text field.
	 * 
	 * @param ipRightOne
	 *            first IP Right
	 *
	 * @return the OMW_SelectMultipleRights class instance.
	 */
	public BatchClassification setIpRightNumber01(String ipRightOne) {
		WebDriverWait elementWait = new WebDriverWait(driver, timeout);
		elementWait.pollingEvery(1, TimeUnit.SECONDS).ignoring(StaleElementReferenceException.class);
		elementWait.until(ExpectedConditions.visibilityOf(ipRightNumber1));
		ipRightNumber1.click();
		ipRightNumber1.sendKeys(ipRightOne);
		return this;
	}

	/**
	 * Set default value to Enter The Applicable Ip Right Numbers Text field.
	 *
	 * @return the OMW_SelectMultipleRights class instance.
	 */
	public BatchClassification setIpRightNumber02() {
		if (getData().containsKey("IP_RIGHT_2")) {
			return setIpRightNumber02(getIPRightNumberATMOSS("IP_RIGHT_2"));
		} else {
			return this;
		}
	}

	/**
	 * Set value to Enter The Applicable Ip Right Numbers Text field.
	 * 
	 * @param ipRightTwo
	 *            the second IP Right
	 *
	 * @return the OMW_SelectMultipleRights class instance.
	 */
	public BatchClassification setIpRightNumber02(String ipRightTwo) {
		ipRightNumber2.click();
		ipRightNumber2.sendKeys(ipRightTwo);
		return this;
	}

	/**
	 * Set default value to Enter The Applicable Ip Right Numbers Text field.
	 *
	 * @return the OMW_SelectMultipleRights class instance.
	 */
	public BatchClassification setIpRightNumber03() {
		if (getData().containsKey("IP_RIGHT_3")) {
			return setIpRightNumber03(getIPRightNumberATMOSS("IP_RIGHT_3"));
		} else {
			return this;
		}
	}

	/**
	 * Set value to Enter The Applicable Ip Right Numbers Text field.
	 * 
	 * @param ipRightThree
	 *            the third IP Right
	 *
	 * @return the OMW_SelectMultipleRights class instance.
	 */
	public BatchClassification setIpRightNumber03(String ipRightThree) {
		ipRightNumber3.click();
		ipRightNumber3.sendKeys(ipRightThree);
		return this;
	}

	/**
	 * Set default value to Enter The Applicable Ip Right Numbers Text field.
	 *
	 * @return the OMW_SelectMultipleRights class instance.
	 */
	public BatchClassification setIpRightNumber04() {
		if (getData().containsKey("IP_RIGHT_4")) {
			return setIpRightNumber04(getIPRightNumberATMOSS("IP_RIGHT_4"));
		} else {
			return this;
		}
	}

	/**
	 * Set value to Enter The Applicable Ip Right Numbers Text field.
	 *
	 * @param ipRightFour
	 *            teh forth IP Right
	 * 
	 * @return the OMW_SelectMultipleRights class instance.
	 */
	public BatchClassification setIpRightNumber04(String ipRightFour) {
		ipRightNumber4.click();
		ipRightNumber4.sendKeys(ipRightFour);
		return this;
	}

	public BatchClassification setLinkedAppsDropDown() {
		if (!getDataValue("LINKED_TYPE").equals("")) {
			return setLinkedAppsDropDown(getData().get("LINKED_TYPE"));
		} else {
			return this;
		}
	}

	public BatchClassification setLinkedAppsDropDown(String linkedType) {
		new Select(selectLinkedApps).selectByVisibleText(linkedType);
		return this;
	}

	public BatchClassification setNumberOfMultipleAppsTextField() {
		if (getData().containsKey("NO_OF_MULTIPLE")) {
			return setNumberOfMultipleAppsTextField(getData().get("NO_OF_MULTIPLE"));
		} else {
			return this;
		}
	}

	public BatchClassification setNumberOfMultipleAppsTextField(String noOfApps) {
		numberOfMultiple.sendKeys(noOfApps);
		return this;
	}

	public BatchClassification setLinkedIPRight() {
		if (!getDataValue("LINKED_IPRIGHT").equals("")) {
			return setLinkedIPRight(getIPRightNumberATMOSS("LINKED_IPRIGHT"));
		} else {
			return this;
		}
	}

	public BatchClassification setLinkedIPRight(String ipRight) {
		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.visibilityOf(linkedRequestId));
		linkedRequestId.sendKeys(ipRight);
		return this;
	}

	public BatchClassification setLinkedIPRightDrownDown(int index) {
		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.visibilityOf(linkRequestDropDown));
		new Select(linkRequestDropDown).selectByIndex(index);
		return this;
	}

	public String getLinkedIPRight() {
		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.visibilityOf(linkRequestDropDown));
		WebElement selectedOption = new Select(linkRequestDropDown).getFirstSelectedOption();
		return selectedOption.getText();
	}

	public BatchClassification setLinkedIPRightDrownDown(String value) {
		(new WebDriverWait(driver, timeout)).until(ExpectedConditions.visibilityOf(linkRequestDropDown));
		(new Select(linkRequestDropDown)).selectByValue(value);
		return this;
	}

	/**
	 * VerifyTables that the page loaded completely.
	 *
	 * @return boolean result
	 */
	public boolean verifyPageLoaded() {
		return verifyPageLoaded(PAGE_LOADED_TEXT);

	}

	/**
	 * VerifyTables that current page URL matches the expected URL.
	 *
	 * @return boolean result
	 */
	public boolean verifyPageUrl() {
		return verifyPageUrl(PAGE_URL);

	}

}
